"""
Firebase & Google OAuth2 Configuration — ISSAM v2.0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CONFIGURATION ACTIVE : Offline-First avec SQLite local
Firebase activé = False → l'app fonctionne 100% hors ligne
Pour activer Firebase :
  1. console.firebase.google.com → Créer un projet
  2. Authentication → Activer Email/Password + Google
  3. Copier la Web API Key ci-dessous
  4. Mettre USE_FIREBASE = True
"""

# ── Toggle principal ────────────────────────────────────────────────────────────
USE_FIREBASE = False        # False = mode local SQLite (fonctionnel sans config)

# ── Firebase (à renseigner si USE_FIREBASE = True) ─────────────────────────────
FIREBASE_API_KEY      = "AIzaSyA1DYoE7kp7WO3-gDMsktnKmOlWWaO13Gk"
FIREBASE_PROJECT_ID   = "studysnapia-92e38"
FIREBASE_AUTH_DOMAIN  = "studysnapia-92e38.firebaseapp.com"

# ── Google OAuth2 Desktop ──────────────────────────────────────────────────────
GOOGLE_CLIENT_ID      = "630551282021-6crmhiglt6nm5fmhc2b1m1b1kto089in.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET  = ""   # Renseigner depuis Google Cloud Console

# ── Firestore ─────────────────────────────────────────────────────────────────
FIRESTORE_BASE_URL = f"https://firestore.googleapis.com/v1/projects/{FIREBASE_PROJECT_ID}/databases/(default)/documents"

# ── Comptes démo (mode offline) ────────────────────────────────────────────────
DEMO_ACCOUNTS = {
    "enseignant@example.com": {
        "password": "password123",
        "uid": "demo-teacher-001",
        "display_name": "Marc Dupont",
        "prenom": "Marc",
        "nom": "Dupont",
        "role": "enseignant",
    },
    "admin@issam.cm": {
        "password": "admin123",
        "uid": "demo-admin-001",
        "display_name": "Admin ISSAM",
        "prenom": "Admin",
        "nom": "ISSAM",
        "role": "admin",
    },
}
