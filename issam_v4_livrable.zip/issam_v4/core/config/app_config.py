"""
ISSAM App Configuration — API endpoints, timeouts, flags
"""

# ── API ────────────────────────────────────────────────────────────────────────
API_BASE_URL   = "http://10.0.2.2:8000/api/v1"   # Local dev / Android emulator
# API_BASE_URL = "https://api.issam.cm/api/v1"   # Production (uncomment to use)

API_TIMEOUT    = 8          # seconds per request
SYNC_INTERVAL  = 60         # seconds between auto-sync attempts
MAX_RETRY      = 3          # max retry attempts per record
BATCH_SIZE     = 50         # notes per HTTP batch

# ── Offline ────────────────────────────────────────────────────────────────────
OFFLINE_MODE   = False       # Force offline (useful for demos with no server)
DEMO_SYNC_MOCK = True        # When server unreachable: simulate success after delay

# ── Security ──────────────────────────────────────────────────────────────────
SESSION_TIMEOUT_MIN = 30
PIN_MAX_ATTEMPTS    = 5
