"""
SyncManager — Offline-First HTTP Sync
Strategy:
  1. Get all pending notes from SQLite
  2. POST them in batches to the REST API
  3. On success  → mark_note_synced
  4. On HTTP error → mark_note_error (retried next cycle, max 3 attempts)
  5. On network error → keep pending, try again when online
  6. When no real server (DEMO_SYNC_MOCK=True) → simulate success after delay
All UI callbacks are dispatched on the Kivy main thread via Clock.schedule_once.
"""
import threading
import time
import json

import requests
from kivy.clock import Clock

from core.config.app_config import (
    API_BASE_URL, API_TIMEOUT, SYNC_INTERVAL,
    MAX_RETRY, BATCH_SIZE, OFFLINE_MODE, DEMO_SYNC_MOCK,
)


# ── Payload builder ────────────────────────────────────────────────────────────

def _build_payload(note):
    return {
        "uuid":             note["uuid"],
        "evaluation_uuid":  note["evaluation_uuid"],
        "eleve_uuid":       note["eleve_uuid"],
        "enseignant_uuid":  note["enseignant_uuid"],
        "valeur":           note["valeur"],
        "appreciation":     note.get("appreciation", ""),
        "updated_at":       note["updated_at"],
        "metadata": {
            "matricule":    note.get("matricule", ""),
            "eleve_nom":    note.get("eleve_nom", ""),
            "eval_nom":     note.get("eval_nom", ""),
            "classe_nom":   note.get("classe_nom", ""),
        },
    }


# ── HTTP helpers ───────────────────────────────────────────────────────────────

def _post_batch(notes):
    """
    POST a batch of notes.
    Returns (synced_uuids, failed_items)
    failed_items = [(uuid, error_string), ...]
    """
    url = f"{API_BASE_URL}/notes/batch-sync"
    payload = {"notes": [_build_payload(n) for n in notes]}
    try:
        resp = requests.post(url, json=payload, timeout=API_TIMEOUT)
        if resp.status_code == 200:
            data = resp.json()
            synced = data.get("synced", [n["uuid"] for n in notes])
            failed = [(item["uuid"], item.get("error", "Unknown"))
                      for item in data.get("failed", [])]
            return synced, failed
        elif resp.status_code in (400, 422):
            # Validation errors — mark all as error
            return [], [(n["uuid"], f"HTTP {resp.status_code}") for n in notes]
        else:
            # Server error — keep as pending (don't consume attempts)
            return None, None  # None = network-level failure
    except requests.exceptions.ConnectionError:
        return None, None  # Offline
    except requests.exceptions.Timeout:
        return None, None  # Timeout


class SyncManager:
    def __init__(self, db_manager, network_monitor):
        self.db = db_manager
        self.network = network_monitor
        self.is_syncing = False
        self.sync_progress = 0
        self._stop_auto = False
        self._callbacks = []   # list of callable(event, data)

        self.network.bind(is_online=self._on_connectivity_change)
        # Start the periodic auto-sync thread
        threading.Thread(target=self._auto_sync_loop, daemon=True).start()

    # ─────────────── Public API ───────────────────────────────────────────────

    def register_callback(self, cb):
        """Register a UI callback. Called on the MAIN thread via Clock."""
        if cb not in self._callbacks:
            self._callbacks.append(cb)

    def unregister_callback(self, cb):
        if cb in self._callbacks:
            self._callbacks.remove(cb)

    def start_sync(self, on_complete=None):
        """Start a manual sync. on_complete(success:bool, synced:int, failed:int)"""
        if self.is_syncing:
            return
        threading.Thread(
            target=self._run_sync,
            args=(on_complete,),
            daemon=True,
        ).start()

    # ─────────────── Internal ─────────────────────────────────────────────────

    def _notify(self, event, data=None):
        for cb in list(self._callbacks):
            Clock.schedule_once(lambda dt, e=event, d=data: cb(e, d), 0)

    def _on_connectivity_change(self, instance, is_online):
        if is_online and not self.is_syncing:
            stats = self.db.get_sync_stats()
            if stats['pending'] > 0:
                time.sleep(1.5)   # let network settle
                threading.Thread(target=self._run_sync, daemon=True).start()

    def _auto_sync_loop(self):
        """Background thread: attempt sync every SYNC_INTERVAL seconds."""
        time.sleep(10)  # initial delay at app start
        while not self._stop_auto:
            if self.network.is_online and not self.is_syncing:
                stats = self.db.get_sync_stats()
                if stats['pending'] > 0:
                    self._run_sync()
            time.sleep(SYNC_INTERVAL)

    def _run_sync(self, on_complete=None):
        if self.is_syncing:
            return
        self.is_syncing = True
        self.sync_progress = 0
        self._notify('sync_start', None)

        total_synced = 0
        total_failed = 0

        try:
            pending_notes = self.db.get_pending_notes_for_sync(limit=200)
            total = len(pending_notes)

            if total == 0:
                self._notify('sync_complete', {'synced': 0, 'failed': 0, 'total': 0})
                if on_complete:
                    Clock.schedule_once(lambda dt: on_complete(True, 0, 0), 0)
                return

            if OFFLINE_MODE or (DEMO_SYNC_MOCK and not self.network.is_online):
                # ── Mock mode ──────────────────────────────────────────────────
                for i, note in enumerate(pending_notes):
                    time.sleep(0.08)
                    self.db.mark_note_synced(note['uuid'])
                    total_synced += 1
                    self.sync_progress = int((i + 1) / total * 100)
                    self._notify('sync_progress', {
                        'pct': self.sync_progress,
                        'current': i + 1,
                        'total': total,
                        'label': note.get('eleve_nom', ''),
                    })
            else:
                # ── Real HTTP sync ────────────────────────────────────────────
                for batch_start in range(0, total, BATCH_SIZE):
                    batch = pending_notes[batch_start:batch_start + BATCH_SIZE]
                    synced_uuids, failed_items = _post_batch(batch)

                    if synced_uuids is None:
                        # Network failure — stop and keep everything pending
                        self._notify('sync_error', {
                            'message': 'Connexion perdue. Les notes seront synchronisées dès que le réseau sera disponible.',
                            'synced': total_synced,
                        })
                        break

                    for note_uuid in synced_uuids:
                        self.db.mark_note_synced(note_uuid)
                        total_synced += 1

                    for note_uuid, err in (failed_items or []):
                        self.db.mark_note_error(note_uuid, err)
                        total_failed += 1

                    done = batch_start + len(batch)
                    self.sync_progress = int(done / total * 100)
                    self._notify('sync_progress', {
                        'pct': self.sync_progress,
                        'current': done,
                        'total': total,
                    })
                    time.sleep(0.05)  # brief pause between batches

            self.db.log_sync_result(total_synced, total_failed)
            self._notify('sync_complete', {
                'synced': total_synced,
                'failed': total_failed,
                'total': total,
            })
            if on_complete:
                Clock.schedule_once(
                    lambda dt: on_complete(total_failed == 0, total_synced, total_failed), 0
                )

        except Exception as e:
            print(f"[SyncManager] Unexpected error: {e}")
            self._notify('sync_error', {'message': str(e), 'synced': total_synced})
            if on_complete:
                Clock.schedule_once(lambda dt: on_complete(False, total_synced, 0), 0)
        finally:
            self.is_syncing = False
            self.sync_progress = 0
