"""
TokenStore — Persist Firebase session locally (survives app restarts).
Stores refresh_token + user profile in a base64-encoded JSON file.
On Android production, swap this for Android Keystore / EncryptedSharedPreferences.
"""
import json
import base64
from pathlib import Path
from datetime import datetime

_SESSION_FILE = Path('.issam_session.dat')


class TokenStore:

    @staticmethod
    def save(user) -> None:
        """Save a FirebaseUser to disk."""
        data = {
            'uid':            user.uid,
            'email':          user.email,
            'display_name':   user.display_name,
            'email_verified': user.email_verified,
            'id_token':       user.id_token,
            'refresh_token':  user.refresh_token,
            'photo_url':      getattr(user, 'photo_url', ''),
            'saved_at':       datetime.now().isoformat(),
        }
        encoded = base64.b64encode(json.dumps(data).encode()).decode()
        _SESSION_FILE.write_text(encoded)

    @staticmethod
    def load() -> dict | None:
        """Load saved session. Returns dict or None."""
        try:
            if _SESSION_FILE.exists():
                raw  = _SESSION_FILE.read_text().strip()
                data = json.loads(base64.b64decode(raw).decode())
                # Basic sanity check
                if data.get('refresh_token') and data.get('uid'):
                    return data
        except Exception:
            pass
        return None

    @staticmethod
    def clear() -> None:
        try:
            _SESSION_FILE.unlink(missing_ok=True)
        except Exception:
            pass

    @staticmethod
    def update_token(id_token: str, refresh_token: str) -> None:
        """Update only the tokens after a refresh."""
        data = TokenStore.load() or {}
        data['id_token']      = id_token
        data['refresh_token'] = refresh_token
        data['saved_at']      = datetime.now().isoformat()
        encoded = base64.b64encode(json.dumps(data).encode()).decode()
        _SESSION_FILE.write_text(encoded)
