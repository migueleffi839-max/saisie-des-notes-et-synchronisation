"""
Firebase REST Auth Client
Implements: Email/Password sign-up, sign-in, email verification,
            password reset, token refresh, Google Sign-In via ID token.
No Firebase SDK — pure REST API (works on all platforms).
"""
import requests
from datetime import datetime, timedelta
from core.config.firebase_config import FIREBASE_API_KEY

_BASE  = "https://identitytoolkit.googleapis.com/v1/accounts"
_TOKEN = "https://securetoken.googleapis.com/v1/token"

# ── French error messages ──────────────────────────────────────────────────────
_ERRORS = {
    'EMAIL_NOT_FOUND':                  "Aucun compte avec cet email.",
    'INVALID_PASSWORD':                 "Mot de passe incorrect.",
    'INVALID_EMAIL':                    "Adresse email invalide.",
    'USER_DISABLED':                    "Ce compte a été désactivé.",
    'EMAIL_EXISTS':                     "Un compte avec cet email existe déjà.",
    'WEAK_PASSWORD : Password should be at least 6 characters':
                                        "Mot de passe trop court (6 caractères min.).",
    'WEAK_PASSWORD':                    "Mot de passe trop faible.",
    'TOO_MANY_ATTEMPTS_TRY_LATER':      "Trop de tentatives. Réessayez dans quelques minutes.",
    'OPERATION_NOT_ALLOWED':            "Méthode de connexion non activée.",
    'USER_NOT_FOUND':                   "Aucun compte avec cet email.",
    'INVALID_ID_TOKEN':                 "Session expirée. Reconnectez-vous.",
    'TOKEN_EXPIRED':                    "Session expirée. Reconnectez-vous.",
    'CREDENTIAL_TOO_OLD_LOGIN_AGAIN':   "Reconnectez-vous pour continuer.",
    'INVALID_REFRESH_TOKEN':            "Session invalide. Reconnectez-vous.",
    'NETWORK_ERROR':                    "Pas de connexion internet.",
    'TIMEOUT':                          "Délai dépassé. Réessayez.",
}


class FirebaseAuthError(Exception):
    def __init__(self, code, message=None):
        self.code    = code
        self.message = message or _ERRORS.get(code, f"Erreur: {code}")
        super().__init__(self.message)


class FirebaseUser:
    __slots__ = ('uid', 'email', 'display_name', 'email_verified',
                 'id_token', 'refresh_token', 'expires_at', 'photo_url')

    def __init__(self, data: dict):
        self.uid            = data.get('localId', '')
        self.email          = data.get('email', '')
        self.display_name   = data.get('displayName', '')
        self.email_verified = data.get('emailVerified', False)
        self.id_token       = data.get('idToken', '')
        self.refresh_token  = data.get('refreshToken', '')
        self.photo_url      = data.get('photoUrl', '')
        exp = int(data.get('expiresIn', 3600))
        self.expires_at     = datetime.now() + timedelta(seconds=exp)

    @property
    def is_token_expired(self):
        return datetime.now() >= self.expires_at

    def to_dict(self):
        return {
            'uid':            self.uid,
            'email':          self.email,
            'display_name':   self.display_name,
            'email_verified': self.email_verified,
            'id_token':       self.id_token,
            'refresh_token':  self.refresh_token,
            'photo_url':      self.photo_url,
            'expires_at':     self.expires_at.isoformat(),
        }


class FirebaseAuth:
    """Thread-safe Firebase REST authentication client."""

    def __init__(self):
        self.api_key  = FIREBASE_API_KEY
        self._session = requests.Session()
        self._session.headers.update({'Content-Type': 'application/json'})

    # ─────────────── private ──────────────────────────────────────────────────

    def _post(self, endpoint: str, payload: dict, timeout=10) -> dict:
        url = f"{_BASE}:{endpoint}?key={self.api_key}"
        try:
            resp = self._session.post(url, json=payload, timeout=timeout)
            data = resp.json()
            if resp.status_code != 200:
                raw_code = data.get('error', {}).get('message', 'UNKNOWN')
                # Firebase sometimes appends extra info after " : "
                code = raw_code.split(' : ')[0]
                raise FirebaseAuthError(code)
            return data
        except FirebaseAuthError:
            raise
        except requests.exceptions.ConnectionError:
            raise FirebaseAuthError('NETWORK_ERROR')
        except requests.exceptions.Timeout:
            raise FirebaseAuthError('TIMEOUT')
        except Exception as e:
            raise FirebaseAuthError('UNKNOWN', str(e))

    def _post_token(self, payload: dict, timeout=10) -> dict:
        url = f"{_TOKEN}?key={self.api_key}"
        try:
            resp = self._session.post(url, json=payload, timeout=timeout)
            data = resp.json()
            if resp.status_code != 200:
                raise FirebaseAuthError('INVALID_REFRESH_TOKEN')
            return data
        except FirebaseAuthError:
            raise
        except Exception as e:
            raise FirebaseAuthError('UNKNOWN', str(e))

    # ─────────────── public API ───────────────────────────────────────────────

    def sign_up(self, email: str, password: str) -> FirebaseUser:
        """Register a new user. Throws FirebaseAuthError on failure."""
        data = self._post('signUp', {
            'email': email, 'password': password, 'returnSecureToken': True,
        })
        return FirebaseUser(data)

    def sign_in(self, email: str, password: str) -> FirebaseUser:
        """Sign in with email + password."""
        data = self._post('signInWithPassword', {
            'email': email, 'password': password, 'returnSecureToken': True,
        })
        return FirebaseUser(data)

    def sign_in_with_google(self, google_id_token: str) -> FirebaseUser:
        """Exchange a Google ID token for a Firebase session."""
        data = self._post('signInWithIdp', {
            'postBody':             f'id_token={google_id_token}&providerId=google.com',
            'requestUri':           'http://localhost',
            'returnIdpCredential':  True,
            'returnSecureToken':    True,
        })
        return FirebaseUser(data)

    def send_email_verification(self, id_token: str):
        """Send verification email to the signed-in user."""
        self._post('sendOobCode', {
            'requestType': 'VERIFY_EMAIL', 'idToken': id_token,
        })

    def send_password_reset(self, email: str):
        """Send password-reset email."""
        self._post('sendOobCode', {
            'requestType': 'PASSWORD_RESET', 'email': email,
        })

    def get_user_info(self, id_token: str) -> dict:
        """Fetch current user profile (includes emailVerified)."""
        data = self._post('lookup', {'idToken': id_token})
        users = data.get('users', [])
        return users[0] if users else {}

    def refresh_id_token(self, refresh_token: str) -> dict:
        """Exchange a refresh token for a new ID token."""
        data = self._post_token({
            'grant_type': 'refresh_token', 'refresh_token': refresh_token,
        })
        return {
            'idToken':      data.get('id_token', ''),
            'refreshToken': data.get('refresh_token', ''),
            'localId':      data.get('user_id', ''),
            'expiresIn':    data.get('expires_in', '3600'),
            'emailVerified': False,
        }

    def update_profile(self, id_token: str, display_name: str = '',
                        photo_url: str = '') -> dict:
        """Update display name / photo URL."""
        return self._post('update', {
            'idToken':     id_token,
            'displayName': display_name,
            'photoUrl':    photo_url,
            'returnSecureToken': True,
        })
