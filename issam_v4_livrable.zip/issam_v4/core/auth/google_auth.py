"""
Google OAuth2 PKCE Flow — Desktop / Kivy — ISSAM v2.0 CORRIGÉ
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Fix principal : port FIXE (8080) au lieu d'un port aléatoire.
Google Cloud Console doit avoir exactement : http://127.0.0.1:8080

Dans Google Cloud Console → APIs & Services → Credentials →
  ton OAuth 2.0 Client ID (Desktop) → Authorized redirect URIs :
    http://127.0.0.1:8080       ← celui-ci suffit
"""
import secrets
import hashlib
import base64
import urllib.parse
import webbrowser
import threading
import socket
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler
from kivy.clock import Clock
from core.config.firebase_config import GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET

_AUTH_URL  = "https://accounts.google.com/o/oauth2/v2/auth"
_TOKEN_URL = "https://oauth2.googleapis.com/token"
_SCOPES    = "openid email profile"

# Port fixe — doit correspondre exactement à Google Cloud Console
_REDIRECT_PORT = 8080
_REDIRECT_URI  = f"http://127.0.0.1:{_REDIRECT_PORT}"

# ── Pages HTML de retour ───────────────────────────────────────────────────────
_HTML_OK = """<!DOCTYPE html><html><head><meta charset="utf-8">
<title>ISSAM — Connexion réussie</title>
<style>body{background:#030B14;color:#F1F5F9;font-family:sans-serif;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.box{text-align:center;padding:40px}.icon{font-size:64px}
h1{color:#3B82F6;margin:16px 0 8px}p{color:#94A3B8}
</style></head>
<body><div class="box"><div class="icon">✅</div>
<h1>Connexion réussie !</h1>
<p>Retournez sur l'application ISSAM.</p>
<p style="color:#475569;font-size:13px;margin-top:20px">
  Vous pouvez fermer cet onglet.
</p></div>
<script>setTimeout(()=>window.close(),2000);</script>
</body></html>"""

_HTML_CANCEL = """<!DOCTYPE html><html><head><meta charset="utf-8">
<title>ISSAM — Annulé</title>
<style>body{background:#030B14;color:#F1F5F9;font-family:sans-serif;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.box{text-align:center;padding:40px}.icon{font-size:64px}
h1{color:#EF4444;margin:16px 0 8px}p{color:#94A3B8}</style></head>
<body><div class="box"><div class="icon">✖</div>
<h1>Connexion annulée</h1>
<p>Retournez sur l'application ISSAM.</p>
</div></body></html>"""

_HTML_ALREADY = """<!DOCTYPE html><html><head><meta charset="utf-8">
<title>ISSAM</title>
<style>body{background:#030B14;color:#F1F5F9;font-family:sans-serif;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.box{text-align:center;padding:40px}</style></head>
<body><div class="box"><p style="color:#94A3B8">Traitement en cours...</p>
</div></body></html>"""


class _CallbackHandler(BaseHTTPRequestHandler):
    """Serveur HTTP one-shot : capture le code OAuth2."""

    # Résultat partagé entre le handler et le thread principal
    result = {'code': None, 'error': None, 'done': False}

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        # Favicon — ignorer
        if self.path == '/favicon.ico':
            self.send_response(204)
            self.end_headers()
            return

        code  = params.get('code',  [None])[0]
        error = params.get('error', [None])[0]

        if _CallbackHandler.result['done']:
            # Requête dupliquée (le navigateur recharge parfois)
            html = _HTML_ALREADY
        else:
            _CallbackHandler.result['code']  = code
            _CallbackHandler.result['error'] = error
            _CallbackHandler.result['done']  = True
            html = _HTML_OK if code else _HTML_CANCEL

        body = html.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        pass  # silencieux


def _port_available(port: int) -> bool:
    """Vérifie si un port est libre."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(('127.0.0.1', port))
            return True
        except OSError:
            return False


class GoogleAuth:
    """
    Flux OAuth2 PKCE Desktop.
    
    Prérequis Google Cloud Console :
      - Type de client : Application de bureau (Desktop)
      - URI de redirection autorisée : http://127.0.0.1:8080
    """

    def start_sign_in(self, on_success, on_error):
        """
        Lance le flux OAuth dans un thread daemon.
        on_success(id_token: str)  — thread principal Kivy
        on_error(message: str)     — thread principal Kivy
        """
        threading.Thread(
            target=self._flow,
            args=(on_success, on_error),
            daemon=True,
            name="GoogleOAuth",
        ).start()

    def _flow(self, on_success, on_error):
        def _err(msg):
            Clock.schedule_once(lambda dt: on_error(msg), 0)

        # ── Vérifier que le port est disponible ────────────────────────────────
        if not _port_available(_REDIRECT_PORT):
            _err(
                f"Port {_REDIRECT_PORT} déjà utilisé.\n"
                "Fermez l'autre application et réessayez."
            )
            return

        # ── PKCE — génération verifier + challenge ─────────────────────────────
        verifier  = secrets.token_urlsafe(64)
        digest    = hashlib.sha256(verifier.encode('ascii')).digest()
        challenge = base64.urlsafe_b64encode(digest).rstrip(b'=').decode('ascii')

        # ── Construction URL d'autorisation ───────────────────────────────────
        params = {
            'client_id':             GOOGLE_CLIENT_ID,
            'redirect_uri':          _REDIRECT_URI,       # port fixe 8080
            'response_type':         'code',
            'scope':                 _SCOPES,
            'code_challenge':        challenge,
            'code_challenge_method': 'S256',
            'access_type':           'offline',
            'prompt':                'select_account',
        }
        auth_url = _AUTH_URL + '?' + urllib.parse.urlencode(params)

        # ── Démarrer le serveur local AVANT d'ouvrir le navigateur ────────────
        _CallbackHandler.result = {'code': None, 'error': None, 'done': False}

        try:
            server = HTTPServer(('127.0.0.1', _REDIRECT_PORT), _CallbackHandler)
            server.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.timeout = 300  # 5 minutes max
        except OSError as e:
            _err(f"Impossible d'ouvrir le serveur local: {e}")
            return

        print(f"[GoogleAuth] Serveur local démarré sur {_REDIRECT_URI}")

        # ── Ouvrir le navigateur APRÈS que le serveur est prêt ────────────────
        try:
            webbrowser.open(auth_url)
        except Exception as e:
            server.server_close()
            _err(f"Impossible d'ouvrir le navigateur: {e}")
            return

        # ── Attendre le callback (bloquant jusqu'à timeout) ────────────────────
        # handle_request() gère UNE requête puis rend la main
        # On boucle pour ignorer favicon et doublons
        max_requests = 5
        for _ in range(max_requests):
            server.handle_request()
            if _CallbackHandler.result['done']:
                break

        server.server_close()
        print("[GoogleAuth] Serveur local fermé.")

        code  = _CallbackHandler.result.get('code')
        error = _CallbackHandler.result.get('error')

        if error:
            msg = ("Connexion Google annulée." if error == 'access_denied'
                   else f"Erreur Google: {error}")
            _err(msg)
            return

        if not code:
            _err("Aucun code reçu de Google. Réessayez.")
            return

        # ── Échange code → ID token ────────────────────────────────────────────
        print(f"[GoogleAuth] Code reçu, échange en cours…")
        try:
            resp = requests.post(_TOKEN_URL, data={
                'code':          code,
                'client_id':     GOOGLE_CLIENT_ID,
                'client_secret': GOOGLE_CLIENT_SECRET,
                'redirect_uri':  _REDIRECT_URI,
                'grant_type':    'authorization_code',
                'code_verifier': verifier,
            }, timeout=20)
            data = resp.json()
        except requests.exceptions.Timeout:
            _err("Délai dépassé lors de l'échange de token Google.")
            return
        except Exception as e:
            _err(f"Échange de token échoué: {e}")
            return

        if resp.status_code != 200:
            err_desc = data.get('error_description', data.get('error', 'Erreur inconnue'))
            print(f"[GoogleAuth] Token error: {data}")
            _err(f"Google a refusé le token: {err_desc}")
            return

        id_token = data.get('id_token')
        if not id_token:
            _err("ID token Google absent de la réponse.")
            return

        print("[GoogleAuth] ID token obtenu avec succès ✓")
        Clock.schedule_once(lambda dt: on_success(id_token), 0)
