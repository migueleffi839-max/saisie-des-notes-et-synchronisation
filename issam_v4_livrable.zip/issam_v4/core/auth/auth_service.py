"""
AuthService — Couche d'authentification unifiée ISSAM v2.0
Offline-First : fonctionne sans Firebase.
Délègue à Firebase quand USE_FIREBASE=True.
Callbacks toujours sur le thread principal Kivy.
"""
import threading
import hashlib
from kivy.clock import Clock
from core.config.firebase_config import USE_FIREBASE, DEMO_ACCOUNTS


class AuthService:
    def __init__(self, db_manager):
        self.db = db_manager
        self._firebase = None
        self._google   = None
        self._store    = None

        if USE_FIREBASE:
            try:
                from core.auth.firebase_auth import FirebaseAuth
                from core.auth.google_auth   import GoogleAuth
                from core.auth.token_store   import TokenStore
                self._firebase = FirebaseAuth()
                self._google   = GoogleAuth()
                self._store    = TokenStore
            except Exception as e:
                print(f"[Auth] Firebase init failed: {e} → mode local activé")

    # ─────────────────────────── API publique ─────────────────────────────────

    def sign_in(self, email, password, on_success, on_error):
        threading.Thread(
            target=self._do_sign_in,
            args=(email, password, on_success, on_error),
            daemon=True,
        ).start()

    def sign_up(self, email, password, display_name, on_success, on_error):
        threading.Thread(
            target=self._do_sign_up,
            args=(email, password, display_name, on_success, on_error),
            daemon=True,
        ).start()

    def sign_in_with_google(self, on_success, on_error):
        if not USE_FIREBASE or not self._google:
            Clock.schedule_once(
                lambda dt: on_error(
                    "Google Sign-In nécessite Firebase.\n"
                    "Configurez firebase_config.py et mettez USE_FIREBASE=True."
                ), 0)
            return
        self._google.start_sign_in(
            on_success=lambda id_tok: threading.Thread(
                target=self._do_google_signin,
                args=(id_tok, on_success, on_error), daemon=True).start(),
            on_error=lambda msg: Clock.schedule_once(lambda dt: on_error(msg), 0),
        )

    def send_password_reset(self, email, on_success, on_error):
        threading.Thread(
            target=self._do_reset,
            args=(email, on_success, on_error),
            daemon=True,
        ).start()

    def send_email_verification(self, id_token, on_success, on_error):
        if not USE_FIREBASE or not self._firebase:
            # En mode local, on simule la vérification
            Clock.schedule_once(lambda dt: on_success(), 0)
            return
        threading.Thread(
            target=self._do_send_verify,
            args=(id_token, on_success, on_error),
            daemon=True,
        ).start()

    def check_email_verified(self, id_token, on_result):
        if not USE_FIREBASE:
            Clock.schedule_once(lambda dt: on_result(True), 0)
            return
        threading.Thread(
            target=self._do_check_verify,
            args=(id_token, on_result),
            daemon=True,
        ).start()

    def restore_session(self, on_success, on_no_session):
        if not USE_FIREBASE or not self._store:
            Clock.schedule_once(lambda dt: on_no_session(), 0)
            return
        threading.Thread(
            target=self._do_restore,
            args=(on_success, on_no_session),
            daemon=True,
        ).start()

    def sign_out(self):
        if self._store:
            try:
                self._store.clear()
            except Exception:
                pass

    # ─────────────────────────── Implémentation Firebase ─────────────────────

    def _do_sign_in(self, email, password, on_success, on_error):
        if USE_FIREBASE and self._firebase:
            try:
                user = self._firebase.sign_in(email, password)
                if self._store:
                    self._store.save(user)
                profile = {
                    'uid': user.uid, 'email': user.email,
                    'display_name': user.display_name,
                    'email_verified': user.email_verified,
                    'id_token': user.id_token,
                    'refresh_token': user.refresh_token,
                    'prenom': (user.display_name or '').split()[0] if user.display_name else 'Prof',
                    'nom': ' '.join((user.display_name or '').split()[1:]) if user.display_name else '',
                    'provider': 'email', 'role': 'enseignant',
                }
                Clock.schedule_once(lambda dt: on_success(profile), 0)
            except Exception as e:
                msg = getattr(e, 'message', str(e))
                Clock.schedule_once(lambda dt: on_error(msg), 0)
        else:
            self._local_sign_in(email, password, on_success, on_error)

    def _do_sign_up(self, email, password, display_name, on_success, on_error):
        if USE_FIREBASE and self._firebase:
            try:
                user = self._firebase.sign_up(email, password)
                if display_name:
                    self._firebase.update_profile(user.id_token, display_name=display_name)
                self._firebase.send_email_verification(user.id_token)
                if self._store:
                    self._store.save(user)
                parts = display_name.split() if display_name else ['Enseignant', '']
                profile = {
                    'uid': user.uid, 'email': user.email,
                    'display_name': display_name,
                    'email_verified': False,
                    'id_token': user.id_token,
                    'refresh_token': user.refresh_token,
                    'prenom': parts[0], 'nom': ' '.join(parts[1:]),
                    'provider': 'email', 'role': 'enseignant',
                }
                Clock.schedule_once(lambda dt: on_success(profile), 0)
            except Exception as e:
                msg = getattr(e, 'message', str(e))
                Clock.schedule_once(lambda dt: on_error(msg), 0)
        else:
            # Mode local : créer un compte SQLite
            self._local_sign_up(email, password, display_name, on_success, on_error)

    def _local_sign_up(self, email, password, display_name, on_success, on_error):
        """Créer un compte local dans SQLite."""
        try:
            existing = self.db.get_user_by_email(email)
            if existing:
                Clock.schedule_once(lambda dt: on_error("Un compte avec cet email existe déjà."), 0)
                return
            parts = display_name.split() if display_name else ['Enseignant', '']
            prenom = parts[0]
            nom = ' '.join(parts[1:]) if len(parts) > 1 else 'Dupont'
            pwd_hash = hashlib.sha256(password.encode()).hexdigest()
            import uuid as uuid_mod
            uid = str(uuid_mod.uuid4())
            self.db.create_user(uid, email, prenom, nom, pwd_hash, 'enseignant')
            profile = {
                'uid': uid, 'email': email,
                'display_name': display_name,
                'email_verified': True,
                'id_token': None, 'refresh_token': None,
                'prenom': prenom, 'nom': nom,
                'provider': 'local', 'role': 'enseignant',
            }
            Clock.schedule_once(lambda dt: on_success(profile), 0)
        except Exception as e:
            Clock.schedule_once(lambda dt: on_error(f"Erreur inscription: {e}"), 0)

    def _do_google_signin(self, id_token, on_success, on_error):
        try:
            user = self._firebase.sign_in_with_google(id_token)
            if self._store:
                self._store.save(user)
            profile = {
                'uid': user.uid, 'email': user.email,
                'display_name': user.display_name,
                'email_verified': True,
                'id_token': user.id_token,
                'refresh_token': user.refresh_token,
                'photo_url': getattr(user, 'photo_url', ''),
                'prenom': (user.display_name or '').split()[0] if user.display_name else 'Utilisateur',
                'nom': ' '.join((user.display_name or '').split()[1:]) if user.display_name else '',
                'provider': 'google', 'role': 'enseignant',
            }
            Clock.schedule_once(lambda dt: on_success(profile), 0)
        except Exception as e:
            msg = getattr(e, 'message', str(e))
            Clock.schedule_once(lambda dt: on_error(msg), 0)

    def _do_reset(self, email, on_success, on_error):
        if USE_FIREBASE and self._firebase:
            try:
                self._firebase.send_password_reset(email)
                Clock.schedule_once(lambda dt: on_success(), 0)
            except Exception as e:
                msg = getattr(e, 'message', str(e))
                Clock.schedule_once(lambda dt: on_error(msg), 0)
        else:
            # Mode local : simuler l'envoi
            Clock.schedule_once(lambda dt: on_success(), 0)

    def _do_send_verify(self, id_token, on_success, on_error):
        try:
            self._firebase.send_email_verification(id_token)
            Clock.schedule_once(lambda dt: on_success(), 0)
        except Exception as e:
            msg = getattr(e, 'message', str(e))
            Clock.schedule_once(lambda dt: on_error(msg), 0)

    def _do_check_verify(self, id_token, on_result):
        try:
            info = self._firebase.get_user_info(id_token)
            verified = bool(info.get('emailVerified', False))
        except Exception:
            verified = False
        Clock.schedule_once(lambda dt: on_result(verified), 0)

    def _do_restore(self, on_success, on_no_session):
        data = self._store.load()
        if not data or not data.get('refresh_token'):
            Clock.schedule_once(lambda dt: on_no_session(), 0)
            return
        try:
            new_tokens = self._firebase.refresh_id_token(data['refresh_token'])
            self._store.update_token(new_tokens['idToken'], new_tokens['refreshToken'])
            profile = {
                **data,
                'id_token': new_tokens['idToken'],
                'refresh_token': new_tokens['refreshToken'],
                'provider': data.get('provider', 'email'),
                'role': 'enseignant',
            }
            Clock.schedule_once(lambda dt: on_success(profile), 0)
        except Exception:
            self._store.clear()
            Clock.schedule_once(lambda dt: on_no_session(), 0)

    # ─────────────────────────── Authentification locale SQLite ──────────────

    def _local_sign_in(self, email, password, on_success, on_error):
        """Authentification hors ligne via SQLite + comptes démo."""

        # 1. Comptes démo depuis config
        demo = DEMO_ACCOUNTS.get(email)
        if demo and demo['password'] == password:
            profile = {
                'uid': demo['uid'],
                'email': email,
                'display_name': demo['display_name'],
                'email_verified': True,
                'id_token': None,
                'refresh_token': None,
                'prenom': demo['prenom'],
                'nom': demo['nom'],
                'provider': 'local',
                'role': demo['role'],
            }
            Clock.schedule_once(lambda dt: on_success(profile), 0)
            return

        # 2. Base SQLite
        try:
            user = self.db.get_user_by_email(email)
            if user:
                pwd_hash = hashlib.sha256(password.encode()).hexdigest()
                if user['mot_de_passe_hash'] == pwd_hash:
                    profile = {
                        'uid': user['uuid'],
                        'email': user['email'],
                        'display_name': f"{user['prenom']} {user['nom']}",
                        'email_verified': True,
                        'id_token': None,
                        'refresh_token': None,
                        'prenom': user['prenom'],
                        'nom': user['nom'],
                        'provider': 'local',
                        'role': user['role'],
                    }
                    Clock.schedule_once(lambda dt: on_success(profile), 0)
                    return
        except Exception as e:
            print(f"[Auth] DB error: {e}")

        Clock.schedule_once(
            lambda dt: on_error("Email ou mot de passe incorrect."), 0)
