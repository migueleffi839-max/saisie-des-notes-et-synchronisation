"""
Network Monitor — Détection connectivité asynchrone
"""
import threading
import socket
import time
from kivy.event import EventDispatcher
from kivy.properties import BooleanProperty


class NetworkMonitor(EventDispatcher):
    is_online = BooleanProperty(False)

    def __init__(self, **kwargs):
        self.register_event_type('on_connectivity_change')
        super().__init__(**kwargs)
        self._running = False
        self._thread = None

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._poll, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _check_connection(self):
        try:
            socket.setdefaulttimeout(3)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
            return True
        except Exception:
            return False

    def _poll(self):
        while self._running:
            status = self._check_connection()
            if status != self.is_online:
                self.is_online = status
                self.dispatch('on_connectivity_change', status)
            time.sleep(5)

    def on_connectivity_change(self, *args):
        pass
