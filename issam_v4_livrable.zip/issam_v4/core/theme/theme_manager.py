"""
ISSAM Design System — Production Design Tokens
"""
from kivymd.theming import ThemeManager as KivyMDTheme

# ── Color Palette ──────────────────────────────────────────────────────────────
BG        = (0.012, 0.043, 0.078, 1)   # #030B14  page background
CARD1     = (0.039, 0.086, 0.157, 1)   # #0A1628  card level 1
CARD2     = (0.059, 0.122, 0.208, 1)   # #0F1F35  card level 2
CARD3     = (0.075, 0.145, 0.247, 1)   # #132540  card level 3 / hover

BLUE      = (0.231, 0.510, 0.965, 1)   # #3B82F6
BLUE_DK   = (0.114, 0.306, 0.847, 1)  # #1D4ED8
PURPLE    = (0.545, 0.361, 0.965, 1)  # #8B5CF6
CYAN      = (0.024, 0.714, 0.831, 1)  # #06B6D4
GREEN     = (0.063, 0.725, 0.506, 1)  # #10B981
AMBER     = (0.961, 0.620, 0.043, 1)  # #F59E0B
RED       = (0.937, 0.267, 0.267, 1)  # #EF4444
PINK      = (0.925, 0.200, 0.557, 1)  # #EC3047

T1        = (0.945, 0.961, 0.980, 1)  # #F1F5F9  primary text
T2        = (0.580, 0.639, 0.722, 1)  # #94A3B8  secondary text
T3        = (0.278, 0.353, 0.416, 1)  # #475569  muted text
BORDER    = (0.118, 0.161, 0.231, 1)  # #1E293B  dividers / borders

BLUE_A    = (0.231, 0.510, 0.965, 0.15)  # blue tint background
GREEN_A   = (0.063, 0.725, 0.506, 0.15)
AMBER_A   = (0.961, 0.620, 0.043, 0.15)
RED_A     = (0.937, 0.267, 0.267, 0.15)
PURPLE_A  = (0.545, 0.361, 0.965, 0.15)


def grade_color(val):
    """Return color tuple for a grade value."""
    if val is None:
        return T3
    try:
        v = float(val)
        if v >= 16: return GREEN
        if v >= 12: return BLUE
        if v >= 8:  return AMBER
        return RED
    except Exception:
        return T3


def grade_bg_color(val):
    """Return tinted background for a grade value."""
    if val is None:
        return CARD2
    try:
        v = float(val)
        if v >= 16: return GREEN_A
        if v >= 12: return BLUE_A
        if v >= 8:  return AMBER_A
        return RED_A
    except Exception:
        return CARD2


class ThemeManager:
    @classmethod
    def apply(cls, app):
        app.theme_cls.theme_style = "Dark"
        app.theme_cls.primary_palette = "Blue"
        app.theme_cls.primary_hue = "600"
