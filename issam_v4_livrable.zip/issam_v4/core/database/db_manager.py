"""
DatabaseManager — SQLite Offline-First, Thread-Safe
All writes tagged pending_sync → picked up by SyncManager
"""
import sqlite3
import uuid
import hashlib
import threading
import json
from datetime import datetime
from pathlib import Path


DB_PATH = Path("issam_local.db")


class DatabaseManager:
    def __init__(self):
        self._lock = threading.Lock()
        self.conn   = None

    # ─────────────────────────── INIT ─────────────────────────────────────────

    def initialize(self):
        self.conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")   # better concurrency
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._create_tables()
        print("[DB] Initialized — WAL mode on")

    def _cur(self):
        return self.conn.cursor()

    def _create_tables(self):
        with self._lock:
            c = self._cur()
            c.executescript("""
            CREATE TABLE IF NOT EXISTS utilisateur (
                uuid TEXT PRIMARY KEY,
                nom TEXT NOT NULL,
                prenom TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                mot_de_passe_hash TEXT NOT NULL,
                role TEXT DEFAULT 'enseignant',
                actif INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS matiere (
                uuid TEXT PRIMARY KEY,
                enseignant_uuid TEXT NOT NULL,
                nom TEXT NOT NULL,
                code TEXT NOT NULL,
                coefficient REAL DEFAULT 1.0,
                actif INTEGER DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS classe (
                uuid TEXT PRIMARY KEY,
                enseignant_uuid TEXT NOT NULL,
                nom TEXT NOT NULL,
                niveau TEXT NOT NULL,
                annee_scolaire TEXT NOT NULL,
                actif INTEGER DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS eleve (
                uuid TEXT PRIMARY KEY,
                classe_uuid TEXT NOT NULL,
                matricule TEXT NOT NULL,
                nom TEXT NOT NULL,
                prenom TEXT NOT NULL,
                date_naissance TEXT,
                sexe TEXT,
                actif INTEGER DEFAULT 1,
                FOREIGN KEY(classe_uuid) REFERENCES classe(uuid)
            );

            CREATE TABLE IF NOT EXISTS enseigne (
                enseignant_uuid TEXT NOT NULL,
                classe_uuid TEXT NOT NULL,
                matiere_uuid TEXT NOT NULL,
                PRIMARY KEY (enseignant_uuid, classe_uuid, matiere_uuid)
            );

            CREATE TABLE IF NOT EXISTS evaluation (
                uuid TEXT PRIMARY KEY,
                enseignant_uuid TEXT NOT NULL,
                matiere_uuid TEXT NOT NULL,
                classe_uuid TEXT NOT NULL,
                nom TEXT NOT NULL,
                type TEXT DEFAULT 'Contrôle',
                date_debut TEXT,
                date_fin TEXT,
                bareme REAL DEFAULT 20.0,
                actif INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                sync_status TEXT DEFAULT 'synced',
                FOREIGN KEY(matiere_uuid) REFERENCES matiere(uuid),
                FOREIGN KEY(classe_uuid) REFERENCES classe(uuid)
            );

            CREATE TABLE IF NOT EXISTS note (
                uuid TEXT PRIMARY KEY,
                evaluation_uuid TEXT NOT NULL,
                eleve_uuid TEXT NOT NULL,
                enseignant_uuid TEXT NOT NULL,
                valeur REAL,
                appreciation TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                sync_status TEXT DEFAULT 'pending_sync',
                sync_attempts INTEGER DEFAULT 0,
                sync_error TEXT DEFAULT '',
                FOREIGN KEY(evaluation_uuid) REFERENCES evaluation(uuid),
                FOREIGN KEY(eleve_uuid) REFERENCES eleve(uuid)
            );

            CREATE TABLE IF NOT EXISTS sync_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at TEXT,
                finished_at TEXT,
                notes_synced INTEGER DEFAULT 0,
                notes_failed INTEGER DEFAULT 0,
                error_message TEXT DEFAULT ''
            );
            """)
            self.conn.commit()
        self._run_migrations()

    # ─────────────────────────── MIGRATIONS ───────────────────────────────────

    def _run_migrations(self):
        """Add missing columns to existing DBs without breaking them."""
        with self._lock:
            c = self._cur()
            # Add enseignant_uuid to classe if missing
            try:
                c.execute("ALTER TABLE classe ADD COLUMN enseignant_uuid TEXT NOT NULL DEFAULT ''")
                self.conn.commit()
            except Exception:
                pass
            # Add enseignant_uuid to matiere if missing
            try:
                c.execute("ALTER TABLE matiere ADD COLUMN enseignant_uuid TEXT NOT NULL DEFAULT ''")
                self.conn.commit()
            except Exception:
                pass
            # Add enseignant_uuid to evaluation if missing
            try:
                c.execute("ALTER TABLE evaluation ADD COLUMN enseignant_uuid TEXT NOT NULL DEFAULT ''")
                self.conn.commit()
            except Exception:
                pass

    # ─────────────────────────── SEED (no-op — clean slate per user) ──────────

    def seed_demo_data(self):
        """No-op: each teacher starts with a clean empty account."""
        pass

    # ─────────────────────────── READ ─────────────────────────────────────────

    def get_user_by_email(self, email):
        with self._lock:
            c = self._cur()
            c.execute("SELECT * FROM utilisateur WHERE email=?", (email,))
            return c.fetchone()

    def get_classes(self, enseignant_uuid=None):
        with self._lock:
            c = self._cur()
            if enseignant_uuid:
                c.execute("SELECT * FROM classe WHERE actif=1 AND enseignant_uuid=? ORDER BY niveau", (enseignant_uuid,))
            else:
                c.execute("SELECT * FROM classe WHERE actif=1 ORDER BY niveau")
            return c.fetchall()

    def get_students_by_class(self, classe_uuid):
        with self._lock:
            c = self._cur()
            c.execute("""
                SELECT e.*,
                    ROUND(AVG(n.valeur), 2) as moyenne
                FROM eleve e
                LEFT JOIN note n ON n.eleve_uuid = e.uuid
                WHERE e.classe_uuid = ? AND e.actif = 1
                GROUP BY e.uuid
                ORDER BY e.nom
            """, (classe_uuid,))
            return c.fetchall()

    def get_evaluations(self, classe_uuid=None):
        with self._lock:
            c = self._cur()
            if classe_uuid:
                c.execute("""
                    SELECT ev.*, m.nom as matiere_nom, cl.nom as classe_nom
                    FROM evaluation ev
                    JOIN matiere m  ON ev.matiere_uuid = m.uuid
                    JOIN classe  cl ON ev.classe_uuid  = cl.uuid
                    WHERE ev.classe_uuid = ? AND ev.actif = 1
                    ORDER BY ev.date_debut DESC
                """, (classe_uuid,))
            else:
                c.execute("""
                    SELECT ev.*, m.nom as matiere_nom, cl.nom as classe_nom
                    FROM evaluation ev
                    JOIN matiere m  ON ev.matiere_uuid = m.uuid
                    JOIN classe  cl ON ev.classe_uuid  = cl.uuid
                    WHERE ev.actif = 1
                    ORDER BY ev.date_debut DESC
                """)
            return c.fetchall()

    def get_notes_for_evaluation(self, evaluation_uuid):
        with self._lock:
            c = self._cur()
            c.execute("""
                SELECT n.*, e.nom as eleve_nom, e.prenom as eleve_prenom,
                       e.matricule, e.sexe
                FROM note n
                JOIN eleve e ON n.eleve_uuid = e.uuid
                WHERE n.evaluation_uuid = ?
                ORDER BY e.nom
            """, (evaluation_uuid,))
            return c.fetchall()

    def get_note_count_for_eval(self, evaluation_uuid):
        with self._lock:
            c = self._cur()
            c.execute("""SELECT COUNT(*) FROM note
                         WHERE evaluation_uuid=? AND valeur IS NOT NULL""",
                      (evaluation_uuid,))
            return c.fetchone()[0]

    def get_student_count_for_class(self, classe_uuid):
        with self._lock:
            c = self._cur()
            c.execute("SELECT COUNT(*) FROM eleve WHERE classe_uuid=? AND actif=1",
                      (classe_uuid,))
            return c.fetchone()[0]

    def get_global_stats(self, enseignant_uuid=None):
        with self._lock:
            c = self._cur()
            if enseignant_uuid:
                c.execute("SELECT COUNT(*) FROM classe WHERE actif=1 AND enseignant_uuid=?", (enseignant_uuid,))
                nb_classes = c.fetchone()[0]
                c.execute("""SELECT COUNT(*) FROM eleve e
                    JOIN classe cl ON e.classe_uuid=cl.uuid
                    WHERE e.actif=1 AND cl.enseignant_uuid=?""", (enseignant_uuid,))
                nb_eleves = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM evaluation WHERE actif=1 AND enseignant_uuid=?", (enseignant_uuid,))
                nb_evals = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM note WHERE valeur IS NOT NULL AND enseignant_uuid=?", (enseignant_uuid,))
                nb_notes = c.fetchone()[0]
                c.execute("SELECT AVG(valeur) FROM note WHERE valeur IS NOT NULL AND enseignant_uuid=?", (enseignant_uuid,))
            else:
                c.execute("SELECT COUNT(*) FROM classe WHERE actif=1")
                nb_classes = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM eleve WHERE actif=1")
                nb_eleves = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM evaluation WHERE actif=1")
                nb_evals = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM note WHERE valeur IS NOT NULL")
                nb_notes = c.fetchone()[0]
                c.execute("SELECT AVG(valeur) FROM note WHERE valeur IS NOT NULL")
            avg = c.fetchone()[0] or 0.0
        return {
            'classes':     nb_classes,
            'eleves':      nb_eleves,
            'evaluations': nb_evals,
            'notes':       nb_notes,
            'moyenne':     round(float(avg), 2),
        }

    def get_sync_stats(self):
        with self._lock:
            c = self._cur()
            c.execute("SELECT COUNT(*) FROM note WHERE sync_status='pending_sync'")
            pending = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM note WHERE sync_status='synced'")
            synced  = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM note WHERE sync_status='error'")
            errors  = c.fetchone()[0]
        return {'pending': pending, 'synced': synced, 'errors': errors}

    def get_note_distribution(self):
        with self._lock:
            c = self._cur()
            c.execute("SELECT valeur FROM note WHERE valeur IS NOT NULL")
            notes = [row[0] for row in c.fetchall()]
        total = len(notes) or 1
        return {
            'excellent':   round(sum(1 for n in notes if n >= 16) / total * 100),
            'bien':        round(sum(1 for n in notes if 12 <= n < 16) / total * 100),
            'passable':    round(sum(1 for n in notes if 8 <= n < 12) / total * 100),
            'insuffisant': round(sum(1 for n in notes if n < 8) / total * 100),
        }

    # ─────────────────────────── WRITE ────────────────────────────────────────

    def upsert_note(self, evaluation_uuid, eleve_uuid, enseignant_uuid, valeur,
                    appreciation=''):
        now = datetime.now().isoformat()
        with self._lock:
            c = self._cur()
            c.execute("""SELECT uuid FROM note
                         WHERE evaluation_uuid=? AND eleve_uuid=?""",
                      (evaluation_uuid, eleve_uuid))
            row = c.fetchone()
            if row:
                c.execute("""UPDATE note
                             SET valeur=?, appreciation=?, updated_at=?,
                                 sync_status='pending_sync', sync_attempts=0, sync_error=''
                             WHERE uuid=?""",
                          (valeur, appreciation, now, row[0]))
                note_uuid = row[0]
            else:
                note_uuid = str(uuid.uuid4())
                c.execute("""INSERT INTO note
                    (uuid,evaluation_uuid,eleve_uuid,enseignant_uuid,
                     valeur,appreciation,sync_status)
                    VALUES (?,?,?,?,?,?,'pending_sync')""",
                    (note_uuid, evaluation_uuid, eleve_uuid,
                     enseignant_uuid, valeur, appreciation))
            self.conn.commit()
        return note_uuid

    # ─────────────────────────── SYNC HELPERS ─────────────────────────────────

    def get_pending_notes_for_sync(self, limit=50):
        """Return notes ready to push to the server."""
        with self._lock:
            c = self._cur()
            c.execute("""
                SELECT n.uuid, n.evaluation_uuid, n.eleve_uuid, n.enseignant_uuid,
                       n.valeur, n.appreciation, n.updated_at, n.sync_attempts,
                       e.matricule, e.nom as eleve_nom, e.prenom as eleve_prenom,
                       ev.nom as eval_nom, ev.bareme,
                       cl.nom as classe_nom, m.nom as matiere_nom
                FROM note n
                JOIN eleve      e  ON n.eleve_uuid      = e.uuid
                JOIN evaluation ev ON n.evaluation_uuid = ev.uuid
                JOIN classe     cl ON ev.classe_uuid    = cl.uuid
                JOIN matiere    m  ON ev.matiere_uuid   = m.uuid
                WHERE n.sync_status = 'pending_sync'
                  AND n.sync_attempts < 3
                ORDER BY n.updated_at ASC
                LIMIT ?
            """, (limit,))
            return [dict(row) for row in c.fetchall()]

    def mark_note_synced(self, note_uuid):
        with self._lock:
            c = self._cur()
            c.execute("""UPDATE note SET sync_status='synced', sync_error=''
                         WHERE uuid=?""", (note_uuid,))
            self.conn.commit()

    def mark_note_error(self, note_uuid, error_msg=''):
        with self._lock:
            c = self._cur()
            c.execute("""UPDATE note
                         SET sync_status='error', sync_error=?,
                             sync_attempts = sync_attempts + 1
                         WHERE uuid=?""", (str(error_msg)[:200], note_uuid))
            self.conn.commit()

    def increment_sync_attempt(self, note_uuid):
        with self._lock:
            c = self._cur()
            c.execute("""UPDATE note SET sync_attempts = sync_attempts + 1
                         WHERE uuid=?""", (note_uuid,))
            self.conn.commit()

    def reset_errors_to_pending(self):
        """Retry errored notes on next sync cycle."""
        with self._lock:
            c = self._cur()
            c.execute("""UPDATE note SET sync_status='pending_sync',
                             sync_attempts=0, sync_error=''
                         WHERE sync_status='error'""")
            self.conn.commit()

    def mark_all_synced(self):
        with self._lock:
            c = self._cur()
            c.execute("UPDATE note SET sync_status='synced' WHERE sync_status='pending_sync'")
            self.conn.commit()

    def log_sync_result(self, synced, failed, error_msg=''):
        with self._lock:
            c = self._cur()
            now = datetime.now().isoformat()
            c.execute("""INSERT INTO sync_log
                (started_at, finished_at, notes_synced, notes_failed, error_message)
                VALUES (?,?,?,?,?)""",
                (now, now, synced, failed, error_msg))
            self.conn.commit()

    def create_user(self, uid, email, prenom, nom, pwd_hash, role='enseignant'):
        """Créer un utilisateur local."""
        with self._lock:
            c = self._cur()
            c.execute("""INSERT OR IGNORE INTO utilisateur
                (uuid, nom, prenom, email, mot_de_passe_hash, role)
                VALUES (?, ?, ?, ?, ?, ?)""",
                (uid, nom, prenom, email, pwd_hash, role))
            self.conn.commit()

    def get_classes_with_counts(self, enseignant_uuid=None):
        """Classes avec nombre d'élèves — filtrées par enseignant."""
        with self._lock:
            c = self._cur()
            if enseignant_uuid:
                c.execute("""
                    SELECT cl.*, COUNT(e.uuid) as student_count
                    FROM classe cl
                    LEFT JOIN eleve e ON e.classe_uuid = cl.uuid AND e.actif=1
                    WHERE cl.actif=1 AND cl.enseignant_uuid=?
                    GROUP BY cl.uuid
                    ORDER BY cl.niveau, cl.nom
                """, (enseignant_uuid,))
            else:
                c.execute("""
                    SELECT cl.*, COUNT(e.uuid) as student_count
                    FROM classe cl
                    LEFT JOIN eleve e ON e.classe_uuid = cl.uuid AND e.actif=1
                    WHERE cl.actif=1
                    GROUP BY cl.uuid
                    ORDER BY cl.niveau, cl.nom
                """)
            return [dict(row) for row in c.fetchall()]

    def get_evaluations_with_meta(self, classe_uuid=None, enseignant_uuid=None):
        """Évaluations enrichies avec nom classe et matière — filtrées par enseignant."""
        with self._lock:
            c = self._cur()
            if classe_uuid and enseignant_uuid:
                c.execute("""
                    SELECT ev.*, cl.nom as classe_nom, m.nom as matiere_nom
                    FROM evaluation ev
                    JOIN classe cl ON ev.classe_uuid = cl.uuid
                    JOIN matiere m ON ev.matiere_uuid = m.uuid
                    WHERE ev.actif=1 AND ev.classe_uuid=? AND ev.enseignant_uuid=?
                    ORDER BY ev.created_at DESC
                """, (classe_uuid, enseignant_uuid))
            elif classe_uuid:
                c.execute("""
                    SELECT ev.*, cl.nom as classe_nom, m.nom as matiere_nom
                    FROM evaluation ev
                    JOIN classe cl ON ev.classe_uuid = cl.uuid
                    JOIN matiere m ON ev.matiere_uuid = m.uuid
                    WHERE ev.actif=1 AND ev.classe_uuid=?
                    ORDER BY ev.created_at DESC
                """, (classe_uuid,))
            elif enseignant_uuid:
                c.execute("""
                    SELECT ev.*, cl.nom as classe_nom, m.nom as matiere_nom
                    FROM evaluation ev
                    JOIN classe cl ON ev.classe_uuid = cl.uuid
                    JOIN matiere m ON ev.matiere_uuid = m.uuid
                    WHERE ev.actif=1 AND ev.enseignant_uuid=?
                    ORDER BY ev.created_at DESC
                """, (enseignant_uuid,))
            else:
                c.execute("""
                    SELECT ev.*, cl.nom as classe_nom, m.nom as matiere_nom
                    FROM evaluation ev
                    JOIN classe cl ON ev.classe_uuid = cl.uuid
                    JOIN matiere m ON ev.matiere_uuid = m.uuid
                    WHERE ev.actif=1
                    ORDER BY ev.created_at DESC
                """)
            return [dict(row) for row in c.fetchall()]

    def get_students_with_averages(self, classe_uuid):
        """Élèves d'une classe avec leur moyenne calculée."""
        with self._lock:
            c = self._cur()
            c.execute("""
                SELECT e.*,
                       ROUND(AVG(n.valeur), 2) as moyenne,
                       COUNT(n.uuid) as note_count
                FROM eleve e
                LEFT JOIN note n ON n.eleve_uuid = e.uuid
                WHERE e.classe_uuid=? AND e.actif=1
                GROUP BY e.uuid
                ORDER BY moyenne DESC NULLS LAST, e.nom ASC
            """, (classe_uuid,))
            return [dict(row) for row in c.fetchall()]

    def get_recent_sync_logs(self, limit=10):
        """Derniers logs de synchronisation."""
        with self._lock:
            c = self._cur()
            c.execute("""
                SELECT * FROM sync_log
                ORDER BY id DESC LIMIT ?
            """, (limit,))
            return [dict(row) for row in c.fetchall()]

    # ─────────────────────────── CRUD CLASSES ─────────────────────────────────

    def create_classe(self, enseignant_uuid, nom, niveau, annee_scolaire):
        """Créer une nouvelle classe pour un enseignant."""
        cl_uuid = str(uuid.uuid4())
        with self._lock:
            c = self._cur()
            c.execute("""INSERT INTO classe (uuid, enseignant_uuid, nom, niveau, annee_scolaire)
                VALUES (?,?,?,?,?)""",
                (cl_uuid, enseignant_uuid, nom, niveau, annee_scolaire))
            self.conn.commit()
        return cl_uuid

    def update_classe(self, classe_uuid, nom, niveau, annee_scolaire):
        """Modifier une classe."""
        with self._lock:
            c = self._cur()
            c.execute("""UPDATE classe SET nom=?, niveau=?, annee_scolaire=?
                WHERE uuid=?""", (nom, niveau, annee_scolaire, classe_uuid))
            self.conn.commit()

    def delete_classe(self, classe_uuid):
        """Supprimer (soft-delete) une classe et ses élèves."""
        with self._lock:
            c = self._cur()
            c.execute("UPDATE classe SET actif=0 WHERE uuid=?", (classe_uuid,))
            c.execute("UPDATE eleve SET actif=0 WHERE classe_uuid=?", (classe_uuid,))
            self.conn.commit()

    # ─────────────────────────── CRUD ÉLÈVES ──────────────────────────────────

    def add_student(self, classe_uuid, prenom, nom, matricule, sexe='M', date_naissance=None):
        """Ajouter un élève."""
        st_uuid = str(uuid.uuid4())
        with self._lock:
            c = self._cur()
            c.execute("""INSERT INTO eleve
                (uuid, classe_uuid, matricule, nom, prenom, date_naissance, sexe)
                VALUES (?,?,?,?,?,?,?)""",
                (st_uuid, classe_uuid, matricule, nom, prenom, date_naissance, sexe))
            self.conn.commit()
        return st_uuid

    def update_student(self, eleve_uuid, prenom, nom, matricule, sexe='M', date_naissance=None):
        """Modifier un élève."""
        with self._lock:
            c = self._cur()
            c.execute("""UPDATE eleve SET prenom=?, nom=?, matricule=?, sexe=?, date_naissance=?
                WHERE uuid=?""", (prenom, nom, matricule, sexe, date_naissance, eleve_uuid))
            self.conn.commit()

    def delete_student(self, eleve_uuid):
        """Supprimer (soft-delete) un élève."""
        with self._lock:
            c = self._cur()
            c.execute("UPDATE eleve SET actif=0 WHERE uuid=?", (eleve_uuid,))
            self.conn.commit()

    # ─────────────────────────── CRUD ÉVALUATIONS ─────────────────────────────

    def create_evaluation(self, enseignant_uuid, matiere_uuid, classe_uuid, nom,
                          ev_type='Contrôle', date_debut=None, date_fin=None, bareme=20.0):
        """Créer une nouvelle évaluation."""
        ev_uuid = str(uuid.uuid4())
        now = datetime.now().isoformat()
        with self._lock:
            c = self._cur()
            c.execute("""INSERT INTO evaluation
                (uuid, enseignant_uuid, matiere_uuid, classe_uuid, nom, type,
                 date_debut, date_fin, bareme, sync_status, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,'pending_sync',?,?)""",
                (ev_uuid, enseignant_uuid, matiere_uuid, classe_uuid, nom, ev_type,
                 date_debut or now[:10], date_fin or now[:10], bareme, now, now))
            self.conn.commit()
        return ev_uuid

    def update_evaluation(self, ev_uuid, nom, ev_type, date_debut, date_fin, bareme):
        """Modifier une évaluation."""
        now = datetime.now().isoformat()
        with self._lock:
            c = self._cur()
            c.execute("""UPDATE evaluation SET nom=?, type=?, date_debut=?, date_fin=?,
                bareme=?, updated_at=? WHERE uuid=?""",
                (nom, ev_type, date_debut, date_fin, bareme, now, ev_uuid))
            self.conn.commit()

    def delete_evaluation(self, ev_uuid):
        """Supprimer (soft-delete) une évaluation."""
        with self._lock:
            c = self._cur()
            c.execute("UPDATE evaluation SET actif=0 WHERE uuid=?", (ev_uuid,))
            self.conn.commit()

    # ─────────────────────────── CRUD MATIÈRES ────────────────────────────────

    def get_matieres(self, enseignant_uuid=None):
        """Liste des matières de l'enseignant."""
        with self._lock:
            c = self._cur()
            if enseignant_uuid:
                c.execute("SELECT * FROM matiere WHERE actif=1 AND enseignant_uuid=? ORDER BY nom",
                          (enseignant_uuid,))
            else:
                c.execute("SELECT * FROM matiere WHERE actif=1 ORDER BY nom")
            return [dict(row) for row in c.fetchall()]

    def create_matiere(self, enseignant_uuid, nom, code, coefficient=1.0):
        """Créer une matière."""
        mat_uuid = str(uuid.uuid4())
        with self._lock:
            c = self._cur()
            c.execute("""INSERT INTO matiere (uuid, enseignant_uuid, nom, code, coefficient)
                VALUES (?,?,?,?,?)""", (mat_uuid, enseignant_uuid, nom, code, coefficient))
            self.conn.commit()
        return mat_uuid

    def delete_matiere(self, mat_uuid):
        """Supprimer (soft-delete) une matière."""
        with self._lock:
            c = self._cur()
            c.execute("UPDATE matiere SET actif=0 WHERE uuid=?", (mat_uuid,))
            self.conn.commit()

