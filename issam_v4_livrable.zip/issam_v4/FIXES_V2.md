# ISSAM v2.0 — Corrections appliquées

## 🔴 Bugs critiques corrigés

### 1. Firebase désactivé (USE_FIREBASE = False)
- **Avant** : `USE_FIREBASE = False` avec un message d'erreur confus dans l'UI
- **Après** : Mode offline complet et transparent — l'app fonctionne parfaitement sans Firebase
- **Comptes démo** : `enseignant@example.com` / `password123` | `admin@issam.cm` / `admin123`

### 2. Crashes sur clic de boutons
- **Cause** : Utilisation de `on_release=lambda` dans les constructeurs KivyMD (`MDRaisedButton`, `MDIconButton`)  
  → KivyMD réinitialise les handlers lors du rendu, écrasant les lambdas passés en kwargs
- **Fix** : Remplacement systématique par `.bind(on_release=...)` après création
- **Fichiers corrigés** :
  - `screens/auth/login_screen.py`
  - `screens/grades/grades_screen.py`
  - `screens/evaluations/evaluations_screen.py`
  - `screens/sync_screen/sync_screen.py`
  - `screens/settings/settings_screen.py`
  - `widgets/bottom_nav.py`

### 3. Navigation plantant l'app
- **Cause** : `setattr(self.manager, 'current', 'screen')` sans try/except dans des lambdas d'événements
- **Fix** : Ajout de méthodes `_go()` / `_go_back()` avec `try/except` dans chaque screen

### 4. Inscription locale non fonctionnelle
- **Avant** : Mode offline affichait "Firebase requis pour créer un compte"
- **Après** : `auth_service._local_sign_up()` crée un vrai compte SQLite local
- **Méthode ajoutée** : `db_manager.create_user()`

### 5. Données fictives en dur dans classes_screen
- **Avant** : `student_counts = [10, 8, 0, 0]` codés en dur
- **Après** : Requête réelle via `db_manager.get_classes_with_counts()`

## 🟡 Améliorations fonctionnelles

### Gestion d'erreurs globale
- `sys.excepthook` personnalisé dans `main.py` — les erreurs non critiques ne crashent plus l'app

### Évaluations — Création fonctionnelle
- Popup `CreateEvalPopup` dans `evaluations_screen.py` avec sélection type, date, barème
- Méthode `db_manager.create_evaluation()` ajoutée

### Réinitialisation mot de passe offline
- Mode local : envoi simulé avec confirmation visuelle
- Message explicatif pour l'utilisateur

### Vérification email offline
- Mode local : vérification automatiquement accordée (skip possible)
- Bouton "Continuer sans vérification" toujours disponible

## 📦 Méthodes DB ajoutées

```python
db_manager.create_user(uid, email, prenom, nom, pwd_hash, role)
db_manager.get_classes_with_counts()
db_manager.get_evaluations_with_meta(classe_uuid=None)
db_manager.get_students_with_averages(classe_uuid)
db_manager.get_recent_sync_logs(limit=10)
db_manager.create_evaluation(matiere_uuid, classe_uuid, nom, ...)
db_manager.get_matieres()
db_manager.add_student(classe_uuid, prenom, nom, matricule, ...)
```

## 🚀 Lancement

```bash
cd issam_v2
pip install kivy kivymd requests --break-system-packages
python main.py
```

**Compte démo** : `enseignant@example.com` / `password123`
