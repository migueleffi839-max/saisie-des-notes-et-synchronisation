"""
Evaluations Screen — CRUD complet, données filtrées par enseignant connecté
ISSAM v4.0
"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton, MDRaisedButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.dialog import MDDialog
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.app import App
from datetime import date
from widgets.bottom_nav import BottomNavBar
from core.theme.theme_manager import (
    BG, CARD1, CARD2, BLUE, BLUE_A, PURPLE, PURPLE_A,
    GREEN, GREEN_A, AMBER, AMBER_A, RED, RED_A, T1, T2, T3
)

TYPE_CONFIG = {
    'Devoir Maison': ('📋', BLUE,   BLUE_A),
    'Contrôle':      ('📝', PURPLE, PURPLE_A),
    'Composition':   ('📄', GREEN,  GREEN_A),
    'Examen':        ('🏆', AMBER,  AMBER_A),
}
EV_TYPES = ['Contrôle', 'Devoir Maison', 'Composition', 'Examen']


class EvalCard(MDCard):
    def __init__(self, ev, on_delete, on_edit, **kwargs):
        super().__init__(**kwargs)
        self._ev = ev
        self.orientation     = 'horizontal'
        self.padding         = [dp(14), dp(14)]
        self.spacing         = dp(14)
        self.md_bg_color     = CARD1
        self.radius          = [dp(20)]
        self.size_hint_y     = None
        self.height          = dp(86)
        self.elevation       = 0
        self.ripple_behavior = True
        self.bind(on_release=lambda x: self._open())

        ev_type = ev.get('type', 'Contrôle')
        icon, color, bg = TYPE_CONFIG.get(ev_type, ('📝', BLUE, BLUE_A))

        badge = MDCard(md_bg_color=bg, radius=[dp(14)],
                        size_hint=(None, None), size=(dp(48), dp(48)),
                        pos_hint={'center_y': 0.5})
        badge.add_widget(MDLabel(text=icon, halign='center', font_style='H6'))

        info = MDBoxLayout(orientation='vertical', spacing=dp(4))
        info.add_widget(MDLabel(text=ev.get('nom', '—'), font_style='Subtitle2',
                                 theme_text_color='Custom', text_color=T1))
        info.add_widget(MDLabel(
            text=f"{ev.get('classe_nom','—')}  ·  {ev.get('matiere_nom','—')}",
            font_style='Caption', theme_text_color='Custom', text_color=T2,
            size_hint_y=None, height=dp(20),
        ))
        info.add_widget(MDLabel(
            text=f"📅 {ev.get('date_debut','—')}  ·  /{'%.0f' % (ev.get('bareme', 20))}",
            font_style='Caption', theme_text_color='Custom', text_color=T3,
            size_hint_y=None, height=dp(16),
        ))

        actions = MDBoxLayout(orientation='horizontal', spacing=dp(2),
                               size_hint=(None, 1), width=dp(72))
        edit_btn = MDIconButton(icon='pencil', theme_icon_color='Custom', icon_color=BLUE,
                                 size_hint=(None, None), size=(dp(32), dp(32)),
                                 pos_hint={'center_y': 0.5})
        edit_btn.bind(on_release=lambda x: on_edit(ev))
        del_btn = MDIconButton(icon='delete', theme_icon_color='Custom',
                                icon_color=(0.9, 0.3, 0.3, 1),
                                size_hint=(None, None), size=(dp(32), dp(32)),
                                pos_hint={'center_y': 0.5})
        del_btn.bind(on_release=lambda x: on_delete(ev))
        actions.add_widget(edit_btn)
        actions.add_widget(del_btn)

        self.add_widget(badge)
        self.add_widget(info)
        self.add_widget(Widget())
        self.add_widget(actions)

    def _open(self):
        try:
            app = App.get_running_app()
            app.selected_evaluation = dict(self._ev)
            app.root.current = 'grades'
        except Exception as e:
            print(f"[EvalCard] Nav error: {e}")


class EvalFormContent(MDBoxLayout):
    def __init__(self, classes, matieres, ev=None, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = dp(10)
        self.padding = [dp(4), dp(8)]
        self.size_hint_y = None
        self.height = dp(380)

        self._classes = classes
        self._matieres = matieres

        self.nom_field = MDTextField(
            hint_text='Nom (ex: Contrôle N°1)',
            mode='rectangle',
            text=ev.get('nom', '') if ev else '',
        )
        self.add_widget(self.nom_field)

        # Type selector
        self._type_idx = 0
        if ev:
            t = ev.get('type', EV_TYPES[0])
            self._type_idx = EV_TYPES.index(t) if t in EV_TYPES else 0
        self._type_lbl = MDLabel(
            text=f'Type : {EV_TYPES[self._type_idx]}',
            font_style='Body1', theme_text_color='Custom', text_color=T1,
            size_hint_y=None, height=dp(32),
        )
        type_nav = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(40))
        pb = MDRaisedButton(text='◀', size_hint=(None, None), size=(dp(40), dp(36)))
        pb.bind(on_release=lambda x: self._prev_type())
        nb = MDRaisedButton(text='▶', size_hint=(None, None), size=(dp(40), dp(36)))
        nb.bind(on_release=lambda x: self._next_type())
        type_nav.add_widget(pb)
        type_nav.add_widget(self._type_lbl)
        type_nav.add_widget(nb)
        self.add_widget(type_nav)

        # Classe selector
        self._classe_idx = 0
        if ev and classes:
            for i, cl in enumerate(classes):
                if cl['uuid'] == ev.get('classe_uuid'):
                    self._classe_idx = i
                    break
        self._classe_lbl = MDLabel(
            text=f'Classe : {classes[self._classe_idx]["nom"] if classes else "Aucune"}',
            font_style='Body1', theme_text_color='Custom', text_color=T1,
            size_hint_y=None, height=dp(32),
        )
        cl_nav = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(40))
        pcb = MDRaisedButton(text='◀', size_hint=(None, None), size=(dp(40), dp(36)))
        pcb.bind(on_release=lambda x: self._prev_classe())
        ncb = MDRaisedButton(text='▶', size_hint=(None, None), size=(dp(40), dp(36)))
        ncb.bind(on_release=lambda x: self._next_classe())
        cl_nav.add_widget(pcb)
        cl_nav.add_widget(self._classe_lbl)
        cl_nav.add_widget(ncb)
        self.add_widget(cl_nav)

        # Matière selector
        self._mat_idx = 0
        if ev and matieres:
            for i, m in enumerate(matieres):
                if m['uuid'] == ev.get('matiere_uuid'):
                    self._mat_idx = i
                    break
        self._mat_lbl = MDLabel(
            text=f'Matière : {matieres[self._mat_idx]["nom"] if matieres else "Aucune"}',
            font_style='Body1', theme_text_color='Custom', text_color=T1,
            size_hint_y=None, height=dp(32),
        )
        mat_nav = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(40))
        pmb = MDRaisedButton(text='◀', size_hint=(None, None), size=(dp(40), dp(36)))
        pmb.bind(on_release=lambda x: self._prev_mat())
        nmb = MDRaisedButton(text='▶', size_hint=(None, None), size=(dp(40), dp(36)))
        nmb.bind(on_release=lambda x: self._next_mat())
        mat_nav.add_widget(pmb)
        mat_nav.add_widget(self._mat_lbl)
        mat_nav.add_widget(nmb)
        self.add_widget(mat_nav)

        # Date et barème
        self.date_field = MDTextField(
            hint_text='Date (YYYY-MM-DD)',
            mode='rectangle',
            text=ev.get('date_debut', str(date.today())) if ev else str(date.today()),
        )
        self.bareme_field = MDTextField(
            hint_text='Barème (ex: 20)',
            mode='rectangle',
            text=str(int(ev.get('bareme', 20))) if ev else '20',
        )
        self.add_widget(self.date_field)
        self.add_widget(self.bareme_field)

    def _prev_type(self):
        self._type_idx = (self._type_idx - 1) % len(EV_TYPES)
        self._type_lbl.text = f'Type : {EV_TYPES[self._type_idx]}'

    def _next_type(self):
        self._type_idx = (self._type_idx + 1) % len(EV_TYPES)
        self._type_lbl.text = f'Type : {EV_TYPES[self._type_idx]}'

    def _prev_classe(self):
        if not self._classes:
            return
        self._classe_idx = (self._classe_idx - 1) % len(self._classes)
        self._classe_lbl.text = f'Classe : {self._classes[self._classe_idx]["nom"]}'

    def _next_classe(self):
        if not self._classes:
            return
        self._classe_idx = (self._classe_idx + 1) % len(self._classes)
        self._classe_lbl.text = f'Classe : {self._classes[self._classe_idx]["nom"]}'

    def _prev_mat(self):
        if not self._matieres:
            return
        self._mat_idx = (self._mat_idx - 1) % len(self._matieres)
        self._mat_lbl.text = f'Matière : {self._matieres[self._mat_idx]["nom"]}'

    def _next_mat(self):
        if not self._matieres:
            return
        self._mat_idx = (self._mat_idx + 1) % len(self._matieres)
        self._mat_lbl.text = f'Matière : {self._matieres[self._mat_idx]["nom"]}'

    def get_values(self):
        try:
            bareme = float(self.bareme_field.text or '20')
        except ValueError:
            bareme = 20.0
        return {
            'nom': self.nom_field.text.strip(),
            'type': EV_TYPES[self._type_idx],
            'classe_uuid': self._classes[self._classe_idx]['uuid'] if self._classes else None,
            'matiere_uuid': self._matieres[self._mat_idx]['uuid'] if self._matieres else None,
            'date_debut': self.date_field.text.strip() or str(date.today()),
            'bareme': bareme,
        }


class EvaluationsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._dialog = None

    def on_enter(self):
        self.clear_widgets()
        self._build_ui()

    def _get_uid(self):
        app = App.get_running_app()
        return (app.current_user or {}).get('uid', '')

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *a: setattr(self._bg, 'pos', self.pos),
                   size=lambda *a: setattr(self._bg, 'size', self.size))

        app = App.get_running_app()
        uid = self._get_uid()
        try:
            evals = app.db_manager.get_evaluations_with_meta(enseignant_uuid=uid)
        except Exception as e:
            print(f"[Evals] error: {e}")
            evals = []

        root = MDBoxLayout(orientation='vertical')

        # Top bar
        topbar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(68),
                              padding=[dp(8), dp(14), dp(16), dp(4)], spacing=dp(4))
        back_btn = MDIconButton(icon='arrow-left', theme_icon_color='Custom', icon_color=T1)
        back_btn.bind(on_release=lambda x: self._go('dashboard'))
        topbar.add_widget(back_btn)

        title_box = MDBoxLayout(orientation='vertical', spacing=dp(1))
        title_box.add_widget(MDLabel(text='Évaluations', font_style='H5',
                                      theme_text_color='Custom', text_color=T1))
        title_box.add_widget(MDLabel(text=f'{len(evals)} évaluation(s)',
                                      font_style='Caption', theme_text_color='Custom', text_color=T2))
        topbar.add_widget(title_box)
        topbar.add_widget(Widget())

        add_btn = MDRaisedButton(text='+ Nouvelle', md_bg_color=BLUE,
                                  size_hint=(None, None), size=(dp(110), dp(38)),
                                  pos_hint={'center_y': 0.5})
        add_btn.bind(on_release=lambda x: self._show_add_dialog())
        topbar.add_widget(add_btn)
        root.add_widget(topbar)

        # Liste
        scroll = MDScrollView()
        content = MDBoxLayout(orientation='vertical',
                               padding=[dp(16), dp(8), dp(16), dp(80)],
                               spacing=dp(10), size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))

        if evals:
            for ev in evals:
                card = EvalCard(ev, on_delete=self._confirm_delete, on_edit=self._show_edit_dialog)
                content.add_widget(card)
        else:
            empty = MDBoxLayout(orientation='vertical', spacing=dp(12),
                                 padding=[dp(20), dp(40)], size_hint_y=None, height=dp(240))
            empty.add_widget(MDLabel(text='📋', halign='center', font_style='H2',
                                      size_hint_y=None, height=dp(70)))
            empty.add_widget(MDLabel(text='Aucune évaluation', halign='center',
                                      font_style='H6', theme_text_color='Custom', text_color=T1,
                                      size_hint_y=None, height=dp(40)))
            empty.add_widget(MDLabel(
                text='Appuyez sur "+ Nouvelle" pour créer votre première évaluation.\n'
                     '(Créez d\'abord des classes et des matières)',
                halign='center', font_style='Body2',
                theme_text_color='Custom', text_color=T2,
                size_hint_y=None, height=dp(80),
            ))
            content.add_widget(empty)

        scroll.add_widget(content)
        root.add_widget(scroll)
        root.add_widget(BottomNavBar(active_screen='evaluations'))
        self.add_widget(root)

    def _get_form_data(self):
        app = App.get_running_app()
        uid = self._get_uid()
        try:
            classes = app.db_manager.get_classes_with_counts(enseignant_uuid=uid)
        except Exception:
            classes = []
        try:
            matieres = app.db_manager.get_matieres(enseignant_uuid=uid)
        except Exception:
            matieres = []
        return classes, matieres

    def _show_add_dialog(self):
        if self._dialog:
            self._dialog.dismiss()
        classes, matieres = self._get_form_data()
        if not classes:
            self._dialog = MDDialog(
                title='Aucune classe',
                text='Créez d\'abord une classe avant d\'ajouter une évaluation.',
                buttons=[MDFlatButton(text='OK', on_release=lambda x: self._dialog.dismiss())],
            )
            self._dialog.open()
            return
        if not matieres:
            self._dialog = MDDialog(
                title='Aucune matière',
                text='Créez d\'abord une matière dans Paramètres.',
                buttons=[MDFlatButton(text='OK', on_release=lambda x: self._dialog.dismiss())],
            )
            self._dialog.open()
            return
        form = EvalFormContent(classes=classes, matieres=matieres)
        self._dialog = MDDialog(
            title='Nouvelle évaluation',
            type='custom',
            content_cls=form,
            buttons=[
                MDFlatButton(text='Annuler', on_release=lambda x: self._dialog.dismiss()),
                MDRaisedButton(text='Créer', md_bg_color=BLUE,
                               on_release=lambda x: self._do_create(form)),
            ],
        )
        self._dialog.open()

    def _do_create(self, form):
        vals = form.get_values()
        if not vals['nom'] or not vals['classe_uuid'] or not vals['matiere_uuid']:
            return
        app = App.get_running_app()
        uid = self._get_uid()
        app.db_manager.create_evaluation(
            enseignant_uuid=uid,
            matiere_uuid=vals['matiere_uuid'],
            classe_uuid=vals['classe_uuid'],
            nom=vals['nom'],
            ev_type=vals['type'],
            date_debut=vals['date_debut'],
            bareme=vals['bareme'],
        )
        self._dialog.dismiss()
        self._dialog = None
        self.on_enter()

    def _show_edit_dialog(self, ev):
        if self._dialog:
            self._dialog.dismiss()
        classes, matieres = self._get_form_data()
        form = EvalFormContent(classes=classes, matieres=matieres, ev=ev)
        self._dialog = MDDialog(
            title='Modifier l\'évaluation',
            type='custom',
            content_cls=form,
            buttons=[
                MDFlatButton(text='Annuler', on_release=lambda x: self._dialog.dismiss()),
                MDRaisedButton(text='Enregistrer', md_bg_color=BLUE,
                               on_release=lambda x: self._do_edit(ev['uuid'], form)),
            ],
        )
        self._dialog.open()

    def _do_edit(self, ev_uuid, form):
        vals = form.get_values()
        if not vals['nom']:
            return
        app = App.get_running_app()
        app.db_manager.update_evaluation(
            ev_uuid, vals['nom'], vals['type'],
            vals['date_debut'], vals['date_debut'], vals['bareme']
        )
        self._dialog.dismiss()
        self._dialog = None
        self.on_enter()

    def _confirm_delete(self, ev):
        if self._dialog:
            self._dialog.dismiss()
        self._dialog = MDDialog(
            title='Supprimer l\'évaluation ?',
            text=f'"{ev.get("nom")}" sera supprimée définitivement.',
            buttons=[
                MDFlatButton(text='Annuler', on_release=lambda x: self._dialog.dismiss()),
                MDRaisedButton(text='Supprimer', md_bg_color=(0.9, 0.3, 0.3, 1),
                               on_release=lambda x: self._do_delete(ev['uuid'])),
            ],
        )
        self._dialog.open()

    def _do_delete(self, ev_uuid):
        app = App.get_running_app()
        app.db_manager.delete_evaluation(ev_uuid)
        self._dialog.dismiss()
        self._dialog = None
        self.on_enter()

    def _go(self, screen):
        try:
            self.manager.current = screen
        except Exception as e:
            print(f"[EvaluationsScreen] Nav error: {e}")
