"""
Grade Entry Screen — Offline-First Numpad Input
Autosave to SQLite on every tap · Color-coded feedback · Progress banner
"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton, MDRaisedButton, MDFlatButton
from kivy.uix.popup import Popup
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.app import App
from kivy.clock import Clock
from kivy.animation import Animation
from core.theme.theme_manager import (
    BG, CARD1, CARD2, BLUE, BLUE_A, GREEN, GREEN_A,
    AMBER, AMBER_A, RED, RED_A, T1, T2, T3, BORDER,
    grade_color, grade_bg_color,
)


# ── Numpad Popup ──────────────────────────────────────────────────────────────

class NumpadPopup(Popup):
    """Full-screen numpad for entering grades 0–20."""

    def __init__(self, current_val, on_confirm, student_name, **kwargs):
        super().__init__(
            title='', separator_height=0,
            background='', background_color=(0, 0, 0, 0),
            size_hint=(None, None), size=(dp(290), dp(415)),
            auto_dismiss=True,
            **kwargs,
        )
        self._on_confirm = on_confirm
        self._raw = '' if current_val is None else str(current_val)

        outer = MDCard(
            orientation='vertical', padding=[dp(14), dp(12)], spacing=dp(8),
            md_bg_color=(0.055, 0.106, 0.190, 1),
            radius=[dp(26)], size_hint=(1, 1),
        )

        # ── Header ────────────────────────────────────────────────────────────
        hdr = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(30))
        hdr.add_widget(MDLabel(
            text=f'{student_name[:22]}…' if len(student_name) > 22 else student_name,
            font_style='Subtitle2', theme_text_color='Custom', text_color=T1,
        ))
        hdr.add_widget(Widget())
        close_btn = MDIconButton(
            icon='close', theme_icon_color='Custom', icon_color=T3,
        )
        close_btn.bind(on_release=lambda x: self.dismiss())
        hdr.add_widget(close_btn)
        outer.add_widget(hdr)

        # ── Display ───────────────────────────────────────────────────────────
        disp_card = MDCard(
            md_bg_color=CARD2, radius=[dp(16)],
            size_hint_y=None, height=dp(62), orientation='vertical',
            padding=[dp(8), dp(4)],
        )
        self.display_lbl = MDLabel(
            text=self._raw or '—',
            halign='center', font_style='H3',
            theme_text_color='Custom',
            text_color=grade_color(float(self._raw)) if self._raw else T3,
        )
        disp_card.add_widget(self.display_lbl)
        outer.add_widget(disp_card)

        outer.add_widget(MDLabel(
            text='Note sur 20', halign='center', font_style='Caption',
            theme_text_color='Custom', text_color=T3,
            size_hint_y=None, height=dp(14),
        ))

        # ── Numpad keys ───────────────────────────────────────────────────────
        keys = [['7','8','9'], ['4','5','6'], ['1','2','3'], ['⌫','0','.']]
        for row_keys in keys:
            row = MDBoxLayout(orientation='horizontal', spacing=dp(8),
                               size_hint_y=None, height=dp(54))
            for k in row_keys:
                is_del = (k == '⌫')
                btn = MDCard(
                    md_bg_color=(*RED[:3], 0.18) if is_del else CARD2,
                    radius=[dp(14)], size_hint=(1, 1),
                    ripple_behavior=True,
                )
                btn.add_widget(MDLabel(
                    text=k, halign='center', font_style='H5',
                    theme_text_color='Custom',
                    text_color=RED if is_del else T1,
                ))
                btn.bind(on_release=lambda x, key=k: self._press(key))
                row.add_widget(btn)
            outer.add_widget(row)

        # ── Confirm button ────────────────────────────────────────────────────
        self.confirm_btn = MDRaisedButton(
            text='✓  Valider', size_hint_x=1,
            md_bg_color=BLUE,
        )
        self.confirm_btn.bind(on_release=self._confirm)
        outer.add_widget(self.confirm_btn)
        self.content = outer

    def _press(self, key):
        if key == '⌫':
            self._raw = self._raw[:-1]
        elif key == '.' and '.' in self._raw:
            return
        elif len(self._raw) >= 4:
            return
        else:
            self._raw += key

        # Clamp to 0–20
        try:
            v = float(self._raw) if self._raw not in ('', '.') else None
            if v is not None and v > 20:
                self._raw = '20'
            color = grade_color(float(self._raw)) if self._raw and self._raw != '.' else T3
        except ValueError:
            color = T3

        self.display_lbl.text = self._raw or '—'
        self.display_lbl.text_color = color

    def _confirm(self, *_):
        try:
            v = float(self._raw) if self._raw and self._raw != '.' else None
            if v is not None and 0.0 <= v <= 20.0:
                self._on_confirm(round(v, 1))
        except ValueError:
            pass
        self.dismiss()


# ── Single student row ────────────────────────────────────────────────────────

class GradeRow(MDBoxLayout):
    def __init__(self, rank, eleve, note_val, on_save, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = dp(64)
        self.spacing = dp(10)
        self.padding = [dp(12), dp(8)]
        self.eleve   = eleve
        self._note   = note_val
        self._on_save = on_save

        with self.canvas.before:
            Color(*CARD1)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(16)])
        self.bind(pos=self._upd, size=self._upd)

        # Rank
        rank_box = MDCard(md_bg_color=CARD2, radius=[dp(10)],
                           size_hint=(None, None), size=(dp(28), dp(28)),
                           pos_hint={'center_y': 0.5})
        rank_box.add_widget(MDLabel(text=str(rank), halign='center', font_style='Caption',
                                     theme_text_color='Custom', text_color=T3))

        # Name + matric
        info = MDBoxLayout(orientation='vertical', spacing=dp(1))
        name = f"{eleve.get('nom','—')} {eleve.get('prenom','')}".strip()
        info.add_widget(MDLabel(text=name, font_style='Body2',
                                 theme_text_color='Custom', text_color=T1))
        mat = eleve.get('matricule', '')
        if mat:
            info.add_widget(MDLabel(text=mat, font_style='Caption',
                                     theme_text_color='Custom', text_color=T3))

        # Grade chip (tappable → opens numpad)
        self.grade_chip = MDCard(
            md_bg_color=grade_bg_color(note_val),
            radius=[dp(12)], size_hint=(None, None), size=(dp(68), dp(38)),
            orientation='horizontal', padding=[dp(4), dp(2)],
            pos_hint={'center_y': 0.5}, ripple_behavior=True,
        )
        self.grade_lbl = MDLabel(
            text=f'{note_val}/20' if note_val is not None else '+ Tap',
            halign='center', font_style='Subtitle2',
            theme_text_color='Custom',
            text_color=grade_color(note_val) if note_val is not None else T3,
        )
        self.grade_chip.add_widget(self.grade_lbl)
        self.grade_chip.bind(on_release=self._open_numpad)

        self.add_widget(rank_box)
        self.add_widget(info)
        self.add_widget(Widget())
        self.add_widget(self.grade_chip)

    def _upd(self, *_):
        self._bg.pos  = self.pos
        self._bg.size = self.size

    def _open_numpad(self, *_):
        name = f"{self.eleve.get('prenom','')} {self.eleve.get('nom','')}".strip()
        NumpadPopup(
            current_val=self._note,
            on_confirm=self._set_note,
            student_name=name,
        ).open()

    def _set_note(self, val):
        self._note = val
        new_bg    = grade_bg_color(val)
        new_color = grade_color(val)
        self.grade_lbl.text       = f'{val}/20'
        self.grade_lbl.text_color = new_color
        # Flash blue → settled color
        Animation(md_bg_color=(*BLUE[:3], 0.35), duration=0.12).start(self.grade_chip)
        Clock.schedule_once(
            lambda dt: Animation(md_bg_color=new_bg, duration=0.22).start(self.grade_chip), 0.15
        )
        self._on_save(self.eleve['uuid'], val)


# ── Screen ─────────────────────────────────────────────────────────────────────

class GradeEntryScreen(MDScreen):

    def on_enter(self):
        self.clear_widgets()
        self._saved_count = 0
        self._build_ui()

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *_: setattr(self._bg, 'pos',  self.pos),
                   size=lambda *_: setattr(self._bg, 'size', self.size))

        app        = App.get_running_app()
        ev         = dict(getattr(app, 'selected_evaluation', None) or {})
        eval_uuid  = ev.get('uuid')
        eval_nom   = ev.get('nom',          'Évaluation')
        classe_nom = ev.get('classe_nom',   '—')
        mat_nom    = ev.get('matiere_nom',  '—')
        bareme     = ev.get('bareme',       20)
        sync_key   = ev.get('sync_status',  'pending_sync')
        # ← use evaluation's own classe_uuid — no need for selected_classe
        classe_uuid = ev.get('classe_uuid')

        # Load students and existing notes
        students  = (list(app.db_manager.get_students_by_class(classe_uuid))
                     if classe_uuid else [])
        notes_raw = (list(app.db_manager.get_notes_for_evaluation(eval_uuid))
                     if eval_uuid else [])
        notes_map = {n['eleve_uuid']: dict(n) for n in notes_raw}

        user_uuid  = (app.current_user or {}).get('uid', '')
        total_s    = len(students)
        filled_s   = sum(1 for n in notes_map.values() if n.get('valeur') is not None)

        root = MDBoxLayout(orientation='vertical')

        # ── Top bar ────────────────────────────────────────────────────────────
        topbar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(68),
                              padding=[dp(8), dp(12), dp(16), dp(4)], spacing=dp(4))
        _back = MDIconButton(
            icon='arrow-left', theme_icon_color='Custom', icon_color=T1,
        )
        _back.bind(on_release=lambda x: self._go_back())
        topbar.add_widget(_back)
        t = MDBoxLayout(orientation='vertical', spacing=dp(1))
        t.add_widget(MDLabel(text=eval_nom, font_style='H6',
                              theme_text_color='Custom', text_color=T1))
        t.add_widget(MDLabel(text=f'{classe_nom}  ·  {mat_nom}  ·  /{bareme}',
                              font_style='Caption',
                              theme_text_color='Custom', text_color=T2))
        topbar.add_widget(t)
        topbar.add_widget(Widget())

        sync_icon  = 'cloud-check'       if sync_key == 'synced' else 'cloud-upload'
        sync_color = GREEN               if sync_key == 'synced' else AMBER
        topbar.add_widget(MDIconButton(
            icon=sync_icon, theme_icon_color='Custom', icon_color=sync_color,
        ))
        root.add_widget(topbar)

        # ── Progress / autosave banner ─────────────────────────────────────────
        progress_pct = int(filled_s / total_s * 100) if total_s else 0
        banner = MDBoxLayout(size_hint_y=None, height=dp(34),
                              padding=[dp(16), dp(6)], spacing=dp(8))
        with banner.canvas.before:
            Color(*BLUE[:3], 0.10)
            _banr = RoundedRectangle(pos=banner.pos, size=banner.size)
        banner.bind(pos=lambda *_: setattr(_banr, 'pos', banner.pos),
                    size=lambda *_: setattr(_banr, 'size', banner.size))

        self._status_lbl = MDLabel(
            text=f'💾  Autosave  ·  {filled_s}/{total_s} notes  ({progress_pct}%)',
            font_style='Caption',
            theme_text_color='Custom', text_color=BLUE,
        )
        banner.add_widget(self._status_lbl)
        root.add_widget(banner)

        # ── Column headers ─────────────────────────────────────────────────────
        hdr = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(32),
                           padding=[dp(14), dp(2), dp(16), dp(0)])
        for txt, w, align in [
            ('#', dp(40), 'center'), ('Nom', None, 'left'), ('Note', dp(72), 'right')
        ]:
            kw = {'size_hint_x': None, 'width': w} if w else {}
            hdr.add_widget(MDLabel(text=txt, font_style='Caption', halign=align,
                                    theme_text_color='Custom', text_color=T3, **kw))
        root.add_widget(hdr)

        # ── Students list ──────────────────────────────────────────────────────
        scroll  = MDScrollView()
        content = MDBoxLayout(orientation='vertical',
                               padding=[dp(10), dp(4), dp(10), dp(76)],
                               spacing=dp(8), size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))

        if students:
            for i, s in enumerate(students):
                nd  = notes_map.get(s['uuid'])
                val = (round(float(nd['valeur']), 1)
                       if nd and nd.get('valeur') is not None else None)
                content.add_widget(GradeRow(
                    rank=i + 1, eleve=dict(s), note_val=val,
                    on_save=lambda euuid, v,
                                   ev_id=eval_uuid, uu=user_uuid:
                        self._save_note(ev_id, euuid, uu, v),
                ))
        else:
            # Empty state
            empty = MDBoxLayout(orientation='vertical', spacing=dp(10),
                                 padding=[dp(32), dp(60)], size_hint_y=None, height=dp(220))
            empty.add_widget(MDLabel(text='👥', halign='center', font_style='H2',
                                      size_hint_y=None, height=dp(70)))
            empty.add_widget(MDLabel(
                text='Aucun élève dans cette classe',
                halign='center', font_style='H6',
                theme_text_color='Custom', text_color=T2,
            ))
            empty.add_widget(MDLabel(
                text='Ajoutez des élèves via le menu Classes',
                halign='center', font_style='Body2',
                theme_text_color='Custom', text_color=T3,
            ))
            content.add_widget(empty)

        scroll.add_widget(content)
        root.add_widget(scroll)

        # ── Bottom action bar ──────────────────────────────────────────────────
        action_bar = MDBoxLayout(size_hint_y=None, height=dp(72),
                                  padding=[dp(16), dp(12)], spacing=dp(10))
        with action_bar.canvas.before:
            Color(*BG)
            _ab = RoundedRectangle(pos=action_bar.pos, size=action_bar.size)
        action_bar.bind(
            pos=lambda *_: setattr(_ab, 'pos', action_bar.pos),
            size=lambda *_: setattr(_ab, 'size', action_bar.size),
        )

        stats_lbl = MDLabel(
            text=f'{filled_s}/{total_s}',
            font_style='H6', theme_text_color='Custom', text_color=T2,
            size_hint=(None, 1), width=dp(52),
        )
        self.save_btn = MDRaisedButton(
            text='💾  Tout enregistrer',
            size_hint_x=1, md_bg_color=BLUE,
        )
        self.save_btn.bind(on_release=self._save_all)
        sync_btn = MDFlatButton(
            text='☁', theme_text_color='Custom', text_color=T2,
            size_hint=(None, 1), width=dp(44),
        )
        sync_btn.bind(on_release=lambda x: self._trigger_sync())
        action_bar.add_widget(stats_lbl)
        action_bar.add_widget(self.save_btn)
        action_bar.add_widget(sync_btn)
        root.add_widget(action_bar)

        self.add_widget(root)
        self._eval_uuid  = eval_uuid
        self._user_uuid  = user_uuid
        self._total_s    = total_s
        self._filled_s   = filled_s

    # ─────────────────────────── Callbacks ────────────────────────────────────

    def _go_back(self):
        try:
            self.manager.current = 'evaluations'
        except Exception as e:
            print(f'[GradeEntry] Nav error: {e}')

    def _save_note(self, eval_uuid, eleve_uuid, user_uuid, val):
        if not eval_uuid or not eleve_uuid:
            return
        App.get_running_app().db_manager.upsert_note(
            eval_uuid, eleve_uuid, user_uuid, val
        )
        self._filled_s = min(self._filled_s + 1, self._total_s)
        pct = int(self._filled_s / self._total_s * 100) if self._total_s else 0
        self._status_lbl.text = (
            f'✓  Sauvegardé · {self._filled_s}/{self._total_s} notes ({pct}%)'
        )
        self._status_lbl.text_color = GREEN
        Clock.schedule_once(self._reset_banner, 2.5)

    def _reset_banner(self, *_):
        pct = int(self._filled_s / self._total_s * 100) if self._total_s else 0
        self._status_lbl.text = (
            f'💾  Autosave · {self._filled_s}/{self._total_s} notes ({pct}%)'
        )
        self._status_lbl.text_color = BLUE

    def _save_all(self, *_):
        Animation(md_bg_color=GREEN, duration=0.18).start(self.save_btn)
        self.save_btn.text = '✓  Toutes les notes sauvegardées'
        Clock.schedule_once(lambda dt: setattr(self.save_btn, 'text',
                                                '💾  Tout enregistrer'), 2.5)
        Clock.schedule_once(lambda dt: Animation(
            md_bg_color=BLUE, duration=0.3).start(self.save_btn), 2.5)

    def _trigger_sync(self):
        app = App.get_running_app()
        if app.sync_manager:
            self._status_lbl.text  = '⟳  Synchronisation en cours…'
            self._status_lbl.text_color = AMBER
            app.sync_manager.start_sync(on_complete=self._on_sync_done)

    def _on_sync_done(self, success, synced, failed):
        if success:
            self._status_lbl.text       = f'✓  {synced} note(s) synchronisée(s)'
            self._status_lbl.text_color = GREEN
        else:
            msg = f'⚠  {synced} sync · {failed} erreur(s)'
            self._status_lbl.text       = msg
            self._status_lbl.text_color = AMBER
        Clock.schedule_once(self._reset_banner, 3)
