"""
Dashboard Screen — Real-time stats + Activity feed
"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton, MDRaisedButton, MDFlatButton
from kivy.graphics import Color, RoundedRectangle, Ellipse
from kivy.metrics import dp
from kivy.uix.widget import Widget
from kivy.app import App
from kivy.clock import Clock
from kivy.animation import Animation
from widgets.bottom_nav import BottomNavBar
from core.theme.theme_manager import (
    BG, CARD1, CARD2, CARD3, BLUE, BLUE_A, PURPLE, PURPLE_A,
    CYAN, GREEN, GREEN_A, AMBER, AMBER_A, RED, T1, T2, T3, BORDER
)


def _bg(widget, color, radius=0):
    with widget.canvas.before:
        Color(*color)
        r = RoundedRectangle(pos=widget.pos, size=widget.size,
                              radius=[dp(radius)] if radius else [0])
    widget.bind(pos=lambda *a: setattr(r, 'pos', widget.pos),
                size=lambda *a: setattr(r, 'size', widget.size))
    return r


class StatCard(MDCard):
    def __init__(self, icon, value, label, color, bg_color, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = [dp(14), dp(14)]
        self.spacing = dp(6)
        self.md_bg_color = CARD1
        self.radius = [dp(20)]
        self.elevation = 0
        self.size_hint_y = None
        self.height = dp(108)
        self.size_hint_x = 1

        # Colored top accent line via canvas
        with self.canvas.after:
            Color(*color[:3], 0.6)
            RoundedRectangle(
                pos=(self.x + dp(14), self.y + self.height - dp(4)),
                size=(dp(32), dp(3)),
                radius=[dp(2)],
            )

        # Icon badge
        icon_card = MDCard(
            orientation='horizontal', padding=[dp(6), dp(6)],
            md_bg_color=bg_color, radius=[dp(12)],
            size_hint=(None, None), size=(dp(38), dp(38)),
        )
        icon_lbl = MDLabel(text=icon, halign='center', font_style='Subtitle1')
        icon_card.add_widget(icon_lbl)

        val_lbl = MDLabel(
            text=str(value), font_style='H5',
            theme_text_color='Custom', text_color=color,
        )
        name_lbl = MDLabel(
            text=label, font_style='Caption',
            theme_text_color='Custom', text_color=T3,
        )
        self.add_widget(icon_card)
        self.add_widget(val_lbl)
        self.add_widget(name_lbl)


class QuickAction(MDCard):
    def __init__(self, icon, label, screen, color, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = dp(16)
        self.spacing = dp(8)
        self.md_bg_color = CARD1
        self.radius = [dp(20)]
        self.elevation = 0
        self.size_hint_y = None
        self.height = dp(90)
        self.ripple_behavior = True
        self.bind(on_release=lambda x: self._go(screen))

        icon_lbl = MDLabel(text=icon, halign='center', font_style='H5',
                            size_hint_y=None, height=dp(36))
        lbl = MDLabel(text=label, halign='center', font_style='Caption',
                       theme_text_color='Custom', text_color=T2)
        self.add_widget(icon_lbl)
        self.add_widget(lbl)

    def _go(self, screen):
        try:
            app = App.get_running_app()
            app.root.current = screen
        except Exception as e:
            print(f'[QuickAction] Nav error to {screen}: {e}')


class ActivityRow(MDBoxLayout):
    def __init__(self, icon, title, sub, time, color, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = dp(62)
        self.spacing = dp(12)
        self.padding = [dp(12), dp(8)]

        _bg(self, CARD1, radius=16)

        dot_box = MDBoxLayout(size_hint=(None, 1), width=dp(42))
        dot = MDCard(md_bg_color=(*color[:3], 0.22), radius=[dp(12)],
                      size_hint=(None, None), size=(dp(38), dp(38)),
                      pos_hint={'center_y': 0.5})
        dot_lbl = MDLabel(text=icon, halign='center', font_style='Body1')
        dot.add_widget(dot_lbl)
        dot_box.add_widget(dot)

        info = MDBoxLayout(orientation='vertical', spacing=dp(2))
        info.add_widget(MDLabel(text=title, font_style='Body2',
                                 theme_text_color='Custom', text_color=T1))
        info.add_widget(MDLabel(text=sub, font_style='Caption',
                                 theme_text_color='Custom', text_color=T2))
        time_lbl = MDLabel(text=time, size_hint=(None, 1), width=dp(56),
                            font_style='Caption', halign='right',
                            theme_text_color='Custom', text_color=T3)
        self.add_widget(dot_box)
        self.add_widget(info)
        self.add_widget(time_lbl)


class SyncStatusCard(MDCard):
    def __init__(self, stats, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = [dp(16), dp(14)]
        self.spacing = dp(8)
        self.md_bg_color = CARD1
        self.radius = [dp(20)]
        self.elevation = 0
        self.size_hint_y = None
        self.height = dp(88)

        pending = stats.get('pending', 0)
        synced = stats.get('synced', 0)
        total = max(synced + pending, 1)
        pct = int(synced / total * 100)
        color = GREEN if pending == 0 else (AMBER if pending < 5 else RED)

        row1 = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(28))
        row1.add_widget(MDLabel(text='☁  Synchronisation', font_style='Subtitle2',
                                 theme_text_color='Custom', text_color=T1))
        row1.add_widget(Widget())
        status_badge = MDCard(
            md_bg_color=(*color[:3], 0.18), radius=[dp(10)],
            size_hint=(None, None), size=(dp(70), dp(24)),
            orientation='horizontal', padding=[dp(8), dp(2)],
        )
        status_lbl = MDLabel(
            text=f'{pct}% sync' if pending > 0 else '✓ Synced',
            font_style='Caption', halign='center',
            theme_text_color='Custom', text_color=color,
        )
        status_badge.add_widget(status_lbl)
        row1.add_widget(status_badge)

        row2 = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(24))
        msg = f'{pending} note(s) en attente' if pending > 0 else 'Toutes les notes sont synchronisées'
        row2.add_widget(MDLabel(text=msg, font_style='Caption',
                                 theme_text_color='Custom', text_color=T2))
        row2.add_widget(Widget())
        if pending > 0:
            sync_btn = MDFlatButton(
                text='Sync maintenant',
                theme_text_color='Custom', text_color=BLUE,
                on_release=lambda x: self._go_sync(),
            )
            row2.add_widget(sync_btn)

        self.add_widget(row1)
        self.add_widget(row2)

    def _go_sync(self):
        try:
            App.get_running_app().root.current = 'sync'
        except Exception as e:
            print(f'[SyncCard] Nav error: {e}')


class DashboardScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._built = False

    def on_enter(self):
        if not self._built:
            self._build_ui()
            self._built = True
        else:
            self._refresh()

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *a: setattr(self._bg, 'pos', self.pos),
                   size=lambda *a: setattr(self._bg, 'size', self.size))

        app = App.get_running_app()
        user = getattr(app, 'current_user', None) or {'prenom': '', 'nom': ''}
        uid = user.get('uid', '')
        stats = app.db_manager.get_global_stats(enseignant_uuid=uid)
        sync_stats = app.db_manager.get_sync_stats()

        root = MDBoxLayout(orientation='vertical')

        # ── Header ─────────────────────────────────────────────────────────────
        header = MDBoxLayout(
            orientation='horizontal', size_hint_y=None, height=dp(82),
            padding=[dp(20), dp(18), dp(16), dp(4)], spacing=dp(12),
        )
        # Avatar
        av = MDCard(md_bg_color=(*BLUE[:3], 0.22), radius=[dp(22)],
                     size_hint=(None, None), size=(dp(44), dp(44)),
                     orientation='horizontal',
                     pos_hint={'center_y': 0.5})
        av_lbl = MDLabel(
            text=user.get('prenom', 'M')[0].upper(),
            halign='center', font_style='H6',
            theme_text_color='Custom', text_color=BLUE,
        )
        av.add_widget(av_lbl)

        greet_box = MDBoxLayout(orientation='vertical', spacing=dp(1))
        greet_box.add_widget(MDLabel(
            text=f"Bonjour, {user.get('prenom', 'Marc')} 👋",
            font_style='H6', theme_text_color='Custom', text_color=T1,
        ))
        greet_box.add_widget(MDLabel(
            text='Mathématiques  ·  Prof',
            font_style='Caption', theme_text_color='Custom', text_color=T2,
        ))

        header.add_widget(av)
        header.add_widget(greet_box)
        header.add_widget(Widget())
        notif = MDIconButton(icon='bell-outline', theme_icon_color='Custom', icon_color=T1)
        header.add_widget(notif)
        root.add_widget(header)

        # ── Scrollable body ────────────────────────────────────────────────────
        scroll = MDScrollView()
        body = MDBoxLayout(
            orientation='vertical',
            padding=[dp(16), dp(4), dp(16), dp(80)],
            spacing=dp(16), size_hint_y=None,
        )
        body.bind(minimum_height=body.setter('height'))

        # Section: Stats row
        sect_lbl = MDLabel(
            text='Vue d\'ensemble', font_style='Subtitle1',
            theme_text_color='Custom', text_color=T1,
            size_hint_y=None, height=dp(28),
        )
        body.add_widget(sect_lbl)

        stat_row = MDBoxLayout(orientation='horizontal', spacing=dp(10),
                                size_hint_y=None, height=dp(108))
        stat_row.add_widget(StatCard('🏫', stats['classes'],    'Classes',    BLUE,   BLUE_A))
        stat_row.add_widget(StatCard('👩‍🎓', stats['eleves'],     'Élèves',     PURPLE, PURPLE_A))
        stat_row.add_widget(StatCard('📝', stats['evaluations'], 'Évals',      CYAN, (*CYAN[:3], 0.15)))
        stat_row.add_widget(StatCard('🔢', stats['notes'],      'Notes',      GREEN,  GREEN_A))
        body.add_widget(stat_row)

        # Average banner
        moy = stats['moyenne']
        moy_color = GREEN if moy >= 12 else (AMBER if moy >= 8 else RED)
        moy_card = MDCard(
            orientation='horizontal', padding=[dp(16), dp(14)], spacing=dp(12),
            md_bg_color=(*moy_color[:3], 0.12), radius=[dp(20)],
            size_hint_y=None, height=dp(66), elevation=0,
        )
        moy_card.add_widget(MDLabel(text='📊', size_hint=(None, 1), width=dp(32),
                                     font_style='H5', halign='center'))
        moy_info = MDBoxLayout(orientation='vertical', spacing=dp(2))
        moy_info.add_widget(MDLabel(text='Moyenne générale de la promotion',
                                     font_style='Body2',
                                     theme_text_color='Custom', text_color=T2))
        moy_info.add_widget(MDLabel(text=f'{moy}/20', font_style='H6',
                                     theme_text_color='Custom', text_color=moy_color))
        moy_card.add_widget(moy_info)
        body.add_widget(moy_card)

        # Sync card
        body.add_widget(SyncStatusCard(sync_stats))

        # Quick actions
        qa_lbl = MDLabel(text='Actions rapides', font_style='Subtitle1',
                          theme_text_color='Custom', text_color=T1,
                          size_hint_y=None, height=dp(28))
        body.add_widget(qa_lbl)

        qa_row1 = MDBoxLayout(orientation='horizontal', spacing=dp(10),
                               size_hint_y=None, height=dp(90))
        qa_row1.add_widget(QuickAction('📋', 'Saisir notes', 'evaluations', BLUE))
        qa_row1.add_widget(QuickAction('🏫', 'Mes classes', 'classes', PURPLE))
        qa_row1.add_widget(QuickAction('📊', 'Statistiques', 'analytics', GREEN))
        body.add_widget(qa_row1)

        # Recent activity
        act_lbl = MDLabel(text='Activité récente', font_style='Subtitle1',
                           theme_text_color='Custom', text_color=T1,
                           size_hint_y=None, height=dp(28))
        body.add_widget(act_lbl)

        activities = [
            ('📝', 'DM Mathématiques — 3ème A', '10 notes saisies', 'Il y a 5m', BLUE),
            ('✅', 'Contrôle N°2 — 2nde B',      'Synchronisé',      'Il y a 1h', GREEN),
            ('⚠️', 'Composition — 1ère C',        'En attente sync',  'Il y a 2h', AMBER),
            ('📊', 'Examen Blanc — Terminale D',  '8 notes saisies',  'Hier',      PURPLE),
        ]
        for icon, title, sub, time, color in activities:
            body.add_widget(ActivityRow(icon, title, sub, time, color,
                                         size_hint_y=None, height=dp(62),
                                         spacing=dp(0), padding=[0, dp(0), 0, dp(0)]))
            body.add_widget(Widget(size_hint_y=None, height=dp(8)))

        scroll.add_widget(body)
        root.add_widget(scroll)
        root.add_widget(BottomNavBar(active_screen='dashboard'))
        self.add_widget(root)

    def _refresh(self):
        pass  # Future: pull fresh stats
