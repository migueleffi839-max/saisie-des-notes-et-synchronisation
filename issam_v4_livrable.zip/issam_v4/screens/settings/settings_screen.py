"""
Settings Screen — Profile, security, preferences
ISSAM v3.0 — FIX: _go_back undefined, on_enter missing, SectionCard dynamic height
"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton, MDRaisedButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle, Ellipse
from kivy.metrics import dp
from kivy.app import App
from kivy.clock import Clock
from widgets.bottom_nav import BottomNavBar
from core.theme.theme_manager import (
    BG, CARD1, CARD2, BLUE, BLUE_A, PURPLE, PURPLE_A,
    GREEN, GREEN_A, AMBER, AMBER_A, RED, RED_A, T1, T2, T3
)


class SettingRow(MDBoxLayout):
    def __init__(self, icon, label, subtitle=None, right_widget=None,
                 icon_color=None, label_color=None, on_tap=None, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = dp(56) if subtitle else dp(48)
        self.spacing = dp(12)
        self.padding = [dp(16), dp(6)]

        if on_tap:
            self.bind(on_touch_down=lambda inst, touch:
                      on_tap() if inst.collide_point(*touch.pos) else None)

        ic = icon_color or BLUE
        lc = label_color or T1

        icon_badge = MDCard(
            md_bg_color=(*ic[:3], 0.15), radius=[dp(10)],
            size_hint=(None, None), size=(dp(34), dp(34)),
            pos_hint={'center_y': 0.5},
        )
        icon_badge.add_widget(MDLabel(text=icon, halign='center', font_style='Body1'))

        info = MDBoxLayout(orientation='vertical', spacing=dp(1))
        info.add_widget(MDLabel(text=label, font_style='Body2',
                                theme_text_color='Custom', text_color=lc))
        if subtitle:
            info.add_widget(MDLabel(text=subtitle, font_style='Caption',
                                    theme_text_color='Custom', text_color=T3))

        self.add_widget(icon_badge)
        self.add_widget(info)
        self.add_widget(Widget())

        if right_widget:
            self.add_widget(right_widget)
        else:
            self.add_widget(MDLabel(text='›', halign='center', font_style='H6',
                                    size_hint=(None, 1), width=dp(22),
                                    theme_text_color='Custom', text_color=T3))


class SectionCard(MDCard):
    def __init__(self, title, rows, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.md_bg_color = CARD1
        self.radius = [dp(20)]
        self.elevation = 0
        self.padding = [0, dp(4)]
        # FIX: compute height dynamically from actual rows
        rows_height = sum(r.height for r in rows)
        self.size_hint_y = None
        self.height = (dp(32) + rows_height + dp(8)) if title else (rows_height + dp(8))

        if title:
            t = MDLabel(text=title.upper(), font_style='Caption',
                        theme_text_color='Custom', text_color=T3,
                        padding=[dp(16), dp(4)], size_hint_y=None, height=dp(28))
            self.add_widget(t)
        for row in rows:
            self.add_widget(row)


class SettingsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def on_enter(self):
        self.clear_widgets()
        self._build_ui()

    # ── FIX: _go_back was called but never defined ─────────────────────────────
    def _go_back(self):
        try:
            self.manager.current = 'dashboard'
        except Exception as e:
            print(f"[SettingsScreen] nav error: {e}")

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *a: setattr(self._bg, 'pos', self.pos),
                  size=lambda *a: setattr(self._bg, 'size', self.size))

        app = App.get_running_app()
        user = getattr(app, 'current_user', None) or {
            'prenom': 'Marc', 'nom': 'Dupont', 'email': 'enseignant@example.com'
        }

        root = MDBoxLayout(orientation='vertical')

        # ── Top bar ─────────────────────────────────────────────────────────────
        topbar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(68),
                             padding=[dp(8), dp(14), dp(16), dp(4)], spacing=dp(4))
        back_btn = MDIconButton(icon='arrow-left', theme_icon_color='Custom', icon_color=T1)
        back_btn.bind(on_release=lambda x: self._go_back())
        topbar.add_widget(back_btn)
        topbar.add_widget(MDLabel(text='Profil & Paramètres', font_style='H5',
                                  theme_text_color='Custom', text_color=T1))
        root.add_widget(topbar)

        scroll = MDScrollView()
        body = MDBoxLayout(orientation='vertical',
                           padding=[dp(16), dp(4), dp(16), dp(90)],
                           spacing=dp(16), size_hint_y=None)
        body.bind(minimum_height=body.setter('height'))

        # ── Profile hero ─────────────────────────────────────────────────────────
        profile_card = MDCard(
            orientation='vertical', padding=[dp(20), dp(20)], spacing=dp(12),
            md_bg_color=CARD1, radius=[dp(24)],
            size_hint_y=None, height=dp(180), elevation=0,
        )
        av_row = MDBoxLayout(orientation='horizontal', spacing=dp(16),
                             size_hint_y=None, height=dp(72))
        av = MDCard(
            md_bg_color=(*BLUE[:3], 0.22), radius=[dp(28)],
            size_hint=(None, None), size=(dp(64), dp(64)),
            orientation='horizontal',
        )
        initial = (user.get('prenom') or 'M')[0].upper()
        av.add_widget(MDLabel(text=initial, halign='center', font_style='H4',
                              theme_text_color='Custom', text_color=BLUE))
        name_box = MDBoxLayout(orientation='vertical', spacing=dp(3))
        name_box.add_widget(MDLabel(
            text=f"{user.get('prenom', '')} {user.get('nom', '')}",
            font_style='H6', theme_text_color='Custom', text_color=T1,
        ))
        name_box.add_widget(MDLabel(
            text=user.get('email', '—'),
            font_style='Caption', theme_text_color='Custom', text_color=T2,
        ))
        name_box.add_widget(MDLabel(
            text=f"Rôle : {user.get('role', 'enseignant')}",
            font_style='Caption', theme_text_color='Custom', text_color=T3,
        ))
        av_row.add_widget(av)
        av_row.add_widget(name_box)
        profile_card.add_widget(av_row)

        plan_row = MDBoxLayout(orientation='horizontal', spacing=dp(10),
                               size_hint_y=None, height=dp(36))
        plan_badge = MDCard(
            md_bg_color=(*PURPLE[:3], 0.20), radius=[dp(12)],
            size_hint=(None, None), size=(dp(120), dp(28)),
            orientation='horizontal', padding=[dp(8), dp(2)],
        )
        plan_badge.add_widget(MDLabel(text='⭐  Plan Pro', halign='center',
                                      font_style='Caption',
                                      theme_text_color='Custom', text_color=PURPLE))
        plan_row.add_widget(plan_badge)
        plan_row.add_widget(Widget())
        plan_row.add_widget(MDLabel(text='Lycée Général — Yaoundé',
                                    font_style='Caption',
                                    theme_text_color='Custom', text_color=T3))
        profile_card.add_widget(plan_row)

        edit_btn = MDFlatButton(text='✏  Modifier le profil',
                                theme_text_color='Custom', text_color=BLUE)
        profile_card.add_widget(edit_btn)
        body.add_widget(profile_card)

        # ── Compte ──────────────────────────────────────────────────────────────
        compte_rows = [
            SettingRow('👤', 'Informations personnelles', 'Nom, prénom, établissement'),
            SettingRow('🏫', 'Mon établissement',         'Lycée Général de Yaoundé'),
            SettingRow('📧', "Changer l'email",           user.get('email', '—')),
            SettingRow('🔑', 'Changer le mot de passe'),
        ]
        body.add_widget(SectionCard('Compte', compte_rows))

        # ── Sécurité ─────────────────────────────────────────────────────────────
        secu_rows = [
            SettingRow('🔒', 'Code PIN',           "Verrouillage de l'app", icon_color=AMBER),
            SettingRow('👁',  'Masquer les notes',  'En mode aperçu',        icon_color=AMBER),
            SettingRow('📱', 'Appareils connectés', '1 appareil actif',      icon_color=AMBER),
            SettingRow('🔐', 'Authentification 2FA', 'Désactivée',           icon_color=RED),
        ]
        body.add_widget(SectionCard('Sécurité', secu_rows))

        # ── Synchronisation ───────────────────────────────────────────────────────
        sync_stats = app.db_manager.get_sync_stats()
        pending = sync_stats.get('pending', 0)
        sync_rows = [
            SettingRow('☁',  'Mode de sync',      'Automatique (Wi-Fi)',           icon_color=BLUE),
            SettingRow('🔄', 'Notes en attente',  f'{pending} en attente de sync', icon_color=BLUE),
            SettingRow('📥', 'Sauvegardes',       'Activées',                      icon_color=BLUE),
        ]
        body.add_widget(SectionCard('Synchronisation', sync_rows))

        # ── Données & Export ──────────────────────────────────────────────────────
        data_rows = [
            SettingRow('📊', 'Exporter en PDF',   'Bulletins de notes',   icon_color=GREEN),
            SettingRow('📋', 'Exporter en Excel', 'Tableaux de notes',    icon_color=GREEN),
            SettingRow('🗄',  'Données locales',   'Base SQLite',          icon_color=GREEN),
        ]
        body.add_widget(SectionCard('Données & Export', data_rows))

        # ── Plan SaaS ─────────────────────────────────────────────────────────────
        plan_card = MDCard(
            orientation='vertical', padding=dp(16), spacing=dp(12),
            md_bg_color=(*PURPLE[:3], 0.12), radius=[dp(20)],
            size_hint_y=None, height=dp(130), elevation=0,
        )
        plan_card.add_widget(MDLabel(
            text='⭐  Plan Pro — Actif', font_style='Subtitle1',
            theme_text_color='Custom', text_color=PURPLE,
            size_hint_y=None, height=dp(28),
        ))
        plan_card.add_widget(MDLabel(
            text='✓  Sync illimitée   ✓  Export PDF/Excel\n✓  Multi-classe      ✓  Support prioritaire',
            font_style='Caption',
            theme_text_color='Custom', text_color=T2,
            size_hint_y=None, height=dp(36),
        ))
        upgrade_btn = MDRaisedButton(text='🚀  Passer à Enterprise', md_bg_color=PURPLE,
                                     size_hint_x=1)
        upgrade_btn.bind(on_release=lambda x: self._show_upgrade())
        plan_card.add_widget(upgrade_btn)
        body.add_widget(plan_card)

        # ── Assistance ────────────────────────────────────────────────────────────
        help_rows = [
            SettingRow('❓', "Centre d'aide",   'FAQ et tutoriels',  icon_color=T2),
            SettingRow('💬', 'Support en ligne', 'Chat  ·  WhatsApp', icon_color=T2),
            SettingRow('📣', 'Nouveautés',       'Version 3.0',       icon_color=T2),
        ]
        body.add_widget(SectionCard('Assistance', help_rows))

        # ── Gestion des Matières ──────────────────────────────────────────────────
        mat_title = MDLabel(
            text='📚  Mes Matières',
            font_style='H6', theme_text_color='Custom', text_color=T1,
            size_hint_y=None, height=dp(36),
        )
        body.add_widget(mat_title)
        self._mat_list_box = MDBoxLayout(orientation='vertical', spacing=dp(6),
                                          size_hint_y=None)
        self._mat_list_box.bind(minimum_height=self._mat_list_box.setter('height'))
        body.add_widget(self._mat_list_box)
        self._refresh_matieres()

        mat_row = MDBoxLayout(orientation='horizontal', spacing=dp(8),
                               size_hint_y=None, height=dp(48))
        self._mat_nom = MDTextField(hint_text='Nom matière (ex: Maths)', mode='rectangle')
        self._mat_code = MDTextField(hint_text='Code (ex: MATH)', mode='rectangle', size_hint_x=None, width=dp(90))
        add_mat_btn = MDRaisedButton(text='Ajouter', md_bg_color=BLUE,
                                      size_hint=(None, None), size=(dp(90), dp(42)))
        add_mat_btn.bind(on_release=lambda x: self._add_matiere())
        mat_row.add_widget(self._mat_nom)
        mat_row.add_widget(self._mat_code)
        mat_row.add_widget(add_mat_btn)
        body.add_widget(mat_row)

        body.add_widget(MDLabel(size_hint_y=None, height=dp(16)))

        # ── Déconnexion ───────────────────────────────────────────────────────────
        logout_btn = MDRaisedButton(
            text='🚪  Se déconnecter',
            size_hint_x=1,
            md_bg_color=(*RED[:3], 0.20),
            theme_text_color='Custom',
        )
        logout_btn.bind(on_release=self._logout)
        body.add_widget(logout_btn)

        body.add_widget(MDLabel(
            text='ISSAM v3.0  ·  © 2025 ISSAM Technologies\nTous droits réservés',
            halign='center', font_style='Caption',
            theme_text_color='Custom', text_color=T3,
            size_hint_y=None, height=dp(40),
        ))

        scroll.add_widget(body)
        root.add_widget(scroll)
        root.add_widget(BottomNavBar(active_screen='settings'))
        self.add_widget(root)

    def _show_upgrade(self):
        from kivy.uix.popup import Popup
        p = Popup(
            title='Plan Enterprise',
            content=MDLabel(text='Contactez enterprise@issam.cm\npour un devis personnalisé.',
                            halign='center', font_style='Body1'),
            size_hint=(None, None), size=(dp(300), dp(180)),
        )
        p.open()

    def _get_uid(self):
        app = App.get_running_app()
        return (app.current_user or {}).get('uid', '')

    def _refresh_matieres(self):
        app = App.get_running_app()
        uid = self._get_uid()
        self._mat_list_box.clear_widgets()
        try:
            matieres = app.db_manager.get_matieres(enseignant_uuid=uid)
        except Exception:
            matieres = []
        if not matieres:
            from kivymd.uix.label import MDLabel as _LBL
            self._mat_list_box.add_widget(_LBL(
                text='Aucune matière. Ajoutez-en une ci-dessous.',
                font_style='Caption', theme_text_color='Custom',
                text_color=(0.5, 0.5, 0.5, 1),
                size_hint_y=None, height=dp(28),
            ))
        for m in matieres:
            from kivymd.uix.card import MDCard as _Card
            row = _Card(orientation='horizontal', md_bg_color=CARD1, radius=[dp(10)],
                         size_hint_y=None, height=dp(42), padding=[dp(12), dp(4)], spacing=dp(8))
            from kivymd.uix.label import MDLabel as _LBL
            row.add_widget(_LBL(text=f"{m['nom']}  ({m.get('code','')})",
                                 font_style='Body2', theme_text_color='Custom', text_color=T1))
            from kivy.uix.widget import Widget as _W
            row.add_widget(_W())
            from kivymd.uix.button import MDIconButton as _IB
            del_btn = _IB(icon='delete', theme_icon_color='Custom',
                           icon_color=(0.9, 0.3, 0.3, 1),
                           size_hint=(None, None), size=(dp(32), dp(32)),
                           pos_hint={'center_y': 0.5})
            del_btn.bind(on_release=lambda x, uuid=m['uuid']: self._delete_matiere(uuid))
            row.add_widget(del_btn)
            self._mat_list_box.add_widget(row)

    def _add_matiere(self):
        nom = self._mat_nom.text.strip()
        code = self._mat_code.text.strip().upper()
        if not nom:
            return
        if not code:
            code = nom[:4].upper()
        app = App.get_running_app()
        uid = self._get_uid()
        app.db_manager.create_matiere(uid, nom, code)
        self._mat_nom.text = ''
        self._mat_code.text = ''
        self._refresh_matieres()

    def _delete_matiere(self, mat_uuid):
        app = App.get_running_app()
        app.db_manager.delete_matiere(mat_uuid)
        self._refresh_matieres()

    def _logout(self, *a):
        try:
            app = App.get_running_app()
            app.current_user = None
            if app.auth_service:
                app.auth_service.sign_out()
            self.manager.current = 'login'
        except Exception as e:
            print(f'[Settings] Logout error: {e}')
