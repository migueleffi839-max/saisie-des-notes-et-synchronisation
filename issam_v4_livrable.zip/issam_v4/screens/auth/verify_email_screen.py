"""
Verify Email Screen — Vérification email + skip local
ISSAM v2.0 — Corrigé
"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.card import MDCard
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.app import App
from core.theme.theme_manager import BG, CARD1, BLUE, GREEN, AMBER, RED, T1, T2, T3


class VerifyEmailScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._check_evt = None
        self._build_ui()

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *_: setattr(self._bg, 'pos', self.pos),
                   size=lambda *_: setattr(self._bg, 'size', self.size))

        outer = MDBoxLayout(orientation='vertical',
                             padding=[dp(24), dp(80), dp(24), 0], spacing=dp(24))

        # Icône + titre
        outer.add_widget(MDLabel(text='📧', halign='center', font_style='H1',
                                  size_hint_y=None, height=dp(60)))
        outer.add_widget(MDLabel(text='Vérifiez votre email', halign='center',
                                  font_style='H5',
                                  theme_text_color='Custom', text_color=T1,
                                  size_hint_y=None, height=dp(36)))

        self.email_lbl = MDLabel(
            text='Un lien de confirmation a été envoyé.',
            halign='center', font_style='Body1',
            theme_text_color='Custom', text_color=T2,
            size_hint_y=None, height=dp(50),
        )
        outer.add_widget(self.email_lbl)

        card = MDCard(
            orientation='vertical', padding=dp(20), spacing=dp(14),
            md_bg_color=CARD1, radius=[dp(24)],
            elevation=4, size_hint_y=None, height=dp(220),
        )

        self.status_lbl = MDLabel(
            text='⏳  En attente de vérification…',
            halign='center', font_style='Body2',
            theme_text_color='Custom', text_color=AMBER,
            size_hint_y=None, height=dp(28),
        )
        card.add_widget(self.status_lbl)

        resend_btn = MDRaisedButton(
            text='Renvoyer l\'email', size_hint_x=1, md_bg_color=BLUE,
        )
        resend_btn.bind(on_release=self._resend)
        card.add_widget(resend_btn)

        check_btn = MDRaisedButton(
            text='J\'ai vérifié mon email ✓', size_hint_x=1, md_bg_color=GREEN,
        )
        check_btn.bind(on_release=self._check_verified)
        card.add_widget(check_btn)

        skip_btn = MDFlatButton(
            text='Continuer sans vérification →',
            size_hint_x=1,
            theme_text_color='Custom', text_color=T3,
        )
        skip_btn.bind(on_release=self._skip)
        card.add_widget(skip_btn)

        outer.add_widget(card)
        outer.add_widget(Widget())
        self.add_widget(outer)

    def on_enter(self):
        app = App.get_running_app()
        user = getattr(app, 'current_user', {})
        email = user.get('email', '') if user else ''
        self.email_lbl.text = f'Email envoyé à :\n{email}'
        # Vérification auto toutes les 5s
        if self._check_evt:
            self._check_evt.cancel()
        self._check_evt = Clock.schedule_interval(self._auto_check, 5)

    def on_leave(self):
        if self._check_evt:
            self._check_evt.cancel()
            self._check_evt = None

    def _auto_check(self, dt):
        app = App.get_running_app()
        user = getattr(app, 'current_user', {})
        if not user:
            return
        id_token = user.get('id_token')
        if not id_token:
            return
        app.auth_service.check_email_verified(
            id_token, on_result=self._on_check_result)

    def _on_check_result(self, verified):
        if verified:
            self._go_dashboard()

    def _resend(self, *_):
        app = App.get_running_app()
        user = getattr(app, 'current_user', {})
        if not user:
            return
        id_token = user.get('id_token')
        if not id_token:
            self.status_lbl.text = '⚠  Mode local : vérification non requise.'
            self.status_lbl.text_color = AMBER
            return
        app.auth_service.send_email_verification(
            id_token,
            on_success=lambda: self._set_status('✉  Email renvoyé !', GREEN),
            on_error=lambda m: self._set_status(f'Erreur: {m}', RED),
        )

    def _check_verified(self, *_):
        app = App.get_running_app()
        user = getattr(app, 'current_user', {})
        if not user:
            return
        id_token = user.get('id_token')
        if not id_token:
            # Mode local → passer directement
            self._go_dashboard()
            return
        app.auth_service.check_email_verified(
            id_token, on_result=lambda v: self._go_dashboard() if v
            else self._set_status('⚠  Email pas encore vérifié.', AMBER)
        )

    def _skip(self, *_):
        self._go_dashboard()

    def _go_dashboard(self):
        if self._check_evt:
            self._check_evt.cancel()
            self._check_evt = None
        try:
            self.manager.current = 'dashboard'
        except Exception as e:
            print(f"[Nav] {e}")

    def _set_status(self, msg, color):
        self.status_lbl.text = msg
        self.status_lbl.text_color = color
