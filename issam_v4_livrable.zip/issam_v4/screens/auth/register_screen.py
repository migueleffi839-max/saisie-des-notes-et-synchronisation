"""
Register Screen — Inscription locale + Firebase
ISSAM v2.0 — Corrigé
"""
import re
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.card import MDCard
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle, Ellipse
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.app import App
from core.theme.theme_manager import BG, CARD1, BLUE, PURPLE, GREEN, RED, T1, T2, T3

_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


class RegisterScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._loading = False
        self._build_ui()

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *_: setattr(self._bg, 'pos', self.pos),
                   size=lambda *_: setattr(self._bg, 'size', self.size))

        # Background orbs
        orb1 = Widget(size=(dp(240), dp(240)), pos_hint={'center_x': 0.85, 'center_y': 0.85})
        with orb1.canvas:
            Color(*GREEN[:3], 0.12)
            Ellipse(pos=orb1.pos, size=orb1.size)
        self.add_widget(orb1)

        outer = MDBoxLayout(orientation='vertical', padding=[dp(24), 0], spacing=0)

        # Header avec retour
        top = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(68),
                           padding=[0, dp(20), 0, 0])
        back_btn = MDFlatButton(text='← Retour', size_hint=(None, 1), width=dp(90),
                                 theme_text_color='Custom', text_color=BLUE)
        back_btn.bind(on_release=self._go_back)
        top.add_widget(back_btn)
        top.add_widget(Widget())
        outer.add_widget(top)

        # Brand
        brand = MDBoxLayout(orientation='vertical', spacing=dp(4),
                             size_hint_y=None, height=dp(80))
        brand.add_widget(MDLabel(text='Créer un compte', halign='center',
                                  font_style='H4', theme_text_color='Custom', text_color=T1))
        brand.add_widget(MDLabel(text='Rejoignez ISSAM — Enseignants du Cameroun',
                                  halign='center', font_style='Body2',
                                  theme_text_color='Custom', text_color=T2))
        outer.add_widget(brand)

        # Card
        card = MDCard(
            orientation='vertical', padding=[dp(22), dp(18)], spacing=dp(12),
            md_bg_color=(*CARD1[:3], 0.95), radius=[dp(28)],
            elevation=8, size_hint_y=None, height=dp(480),
        )

        # Nom complet
        self.name_field = MDTextField(
            hint_text='Prénom Nom (ex: Jean Mbarga)',
            icon_right='account-outline',
            mode='rectangle', size_hint_y=None, height=dp(50),
        )
        self._add_labeled_field(card, 'Nom complet', self.name_field)

        # Email
        self.email_field = MDTextField(
            hint_text='nom@lycee.cm',
            icon_right='email-outline',
            mode='rectangle', size_hint_y=None, height=dp(50),
        )
        self._add_labeled_field(card, 'Email professionnel', self.email_field)

        # Mot de passe
        self.pwd_field = MDTextField(
            hint_text='Minimum 6 caractères',
            icon_right='eye-outline',
            mode='rectangle', password=True, size_hint_y=None, height=dp(50),
        )
        self._add_labeled_field(card, 'Mot de passe', self.pwd_field)

        # Confirmer
        self.pwd2_field = MDTextField(
            hint_text='Répétez le mot de passe',
            icon_right='eye-outline',
            mode='rectangle', password=True, size_hint_y=None, height=dp(50),
        )
        self._add_labeled_field(card, 'Confirmer le mot de passe', self.pwd2_field)

        # Erreur
        self.error_lbl = MDLabel(
            text='', halign='center', font_style='Caption',
            theme_text_color='Custom', text_color=RED,
            size_hint_y=None, height=dp(20),
        )
        card.add_widget(self.error_lbl)

        # Bouton
        self.reg_btn = MDRaisedButton(
            text="S'inscrire →",
            size_hint_x=1, md_bg_color=GREEN,
        )
        self.reg_btn.bind(on_release=self._do_register)
        card.add_widget(self.reg_btn)

        # Lien login
        link_row = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(36))
        link_row.add_widget(Widget())
        link_row.add_widget(MDLabel(text='Déjà un compte ?', font_style='Caption',
                                     size_hint=(None, 1), width=dp(120),
                                     theme_text_color='Custom', text_color=T2))
        login_link = MDFlatButton(text='Se connecter', size_hint=(None, 1), width=dp(110),
                                   theme_text_color='Custom', text_color=BLUE)
        login_link.bind(on_release=self._go_back)
        link_row.add_widget(login_link)
        link_row.add_widget(Widget())
        card.add_widget(link_row)

        outer.add_widget(card)
        outer.add_widget(Widget())
        self.add_widget(outer)

    def _add_labeled_field(self, parent, label, field):
        box = MDBoxLayout(orientation='vertical', spacing=dp(2),
                           size_hint_y=None, height=dp(70))
        box.add_widget(MDLabel(text=label, font_style='Caption',
                                theme_text_color='Custom', text_color=T2,
                                size_hint_y=None, height=dp(16)))
        box.add_widget(field)
        parent.add_widget(box)

    def on_enter(self):
        self.opacity = 0
        Animation(opacity=1, duration=0.4).start(self)

    def _go_back(self, *_):
        try:
            self.manager.current = 'login'
        except Exception as e:
            print(f"[Nav] {e}")

    def _do_register(self, *_):
        if self._loading:
            return
        name  = self.name_field.text.strip()
        email = self.email_field.text.strip()
        pwd   = self.pwd_field.text
        pwd2  = self.pwd2_field.text

        if not name or not email or not pwd:
            self._show_error('Tous les champs sont requis.')
            return
        if not _EMAIL_RE.match(email):
            self._show_error('Email invalide.')
            return
        if len(pwd) < 6:
            self._show_error('Mot de passe trop court (6 min).')
            return
        if pwd != pwd2:
            self._show_error('Les mots de passe ne correspondent pas.')
            return

        self._set_loading(True)
        try:
            App.get_running_app().auth_service.sign_up(
                email, pwd, name,
                on_success=self._on_success,
                on_error=self._on_error,
            )
        except Exception as e:
            self._set_loading(False)
            self._show_error(str(e))

    def _on_success(self, profile):
        app = App.get_running_app()
        app.current_user = profile
        self._set_loading(False)
        Animation(opacity=0, duration=0.3).start(self)
        Clock.schedule_once(self._go_dashboard, 0.35)

    def _go_dashboard(self, *_):
        try:
            if self.manager:
                self.manager.current = 'dashboard'
        except Exception as e:
            print(f"[Register] nav error: {e}")

    def _on_error(self, msg):
        self._set_loading(False)
        self._show_error(msg)

    def _set_loading(self, v):
        self._loading = v
        self.reg_btn.disabled = v
        self.reg_btn.text = 'Inscription…' if v else "S'inscrire →"

    def _show_error(self, msg):
        self.error_lbl.text = msg
