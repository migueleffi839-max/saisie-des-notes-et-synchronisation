"""
Login Screen — Firebase Email/Password + Google Sign-In
Design startup moderne · Fonctionne offline + Firebase
ISSAM v2.0 — Bugs corrigés
"""
import re
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.card import MDCard
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle, Ellipse
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.app import App
from core.theme.theme_manager import (
    BG, CARD1, CARD2, BLUE, PURPLE, GREEN, RED, T1, T2, T3, AMBER
)

_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


class _Orb(Widget):
    def __init__(self, base_color, **kwargs):
        super().__init__(**kwargs)
        self._c = base_color
        self.bind(pos=self._draw, size=self._draw)

    def _draw(self, *_):
        self.canvas.clear()
        with self.canvas:
            Color(*self._c[:3], 0.18)
            Ellipse(pos=self.pos, size=self.size)
            Color(*self._c[:3], 0.07)
            pad = dp(24)
            Ellipse(pos=(self.x - pad, self.y - pad),
                    size=(self.width + pad*2, self.height + pad*2))


class GoogleSignInButton(MDCard):
    def __init__(self, on_press_cb, **kwargs):
        super().__init__(**kwargs)
        self.orientation     = 'horizontal'
        self.padding         = [dp(14), dp(0)]
        self.spacing         = dp(10)
        self.md_bg_color     = (0.165, 0.196, 0.216, 1)
        self.radius          = [dp(14)]
        self.size_hint_y     = None
        self.height          = dp(52)
        self.ripple_behavior = True
        self._cb             = on_press_cb
        self.bind(on_release=lambda x: self._cb())

        g_lbl = MDLabel(
            text='G', halign='center', font_style='H6',
            size_hint=(None, 1), width=dp(32),
            theme_text_color='Custom',
            text_color=(0.937, 0.267, 0.267, 1),
        )
        self.txt_lbl = MDLabel(
            text='Continuer avec Google',
            halign='center', font_style='Subtitle2',
            theme_text_color='Custom', text_color=T1,
        )
        self.add_widget(Widget(size_hint_x=None, width=dp(4)))
        self.add_widget(g_lbl)
        self.add_widget(self.txt_lbl)
        self.add_widget(Widget())


class _Divider(MDBoxLayout):
    def __init__(self, text='ou', **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height      = dp(20)
        self.spacing     = dp(10)
        self.padding     = [dp(4), 0]

        line_l = Widget()
        with line_l.canvas:
            Color(*T3[:3], 0.4)
            self._ll = RoundedRectangle(pos=(line_l.x, line_l.center_y),
                                         size=(line_l.width, dp(1)))
        line_l.bind(
            pos=lambda i, _: setattr(self._ll, 'pos', (i.x, i.center_y)),
            size=lambda i, _: setattr(self._ll, 'size', (i.width, dp(1))),
        )
        lbl = MDLabel(text=text, halign='center', font_style='Caption',
                       size_hint=(None, 1), width=dp(28),
                       theme_text_color='Custom', text_color=T3)
        line_r = Widget()
        with line_r.canvas:
            Color(*T3[:3], 0.4)
            self._lr = RoundedRectangle(pos=(line_r.x, line_r.center_y),
                                         size=(line_r.width, dp(1)))
        line_r.bind(
            pos=lambda i, _: setattr(self._lr, 'pos', (i.x, i.center_y)),
            size=lambda i, _: setattr(self._lr, 'size', (i.width, dp(1))),
        )
        self.add_widget(line_l)
        self.add_widget(lbl)
        self.add_widget(line_r)


class LoginScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._loading = False
        self._build_ui()

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *_: setattr(self._bg, 'pos',  self.pos),
                   size=lambda *_: setattr(self._bg, 'size', self.size))

        self.add_widget(_Orb(BLUE,   size=(dp(280), dp(280)),
                              pos_hint={'center_x': 0.9, 'center_y': 0.88}))
        self.add_widget(_Orb(PURPLE, size=(dp(220), dp(220)),
                              pos_hint={'center_x': 0.1, 'center_y': 0.18}))

        outer = MDBoxLayout(orientation='vertical', padding=[dp(24), 0], spacing=0)

        brand = MDBoxLayout(orientation='vertical', spacing=dp(6),
                             size_hint_y=None, height=dp(148),
                             padding=[0, dp(48), 0, dp(12)])
        badge = MDCard(
            md_bg_color=(*BLUE[:3], 0.16), radius=[dp(20)],
            size_hint=(None, None), size=(dp(132), dp(30)),
            pos_hint={'center_x': 0.5}, orientation='horizontal',
            padding=[dp(10), dp(2)],
        )
        badge.add_widget(MDLabel(text='🎓  ISSAM v2.0', halign='center',
                                  font_style='Caption',
                                  theme_text_color='Custom', text_color=BLUE))
        brand.add_widget(badge)
        brand.add_widget(MDLabel(text='Bon retour 👋', halign='center',
                                  font_style='H4',
                                  theme_text_color='Custom', text_color=T1))
        brand.add_widget(MDLabel(text='Connectez-vous à votre espace',
                                  halign='center', font_style='Body1',
                                  theme_text_color='Custom', text_color=T2))
        outer.add_widget(brand)

        card = MDCard(
            orientation='vertical', padding=[dp(22), dp(22)], spacing=dp(14),
            md_bg_color=(*CARD1[:3], 0.94), radius=[dp(28)],
            elevation=10, size_hint_y=None, height=dp(450),
        )

        self.google_btn = GoogleSignInButton(on_press_cb=self._google_sign_in)
        card.add_widget(self.google_btn)
        card.add_widget(_Divider())

        email_box = MDBoxLayout(orientation='vertical', spacing=dp(2),
                                 size_hint_y=None, height=dp(70))
        email_box.add_widget(MDLabel(text='Email', font_style='Caption',
                                      theme_text_color='Custom', text_color=T2,
                                      size_hint_y=None, height=dp(16)))
        self.email_field = MDTextField(
            hint_text='nom@etablissement.cm',
            icon_right='email-outline',
            mode='rectangle',
            text='enseignant@example.com',
            size_hint_y=None, height=dp(50),
        )
        self.email_field.bind(text=self._clear_error)
        email_box.add_widget(self.email_field)
        card.add_widget(email_box)

        pwd_box = MDBoxLayout(orientation='vertical', spacing=dp(2),
                               size_hint_y=None, height=dp(70))
        pwd_hdr = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(16))
        pwd_hdr.add_widget(MDLabel(text='Mot de passe', font_style='Caption',
                                    theme_text_color='Custom', text_color=T2))
        pwd_hdr.add_widget(Widget())
        self.forgot_btn = MDFlatButton(
            text='Oublié ?', size_hint=(None, 1), width=dp(62),
            theme_text_color='Custom', text_color=BLUE,
        )
        self.forgot_btn.bind(on_release=self._go_forgot)
        pwd_hdr.add_widget(self.forgot_btn)
        self.password_field = MDTextField(
            hint_text='••••••••',
            icon_right='eye-outline',
            mode='rectangle', password=True,
            text='password123',
            size_hint_y=None, height=dp(50),
        )
        self.password_field.bind(text=self._clear_error)
        pwd_box.add_widget(pwd_hdr)
        pwd_box.add_widget(self.password_field)
        card.add_widget(pwd_box)

        self.error_lbl = MDLabel(
            text='', halign='center', font_style='Caption',
            theme_text_color='Custom', text_color=RED,
            size_hint_y=None, height=dp(20),
        )
        card.add_widget(self.error_lbl)

        self.login_btn = MDRaisedButton(
            text='Se connecter →',
            size_hint_x=1, md_bg_color=BLUE,
        )
        self.login_btn.bind(on_release=self._do_login)
        card.add_widget(self.login_btn)

        reg_row = MDBoxLayout(orientation='horizontal', size_hint_y=None,
                               height=dp(36), spacing=dp(4))
        reg_row.add_widget(Widget())
        reg_row.add_widget(MDLabel(text="Pas encore de compte ?",
                                    font_style='Caption', size_hint=(None, 1),
                                    width=dp(148),
                                    theme_text_color='Custom', text_color=T2))
        reg_btn = MDFlatButton(
            text="S'inscrire", size_hint=(None, 1), width=dp(80),
            theme_text_color='Custom', text_color=BLUE,
        )
        reg_btn.bind(on_release=self._go_register)
        reg_row.add_widget(reg_btn)
        reg_row.add_widget(Widget())
        card.add_widget(reg_row)

        outer.add_widget(card)

        footer = MDBoxLayout(orientation='vertical', size_hint_y=None,
                              height=dp(52), padding=[0, dp(10)])
        footer.add_widget(MDLabel(
            text='🔒  Connexion chiffrée  ·  Offline-First  ·  ISSAM',
            halign='center', font_style='Caption',
            theme_text_color='Custom', text_color=T3,
        ))
        outer.add_widget(Widget())
        outer.add_widget(footer)
        self.add_widget(outer)

    def on_enter(self):
        self.opacity = 0
        Animation(opacity=1, duration=0.45).start(self)

    def _go_forgot(self, *_):
        try:
            self.manager.current = 'forgot_password'
        except Exception as e:
            print(f"[Nav] forgot_password error: {e}")

    def _go_register(self, *_):
        try:
            self.manager.current = 'register'
        except Exception as e:
            print(f"[Nav] register error: {e}")

    def _clear_error(self, *_):
        self.error_lbl.text = ''

    def _do_login(self, *_):
        if self._loading:
            return
        email    = self.email_field.text.strip()
        password = self.password_field.text

        if not email or not password:
            self._show_error('Veuillez remplir tous les champs.')
            return
        if not _EMAIL_RE.match(email):
            self._show_error('Adresse email invalide.')
            return

        self._set_loading(True)
        try:
            App.get_running_app().auth_service.sign_in(
                email, password,
                on_success=self._on_auth_success,
                on_error=self._on_auth_error,
            )
        except Exception as e:
            self._set_loading(False)
            self._show_error(f'Erreur: {e}')

    def _google_sign_in(self):
        if self._loading:
            return
        self._set_loading(True, label='Ouverture Google…')
        try:
            App.get_running_app().auth_service.sign_in_with_google(
                on_success=self._on_auth_success,
                on_error=self._on_auth_error,
            )
        except Exception as e:
            self._set_loading(False)
            self._show_error(f'Erreur Google: {e}')

    def _on_auth_success(self, profile):
        app = App.get_running_app()
        app.current_user = profile
        self._set_loading(False)

        if not profile.get('email_verified', True) \
                and profile.get('provider') == 'email':
            try:
                self.manager.current = 'verify_email'
            except Exception:
                self.manager.current = 'dashboard'
            return

        Animation(opacity=0, duration=0.3).start(self)
        Clock.schedule_once(self._go_dashboard, 0.35)

    def _go_dashboard(self, *_):
        try:
            if self.manager:
                self.manager.current = 'dashboard'
        except Exception as e:
            print(f"[Login] nav error: {e}")

    def _on_auth_error(self, message):
        self._set_loading(False)
        self._show_error(message)

    def _set_loading(self, loading, label=None):
        self._loading           = loading
        self.login_btn.disabled = loading
        self.google_btn.disabled = loading
        if loading:
            self.login_btn.text = label or 'Connexion…'
        else:
            self.login_btn.text = 'Se connecter →'

    def _show_error(self, msg):
        self.error_lbl.text = msg
        shake = (Animation(x=self.error_lbl.x + dp(8), duration=0.04) +
                 Animation(x=self.error_lbl.x - dp(8), duration=0.04) +
                 Animation(x=self.error_lbl.x,          duration=0.04))
        shake.start(self.error_lbl)
