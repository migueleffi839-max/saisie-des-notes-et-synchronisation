"""
Forgot Password Screen — Reset par email ou mode local
ISSAM v2.0 — Corrigé
"""
import re
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.card import MDCard
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.app import App
from core.theme.theme_manager import BG, CARD1, BLUE, GREEN, RED, AMBER, T1, T2, T3

_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


class ForgotPasswordScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._loading = False
        self._sent = False
        self._build_ui()

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *_: setattr(self._bg, 'pos', self.pos),
                   size=lambda *_: setattr(self._bg, 'size', self.size))

        outer = MDBoxLayout(orientation='vertical', padding=[dp(24), 0], spacing=0)

        # Retour
        top = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(68),
                           padding=[0, dp(20), 0, 0])
        back_btn = MDFlatButton(text='← Retour', size_hint=(None, 1), width=dp(90),
                                 theme_text_color='Custom', text_color=BLUE)
        back_btn.bind(on_release=lambda *_: self._go_back())
        top.add_widget(back_btn)
        top.add_widget(Widget())
        outer.add_widget(top)

        # Icon + titre
        head = MDBoxLayout(orientation='vertical', spacing=dp(8),
                            size_hint_y=None, height=dp(110), padding=[0, dp(10), 0, 0])
        head.add_widget(MDLabel(text='🔑', halign='center', font_style='H2',
                                 size_hint_y=None, height=dp(50)))
        head.add_widget(MDLabel(text='Mot de passe oublié', halign='center',
                                 font_style='H5', theme_text_color='Custom', text_color=T1))
        head.add_widget(MDLabel(text='Entrez votre email — nous vous enverrons un lien',
                                 halign='center', font_style='Body2',
                                 theme_text_color='Custom', text_color=T2))
        outer.add_widget(head)

        # Card
        card = MDCard(
            orientation='vertical', padding=[dp(22), dp(22)], spacing=dp(16),
            md_bg_color=(*CARD1[:3], 0.95), radius=[dp(28)],
            elevation=6, size_hint_y=None, height=dp(240),
        )

        email_box = MDBoxLayout(orientation='vertical', spacing=dp(2),
                                 size_hint_y=None, height=dp(70))
        email_box.add_widget(MDLabel(text='Adresse email', font_style='Caption',
                                      theme_text_color='Custom', text_color=T2,
                                      size_hint_y=None, height=dp(16)))
        self.email_field = MDTextField(
            hint_text='votre@email.cm',
            icon_right='email-outline',
            mode='rectangle', size_hint_y=None, height=dp(50),
        )
        email_box.add_widget(self.email_field)
        card.add_widget(email_box)

        self.feedback_lbl = MDLabel(
            text='', halign='center', font_style='Caption',
            theme_text_color='Custom', text_color=RED,
            size_hint_y=None, height=dp(20),
        )
        card.add_widget(self.feedback_lbl)

        self.send_btn = MDRaisedButton(
            text='Envoyer le lien de réinitialisation',
            size_hint_x=1, md_bg_color=BLUE,
        )
        self.send_btn.bind(on_release=self._do_send)
        card.add_widget(self.send_btn)

        back_link = MDFlatButton(
            text='Retour à la connexion',
            size_hint_x=1,
            theme_text_color='Custom', text_color=T2,
        )
        back_link.bind(on_release=lambda *_: self._go_back())
        card.add_widget(back_link)

        outer.add_widget(card)
        outer.add_widget(Widget())
        self.add_widget(outer)

    def on_enter(self):
        self.opacity = 0
        self._sent = False
        self.email_field.text = ''
        self.feedback_lbl.text = ''
        self.send_btn.text = 'Envoyer le lien de réinitialisation'
        self.send_btn.md_bg_color = BLUE
        Animation(opacity=1, duration=0.4).start(self)

    def _go_back(self):
        try:
            self.manager.current = 'login'
        except Exception as e:
            print(f"[Nav] {e}")

    def _do_send(self, *_):
        if self._loading or self._sent:
            return
        email = self.email_field.text.strip()
        if not email:
            self._show_feedback('Veuillez entrer votre email.', RED)
            return
        if not _EMAIL_RE.match(email):
            self._show_feedback('Email invalide.', RED)
            return

        self._set_loading(True)
        try:
            App.get_running_app().auth_service.send_password_reset(
                email,
                on_success=self._on_sent,
                on_error=self._on_error,
            )
        except Exception as e:
            self._set_loading(False)
            self._show_feedback(str(e), RED)

    def _on_sent(self):
        self._set_loading(False)
        self._sent = True
        self.send_btn.text = '✓ Email envoyé !'
        self.send_btn.md_bg_color = GREEN
        self._show_feedback(
            'Un lien de réinitialisation a été envoyé.\n(Mode local : utilisez password123)',
            GREEN
        )
        Clock.schedule_once(lambda dt: self._go_back(), 3.5)

    def _on_error(self, msg):
        self._set_loading(False)
        self._show_feedback(msg, RED)

    def _set_loading(self, v):
        self._loading = v
        self.send_btn.disabled = v
        if v:
            self.send_btn.text = 'Envoi en cours…'

    def _show_feedback(self, msg, color):
        self.feedback_lbl.text_color = color
        self.feedback_lbl.text = msg
