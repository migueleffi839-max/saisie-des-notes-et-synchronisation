"""
Students Screen — CRUD complet (ajouter/modifier/supprimer élèves)
ISSAM v4.0
"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton, MDRaisedButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.dialog import MDDialog
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.widget import Widget
from kivy.app import App
from widgets.bottom_nav import BottomNavBar
from core.theme.theme_manager import (
    BG, CARD1, CARD2, BLUE, BLUE_A, GREEN, GREEN_A, AMBER, AMBER_A,
    RED, RED_A, T1, T2, T3, grade_color, grade_bg_color
)


class StudentRow(MDCard):
    def __init__(self, rank, student, on_edit, on_delete, **kwargs):
        super().__init__(**kwargs)
        self._student = student
        self.orientation = 'horizontal'
        self.padding = [dp(14), dp(12)]
        self.spacing = dp(12)
        self.md_bg_color = CARD1
        self.radius = [dp(18)]
        self.size_hint_y = None
        self.height = dp(70)
        self.elevation = 0

        moy = student.get('moyenne')
        try:
            moy_f = round(float(moy), 2) if moy is not None else None
        except Exception:
            moy_f = None

        gcolor = grade_color(moy_f)
        gbg    = grade_bg_color(moy_f)

        rank_lbl = MDLabel(text=str(rank), halign='center', font_style='Body2',
                            size_hint=(None, 1), width=dp(24),
                            theme_text_color='Custom', text_color=T3)

        initial = (student.get('prenom') or 'E')[0].upper()
        av = MDCard(md_bg_color=(*gcolor[:3], 0.20), radius=[dp(14)],
                     size_hint=(None, None), size=(dp(42), dp(42)),
                     orientation='horizontal', pos_hint={'center_y': 0.5})
        av.add_widget(MDLabel(text=initial, halign='center', font_style='H6',
                               theme_text_color='Custom', text_color=gcolor))

        info = MDBoxLayout(orientation='vertical', spacing=dp(3))
        info.add_widget(MDLabel(
            text=f"{student.get('nom','—')} {student.get('prenom','')}",
            font_style='Subtitle2', theme_text_color='Custom', text_color=T1,
        ))
        sexe_icon = '♂' if student.get('sexe') == 'M' else '♀'
        info.add_widget(MDLabel(
            text=f"{sexe_icon}  {student.get('matricule','—')}",
            font_style='Caption', theme_text_color='Custom', text_color=T3,
        ))

        grade_chip = MDCard(
            md_bg_color=gbg, radius=[dp(12)],
            size_hint=(None, None), size=(dp(56), dp(36)),
            orientation='horizontal', padding=[dp(4), dp(2)],
            pos_hint={'center_y': 0.5},
        )
        grade_chip.add_widget(MDLabel(
            text=f'{moy_f}/20' if moy_f is not None else 'N/A',
            halign='center', font_style='Body2',
            theme_text_color='Custom', text_color=gcolor,
        ))

        actions = MDBoxLayout(orientation='horizontal', spacing=dp(2),
                               size_hint=(None, 1), width=dp(72))
        edit_btn = MDIconButton(icon='pencil', theme_icon_color='Custom', icon_color=BLUE,
                                 size_hint=(None, None), size=(dp(32), dp(32)),
                                 pos_hint={'center_y': 0.5})
        edit_btn.bind(on_release=lambda x: on_edit(student))
        del_btn = MDIconButton(icon='delete', theme_icon_color='Custom',
                                icon_color=(0.9, 0.3, 0.3, 1),
                                size_hint=(None, None), size=(dp(32), dp(32)),
                                pos_hint={'center_y': 0.5})
        del_btn.bind(on_release=lambda x: on_delete(student))
        actions.add_widget(edit_btn)
        actions.add_widget(del_btn)

        self.add_widget(rank_lbl)
        self.add_widget(av)
        self.add_widget(info)
        self.add_widget(Widget())
        self.add_widget(grade_chip)
        self.add_widget(actions)


class StudentFormContent(MDBoxLayout):
    def __init__(self, student=None, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = dp(12)
        self.padding = [dp(4), dp(8)]
        self.size_hint_y = None
        self.height = dp(300)

        self.prenom_field = MDTextField(
            hint_text='Prénom',
            mode='rectangle',
            text=student.get('prenom', '') if student else '',
        )
        self.nom_field = MDTextField(
            hint_text='Nom de famille',
            mode='rectangle',
            text=student.get('nom', '') if student else '',
        )
        self.matricule_field = MDTextField(
            hint_text='Matricule (ex: MAT2024001)',
            mode='rectangle',
            text=student.get('matricule', '') if student else '',
        )

        # Sexe selector
        self._sexe = student.get('sexe', 'M') if student else 'M'
        sexe_row = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(44),
                                spacing=dp(8))
        self._sexe_lbl = MDLabel(text=f'Sexe : {"Masculin" if self._sexe == "M" else "Féminin"}',
                                  font_style='Body1', theme_text_color='Custom', text_color=T1)
        toggle_btn = MDRaisedButton(text='Changer', size_hint=(None, None), size=(dp(100), dp(38)))
        toggle_btn.bind(on_release=lambda x: self._toggle_sexe())
        sexe_row.add_widget(self._sexe_lbl)
        sexe_row.add_widget(toggle_btn)

        self.add_widget(self.prenom_field)
        self.add_widget(self.nom_field)
        self.add_widget(self.matricule_field)
        self.add_widget(sexe_row)

    def _toggle_sexe(self):
        self._sexe = 'F' if self._sexe == 'M' else 'M'
        self._sexe_lbl.text = f'Sexe : {"Masculin" if self._sexe == "M" else "Féminin"}'

    def get_values(self):
        return {
            'prenom': self.prenom_field.text.strip(),
            'nom': self.nom_field.text.strip(),
            'matricule': self.matricule_field.text.strip(),
            'sexe': self._sexe,
        }


class StudentsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._dialog = None

    def on_enter(self):
        self.clear_widgets()
        self._build_ui()

    def _get_classe(self):
        app = App.get_running_app()
        return getattr(app, 'selected_classe', None) or {}

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *a: setattr(self._bg, 'pos', self.pos),
                   size=lambda *a: setattr(self._bg, 'size', self.size))

        app = App.get_running_app()
        classe = self._get_classe()
        classe_uuid = classe.get('uuid', '')
        classe_nom = classe.get('nom', 'Classe')

        try:
            students = app.db_manager.get_students_with_averages(classe_uuid) if classe_uuid else []
        except Exception as e:
            print(f"[Students] Erreur: {e}")
            students = []

        root = MDBoxLayout(orientation='vertical')

        # Top bar
        topbar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(68),
                              padding=[dp(8), dp(14), dp(16), dp(4)], spacing=dp(4))
        back_btn = MDIconButton(icon='arrow-left', theme_icon_color='Custom', icon_color=T1)
        back_btn.bind(on_release=lambda x: self._go('classes'))
        topbar.add_widget(back_btn)

        title_box = MDBoxLayout(orientation='vertical', spacing=dp(1))
        title_box.add_widget(MDLabel(text=classe_nom, font_style='H5',
                                      theme_text_color='Custom', text_color=T1))
        title_box.add_widget(MDLabel(
            text=f'{len(students)} élève(s)',
            font_style='Caption', theme_text_color='Custom', text_color=T2,
        ))
        topbar.add_widget(title_box)
        topbar.add_widget(Widget())

        add_btn = MDRaisedButton(text='+ Élève', md_bg_color=BLUE,
                                  size_hint=(None, None), size=(dp(100), dp(38)),
                                  pos_hint={'center_y': 0.5})
        add_btn.bind(on_release=lambda x: self._show_add_dialog(classe_uuid))
        topbar.add_widget(add_btn)
        root.add_widget(topbar)

        # Actions barre
        action_bar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(52),
                                  padding=[dp(16), dp(4)], spacing=dp(8))
        notes_btn = MDRaisedButton(text='📝 Notes', md_bg_color=GREEN,
                                    size_hint=(None, None), size=(dp(110), dp(38)))
        notes_btn.bind(on_release=lambda x: self._go('evaluations'))
        action_bar.add_widget(notes_btn)
        action_bar.add_widget(Widget())
        root.add_widget(action_bar)

        # Liste des élèves
        scroll = MDScrollView()
        content = MDBoxLayout(orientation='vertical',
                               padding=[dp(16), dp(4), dp(16), dp(80)],
                               spacing=dp(8), size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))

        if not students:
            empty_box = MDBoxLayout(orientation='vertical', spacing=dp(12),
                                     size_hint_y=None, height=dp(200),
                                     padding=[dp(20), dp(40)])
            empty_box.add_widget(MDLabel(
                text='👨‍🎓', halign='center', font_style='H2',
                size_hint_y=None, height=dp(60),
            ))
            empty_box.add_widget(MDLabel(
                text='Aucun élève dans cette classe',
                halign='center', font_style='H6',
                theme_text_color='Custom', text_color=T1,
                size_hint_y=None, height=dp(36),
            ))
            empty_box.add_widget(MDLabel(
                text='Appuyez sur "+ Élève" pour ajouter des élèves.',
                halign='center', font_style='Body1',
                theme_text_color='Custom', text_color=T2,
                size_hint_y=None, height=dp(60),
            ))
            content.add_widget(empty_box)
        else:
            for i, stu in enumerate(students):
                row = StudentRow(
                    i + 1, stu,
                    on_edit=self._show_edit_dialog,
                    on_delete=self._confirm_delete,
                )
                content.add_widget(row)

        scroll.add_widget(content)
        root.add_widget(scroll)
        root.add_widget(BottomNavBar(active_screen='students'))
        self.add_widget(root)

    # ──────────────────────── Dialogs ─────────────────────────────────────────

    def _show_add_dialog(self, classe_uuid):
        if self._dialog:
            self._dialog.dismiss()
        form = StudentFormContent()
        self._dialog = MDDialog(
            title='Ajouter un élève',
            type='custom',
            content_cls=form,
            buttons=[
                MDFlatButton(text='Annuler', on_release=lambda x: self._dialog.dismiss()),
                MDRaisedButton(text='Ajouter', md_bg_color=BLUE,
                               on_release=lambda x: self._do_add(classe_uuid, form)),
            ],
        )
        self._dialog.open()

    def _do_add(self, classe_uuid, form):
        vals = form.get_values()
        if not vals['prenom'] or not vals['nom']:
            return
        app = App.get_running_app()
        matricule = vals['matricule'] or f"MAT{__import__('uuid').uuid4().hex[:8].upper()}"
        app.db_manager.add_student(
            classe_uuid, vals['prenom'], vals['nom'],
            matricule, vals['sexe']
        )
        self._dialog.dismiss()
        self._dialog = None
        self.on_enter()

    def _show_edit_dialog(self, student):
        if self._dialog:
            self._dialog.dismiss()
        form = StudentFormContent(student=student)
        self._dialog = MDDialog(
            title='Modifier l\'élève',
            type='custom',
            content_cls=form,
            buttons=[
                MDFlatButton(text='Annuler', on_release=lambda x: self._dialog.dismiss()),
                MDRaisedButton(text='Enregistrer', md_bg_color=BLUE,
                               on_release=lambda x: self._do_edit(student['uuid'], form)),
            ],
        )
        self._dialog.open()

    def _do_edit(self, eleve_uuid, form):
        vals = form.get_values()
        if not vals['prenom'] or not vals['nom']:
            return
        app = App.get_running_app()
        matricule = vals['matricule'] or f"MAT{eleve_uuid[:8].upper()}"
        app.db_manager.update_student(
            eleve_uuid, vals['prenom'], vals['nom'],
            matricule, vals['sexe']
        )
        self._dialog.dismiss()
        self._dialog = None
        self.on_enter()

    def _confirm_delete(self, student):
        if self._dialog:
            self._dialog.dismiss()
        name = f"{student.get('prenom','')} {student.get('nom','')}"
        self._dialog = MDDialog(
            title='Supprimer l\'élève ?',
            text=f'"{name}" sera supprimé de la classe.',
            buttons=[
                MDFlatButton(text='Annuler', on_release=lambda x: self._dialog.dismiss()),
                MDRaisedButton(text='Supprimer', md_bg_color=(0.9, 0.3, 0.3, 1),
                               on_release=lambda x: self._do_delete(student['uuid'])),
            ],
        )
        self._dialog.open()

    def _do_delete(self, eleve_uuid):
        app = App.get_running_app()
        app.db_manager.delete_student(eleve_uuid)
        self._dialog.dismiss()
        self._dialog = None
        self.on_enter()

    def _go(self, screen):
        try:
            self.manager.current = screen
        except Exception as e:
            print(f"[StudentsScreen] Nav error: {e}")
