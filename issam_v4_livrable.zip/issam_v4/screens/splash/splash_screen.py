"""
Splash Screen — Animated logo + session restore
ISSAM v3.0 — FIX: dangling except block, nav race, _SpinRing clock leak
"""
import math
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivy.uix.widget import Widget
from kivy.graphics import Color, Ellipse, RoundedRectangle, Line
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.app import App
from core.theme.theme_manager import BG, CARD1, BLUE, PURPLE, T1, T2, T3


class _SpinRing(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._a = 0
        self._ev = None
        self.bind(pos=self._draw, size=self._draw)

    def on_parent(self, instance, parent):
        if parent is not None:
            if not self._ev:
                self._ev = Clock.schedule_interval(self._tick, 1 / 30)
        else:
            if self._ev:
                self._ev.cancel()
                self._ev = None

    def _tick(self, dt):
        self._a = (self._a + 2) % 360
        self._draw()

    def _draw(self, *_):
        self.canvas.clear()
        cx, cy = self.center_x, self.center_y
        r = min(self.width, self.height) / 2
        with self.canvas:
            Color(0.231, 0.510, 0.965, 0.10)
            Ellipse(pos=(cx - r - dp(20), cy - r - dp(20)),
                    size=(r * 2 + dp(40), r * 2 + dp(40)))
            Color(*CARD1)
            Ellipse(pos=(cx - r, cy - r), size=(r * 2, r * 2))
            Color(0.231, 0.510, 0.965, 1)
            pts = []
            for i in range(100):
                a = math.radians(self._a + i * 2)
                pts += [cx + (r - dp(5)) * math.cos(a), cy + (r - dp(5)) * math.sin(a)]
            if len(pts) >= 4:
                Line(points=pts, width=dp(3))
            Color(0.545, 0.361, 0.965, 0.7)
            pts2 = []
            for i in range(60):
                a = math.radians(-self._a + 180 + i * 2)
                pts2 += [cx + (r - dp(14)) * math.cos(a), cy + (r - dp(14)) * math.sin(a)]
            if len(pts2) >= 4:
                Line(points=pts2, width=dp(2))
            Color(0.231, 0.510, 0.965, 1)
            d = dp(11)
            Ellipse(pos=(cx - d, cy - d), size=(d * 2, d * 2))


class SplashScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._build_ui()

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *_: setattr(self._bg, 'pos',  self.pos),
                  size=lambda *_: setattr(self._bg, 'size', self.size))

        root = MDBoxLayout(orientation='vertical', padding=dp(40), spacing=dp(18))
        root.add_widget(Widget())
        root.add_widget(_SpinRing(size_hint=(None, None), size=(dp(110), dp(110)),
                                  pos_hint={'center_x': 0.5}))
        self.name_lbl = MDLabel(text='ISSAM', halign='center', font_style='H3',
                                theme_text_color='Custom', text_color=(*BLUE[:3], 0))
        self.sub_lbl  = MDLabel(text='Système de Saisie de Notes',
                                halign='center', font_style='H6',
                                theme_text_color='Custom', text_color=(*T1[:3], 0))
        self.tag_lbl  = MDLabel(text='Enseignez. Évaluez. Synchronisez.',
                                halign='center', font_style='Caption',
                                theme_text_color='Custom', text_color=(*T2[:3], 0))
        self.ver_lbl  = MDLabel(text='v3.0  ·  Offline-First  ·  SQLite',
                                halign='center', font_style='Caption',
                                theme_text_color='Custom', text_color=(*T3[:3], 0))
        for w in [self.name_lbl, self.sub_lbl, self.tag_lbl,
                  Widget(size_hint_y=None, height=dp(8)), self.ver_lbl]:
            root.add_widget(w)
        root.add_widget(Widget())
        self.add_widget(root)

    def on_enter(self):
        Clock.schedule_once(self._animate, 0.3)

    def _fade(self, lbl, delay, dur=0.6):
        Clock.schedule_once(
            lambda dt: Animation(text_color=(*lbl.text_color[:3], 1),
                                 duration=dur).start(lbl), delay)

    def _animate(self, dt):
        self._fade(self.name_lbl, 0.0)
        self._fade(self.sub_lbl,  0.3)
        self._fade(self.tag_lbl,  0.5)
        self._fade(self.ver_lbl,  0.7)
        Clock.schedule_once(self._try_restore, 2.4)

    def _try_restore(self, dt):
        app = App.get_running_app()
        if app.auth_service:
            try:
                app.auth_service.restore_session(
                    on_success=self._on_session_found,
                    on_no_session=self._leave_to_login,
                )
            except Exception as e:
                print(f"[Splash] restore_session error: {e}")
                self._leave_to_login()
        else:
            self._leave_to_login()

    def _on_session_found(self, profile):
        App.get_running_app().current_user = profile
        target = 'dashboard' if profile.get('email_verified', True) else 'verify_email'
        self._leave_to(target)

    def _leave_to_login(self, *_):
        self._leave_to('login')

    def _leave_to(self, screen):
        Animation(opacity=0, duration=0.4).start(self)

        def _nav(dt):
            try:
                if self.manager:
                    self.manager.current = screen
            except Exception as e:
                print(f"[Splash] nav to {screen} error: {e}")

        Clock.schedule_once(_nav, 0.45)
