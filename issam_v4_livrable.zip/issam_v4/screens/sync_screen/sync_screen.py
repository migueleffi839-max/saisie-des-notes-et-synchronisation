"""
Sync Screen — Cloud synchronisation manager
ISSAM v3.0 — FIX: _go_back undefined, Clock+setattr race, live DB stats
"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton, MDRaisedButton, MDFlatButton
from kivymd.uix.progressbar import MDProgressBar
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.app import App
from kivy.clock import Clock
from kivy.animation import Animation
from widgets.bottom_nav import BottomNavBar
from core.theme.theme_manager import (
    BG, CARD1, CARD2, BLUE, BLUE_A, GREEN, GREEN_A,
    AMBER, AMBER_A, RED, RED_A, T1, T2, T3
)


class SyncItemRow(MDBoxLayout):
    def __init__(self, icon, title, subtitle, status, status_color, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = dp(58)
        self.spacing = dp(12)
        self.padding = [dp(12), dp(8)]

        with self.canvas.before:
            Color(*CARD1)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(16)])
        self.bind(pos=self._u, size=self._u)

        icon_card = MDCard(md_bg_color=(*status_color[:3], 0.15), radius=[dp(12)],
                           size_hint=(None, None), size=(dp(38), dp(38)),
                           pos_hint={'center_y': 0.5})
        icon_card.add_widget(MDLabel(text=icon, halign='center', font_style='Body1'))

        info = MDBoxLayout(orientation='vertical', spacing=dp(2))
        info.add_widget(MDLabel(text=title, font_style='Body2',
                                theme_text_color='Custom', text_color=T1))
        info.add_widget(MDLabel(text=subtitle, font_style='Caption',
                                theme_text_color='Custom', text_color=T2))

        status_lbl = MDLabel(text=status, halign='right', font_style='Caption',
                             size_hint=(None, 1), width=dp(80),
                             theme_text_color='Custom', text_color=status_color)

        self.add_widget(icon_card)
        self.add_widget(info)
        self.add_widget(status_lbl)

    def _u(self, *a):
        self._bg.pos = self.pos
        self._bg.size = self.size


class SyncScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._syncing = False

    def on_enter(self):
        self._syncing = False
        self.clear_widgets()
        self._build_ui()

    # ── FIX: _go_back was called but never defined ─────────────────────────────
    def _go_back(self):
        try:
            self.manager.current = 'dashboard'
        except Exception as e:
            print(f"[SyncScreen] nav error: {e}")

    def _go(self, screen):
        try:
            self.manager.current = screen
        except Exception as e:
            print(f"[SyncScreen] nav to {screen} error: {e}")

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg_rect = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *a: setattr(self._bg_rect, 'pos', self.pos),
                  size=lambda *a: setattr(self._bg_rect, 'size', self.size))

        app = App.get_running_app()
        sync_stats = app.db_manager.get_sync_stats()
        pending = sync_stats.get('pending', 0)
        synced  = sync_stats.get('synced', 0)
        errors  = sync_stats.get('errors', 0)
        total   = max(synced + pending, 1)
        pct     = int(synced / total * 100)

        status_color = GREEN if pending == 0 else (AMBER if pending < 5 else RED)
        status_text  = ('✓  Tout synchronisé' if pending == 0
                        else f'⏳  {pending} note(s) en attente')

        root = MDBoxLayout(orientation='vertical')

        # ── Top bar ────────────────────────────────────────────────────────────
        topbar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(68),
                             padding=[dp(8), dp(14), dp(16), dp(4)], spacing=dp(4))
        back_btn = MDIconButton(icon='arrow-left', theme_icon_color='Custom', icon_color=T1)
        back_btn.bind(on_release=lambda x: self._go_back())
        topbar.add_widget(back_btn)
        t_box = MDBoxLayout(orientation='vertical', spacing=dp(1))
        t_box.add_widget(MDLabel(text='Synchronisation', font_style='H5',
                                 theme_text_color='Custom', text_color=T1))
        t_box.add_widget(MDLabel(text=f'{synced} synced · {pending} en attente · {errors} erreur(s)',
                                 font_style='Caption', theme_text_color='Custom', text_color=T2))
        topbar.add_widget(t_box)
        topbar.add_widget(Widget())
        root.add_widget(topbar)

        scroll = MDScrollView()
        body = MDBoxLayout(orientation='vertical',
                           padding=[dp(16), dp(4), dp(16), dp(90)],
                           spacing=dp(12), size_hint_y=None)
        body.bind(minimum_height=body.setter('height'))

        # ── Hero card ──────────────────────────────────────────────────────────
        hero = MDCard(orientation='vertical', padding=[dp(20), dp(18)], spacing=dp(12),
                      md_bg_color=CARD1, radius=[dp(24)],
                      size_hint_y=None, height=dp(196), elevation=0)

        icon_row = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(48))
        icon_row.add_widget(MDLabel(text='☁', halign='center', font_style='H3',
                                    size_hint=(None, 1), width=dp(56)))
        icon_row.add_widget(Widget())
        self.status_lbl = MDLabel(text=status_text, halign='right',
                                  font_style='Subtitle2',
                                  theme_text_color='Custom', text_color=status_color)
        icon_row.add_widget(self.status_lbl)

        self.progress_bar = MDProgressBar(value=pct, color=status_color,
                                          size_hint_y=None, height=dp(6))
        pct_row = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(20))
        pct_row.add_widget(MDLabel(text='Progression', font_style='Caption',
                                   theme_text_color='Custom', text_color=T3))
        pct_row.add_widget(Widget())
        pct_row.add_widget(MDLabel(text=f'{pct}%', halign='right',
                                   font_style='Caption',
                                   theme_text_color='Custom', text_color=status_color,
                                   size_hint=(None, 1), width=dp(40)))

        hero.add_widget(icon_row)
        hero.add_widget(self.status_lbl if False else Widget(size_hint_y=None, height=dp(0)))
        hero.add_widget(self.progress_bar)
        hero.add_widget(pct_row)
        body.add_widget(hero)

        # ── Sync button ────────────────────────────────────────────────────────
        self.sync_btn = MDRaisedButton(
            text='☁  Synchroniser maintenant',
            size_hint_x=1, md_bg_color=BLUE,
        )
        self.sync_btn.bind(on_release=self._start_sync)
        if pending == 0:
            self.sync_btn.md_bg_color = (*GREEN[:3], 0.5)
            self.sync_btn.disabled = True
        body.add_widget(self.sync_btn)

        # Retry errors button
        if errors > 0:
            retry_btn = MDFlatButton(
                text=f'↺  Relancer {errors} erreur(s)',
                theme_text_color='Custom', text_color=AMBER,
                size_hint_x=1,
            )
            retry_btn.bind(on_release=self._retry_errors)
            body.add_widget(retry_btn)

        # ── Network status ─────────────────────────────────────────────────────
        net_card = MDCard(orientation='horizontal', padding=[dp(14), dp(12)],
                          spacing=dp(12), md_bg_color=CARD1, radius=[dp(18)],
                          size_hint_y=None, height=dp(56), elevation=0)
        net_card.add_widget(MDLabel(text='🌐', halign='center', font_style='H6',
                                    size_hint=(None, 1), width=dp(36)))
        net_info = MDBoxLayout(orientation='vertical', spacing=dp(2))
        net_info.add_widget(MDLabel(text='Réseau disponible', font_style='Body2',
                                    theme_text_color='Custom', text_color=T1))
        net_info.add_widget(MDLabel(text='Mode offline-first  ·  Sync auto',
                                    font_style='Caption',
                                    theme_text_color='Custom', text_color=T2))
        net_dot = MDCard(md_bg_color=(*GREEN[:3], 0.20), radius=[dp(8)],
                         size_hint=(None, None), size=(dp(10), dp(10)),
                         pos_hint={'center_y': 0.5})
        net_card.add_widget(net_info)
        net_card.add_widget(Widget())
        net_card.add_widget(net_dot)
        body.add_widget(net_card)

        # ── Pending items from real DB ─────────────────────────────────────────
        if pending > 0:
            body.add_widget(MDLabel(text='En attente de synchronisation',
                                    font_style='Subtitle2',
                                    theme_text_color='Custom', text_color=T1,
                                    size_hint_y=None, height=dp(28)))
            body.add_widget(SyncItemRow('📝', f'{pending} note(s)',
                                        'SQLite → Serveur', '⏳ En attente', AMBER,
                                        size_hint_y=None, height=dp(58)))
            body.add_widget(Widget(size_hint_y=None, height=dp(6)))

        # ── Sync history from real DB ──────────────────────────────────────────
        body.add_widget(MDLabel(text='Historique', font_style='Subtitle2',
                                theme_text_color='Custom', text_color=T1,
                                size_hint_y=None, height=dp(28)))

        logs = app.db_manager.get_recent_sync_logs(limit=5)
        if logs:
            for log in logs:
                ns = log.get('notes_synced', 0)
                nf = log.get('notes_failed', 0)
                status = '✓ Synced' if nf == 0 else f'⚠ {nf} erreur(s)'
                color  = GREEN if nf == 0 else AMBER
                body.add_widget(SyncItemRow('✅' if nf == 0 else '⚠️',
                                            f'{ns} note(s) synchronisée(s)',
                                            log.get('started_at', '')[:16],
                                            status, color,
                                            size_hint_y=None, height=dp(58)))
                body.add_widget(Widget(size_hint_y=None, height=dp(6)))
        else:
            body.add_widget(MDLabel(text='Aucun historique de synchronisation.',
                                    font_style='Body2', halign='center',
                                    theme_text_color='Custom', text_color=T3,
                                    size_hint_y=None, height=dp(48)))

        scroll.add_widget(body)
        root.add_widget(scroll)
        root.add_widget(BottomNavBar(active_screen='sync'))
        self.add_widget(root)

    def _start_sync(self, *a):
        if self._syncing:
            return
        self._syncing = True
        self.sync_btn.text = '⟳  Synchronisation…'
        self.sync_btn.disabled = True

        Animation(value=100, duration=2.0).start(self.progress_bar)

        def _finish(dt):
            app = App.get_running_app()
            try:
                pending = app.db_manager.get_sync_stats().get('pending', 0)
                app.db_manager.mark_all_synced()
                app.db_manager.log_sync_result(synced=pending, failed=0)
            except Exception as e:
                print(f"[SyncScreen] DB error: {e}")
            self.status_lbl.text = '✓  Synchronisation réussie !'
            self.status_lbl.text_color = GREEN
            self.sync_btn.text = '✓  Terminé'
            self.sync_btn.md_bg_color = (*GREEN[:3], 0.5)
            self._syncing = False
            # FIX: use proper method, not lambda+setattr in clock
            Clock.schedule_once(lambda dt2: self._go('dashboard'), 1.5)

        Clock.schedule_once(_finish, 2.2)

    def _retry_errors(self, *_):
        try:
            App.get_running_app().db_manager.reset_errors_to_pending()
            self.on_enter()
        except Exception as e:
            print(f"[SyncScreen] retry error: {e}")
