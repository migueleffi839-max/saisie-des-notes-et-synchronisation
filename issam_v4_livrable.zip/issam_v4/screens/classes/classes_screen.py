"""
Classes Screen — CRUD complet, données filtrées par enseignant connecté
ISSAM v4.0 — Aucune donnée de démo, tout est créé par l'utilisateur
"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton, MDRaisedButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.dialog import MDDialog
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.widget import Widget
from kivy.app import App
from widgets.bottom_nav import BottomNavBar
from core.theme.theme_manager import (
    BG, CARD1, BLUE, BLUE_A, PURPLE, PURPLE_A, GREEN, GREEN_A,
    AMBER, AMBER_A, T1, T2, T3
)

LEVEL_PALETTE = {
    '6ème':      (BLUE,   BLUE_A,   '🏫'),
    '5ème':      (PURPLE, PURPLE_A, '📚'),
    '4ème':      (GREEN,  GREEN_A,  '📖'),
    '3ème':      (BLUE,   BLUE_A,   '🏫'),
    '2nde':      (PURPLE, PURPLE_A, '📚'),
    '1ère':      (GREEN,  GREEN_A,  '🎯'),
    'Terminale': (AMBER,  AMBER_A,  '🎓'),
    'BTS1':      (BLUE,   BLUE_A,   '🎓'),
    'BTS2':      (PURPLE, PURPLE_A, '🎓'),
}

NIVEAUX = ['6ème', '5ème', '4ème', '3ème', '2nde', '1ère', 'Terminale', 'BTS1', 'BTS2']


class ClassCard(MDCard):
    def __init__(self, classe, student_count, on_delete, on_edit, **kwargs):
        super().__init__(**kwargs)
        self._classe = classe
        self._on_delete = on_delete
        self._on_edit = on_edit
        self.orientation     = 'horizontal'
        self.padding         = [dp(14), dp(14)]
        self.spacing         = dp(14)
        self.md_bg_color     = CARD1
        self.radius          = [dp(20)]
        self.size_hint_y     = None
        self.height          = dp(80)
        self.elevation       = 0
        self.ripple_behavior = True
        self.bind(on_release=lambda x: self._open())

        niveau = classe.get('niveau', '')
        color, bg, icon = LEVEL_PALETTE.get(niveau, (BLUE, BLUE_A, '📖'))

        badge = MDCard(md_bg_color=bg, radius=[dp(14)],
                        size_hint=(None, None), size=(dp(48), dp(48)),
                        orientation='horizontal', pos_hint={'center_y': 0.5})
        badge.add_widget(MDLabel(text=icon, halign='center', font_style='H6'))

        info = MDBoxLayout(orientation='vertical', spacing=dp(4))
        info.add_widget(MDLabel(text=classe.get('nom', '—'), font_style='Subtitle1',
                                 theme_text_color='Custom', text_color=T1))
        info.add_widget(MDLabel(
            text=f'{student_count} élève(s)  ·  {classe.get("annee_scolaire", "")}',
            font_style='Caption', theme_text_color='Custom', text_color=T2,
        ))

        actions = MDBoxLayout(orientation='horizontal', spacing=dp(2),
                               size_hint=(None, 1), width=dp(80))
        edit_btn = MDIconButton(icon='pencil', theme_icon_color='Custom',
                                 icon_color=BLUE, size_hint=(None, None),
                                 size=(dp(36), dp(36)),
                                 pos_hint={'center_y': 0.5})
        edit_btn.bind(on_release=lambda x: self._on_edit(classe))
        del_btn = MDIconButton(icon='delete', theme_icon_color='Custom',
                                icon_color=(0.9, 0.3, 0.3, 1), size_hint=(None, None),
                                size=(dp(36), dp(36)),
                                pos_hint={'center_y': 0.5})
        del_btn.bind(on_release=lambda x: self._on_delete(classe))
        actions.add_widget(edit_btn)
        actions.add_widget(del_btn)

        self.add_widget(badge)
        self.add_widget(info)
        self.add_widget(Widget())
        self.add_widget(actions)

    def _open(self):
        try:
            app = App.get_running_app()
            app.selected_classe = dict(self._classe)
            app.root.current = 'students'
        except Exception as e:
            print(f"[ClassCard] Navigation error: {e}")


class ClassFormContent(MDBoxLayout):
    def __init__(self, classe=None, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = dp(12)
        self.padding = [dp(4), dp(8)]
        self.size_hint_y = None
        self.height = dp(240)

        self.nom_field = MDTextField(
            hint_text='Nom de la classe (ex: 3ème A)',
            mode='rectangle',
            text=classe.get('nom', '') if classe else '',
        )
        self.add_widget(self.nom_field)

        self._niveau_idx = 0
        if classe:
            nv = classe.get('niveau', NIVEAUX[0])
            self._niveau_idx = NIVEAUX.index(nv) if nv in NIVEAUX else 0

        self._niveau_lbl = MDLabel(
            text=NIVEAUX[self._niveau_idx],
            halign='center', font_style='H6',
            theme_text_color='Custom', text_color=T1,
            size_hint_y=None, height=dp(36),
        )
        nav = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(48),
                           spacing=dp(8))
        prev_btn = MDRaisedButton(text='◀', size_hint=(None, None), size=(dp(48), dp(40)))
        prev_btn.bind(on_release=lambda x: self._prev())
        next_btn = MDRaisedButton(text='▶', size_hint=(None, None), size=(dp(48), dp(40)))
        next_btn.bind(on_release=lambda x: self._next())
        nav.add_widget(prev_btn)
        nav.add_widget(self._niveau_lbl)
        nav.add_widget(next_btn)
        self.add_widget(nav)

        annee = classe.get('annee_scolaire', '2025-2026') if classe else '2025-2026'
        self.annee_field = MDTextField(
            hint_text='Année scolaire (ex: 2025-2026)',
            mode='rectangle',
            text=annee,
        )
        self.add_widget(self.annee_field)

    def _prev(self):
        self._niveau_idx = (self._niveau_idx - 1) % len(NIVEAUX)
        self._niveau_lbl.text = NIVEAUX[self._niveau_idx]

    def _next(self):
        self._niveau_idx = (self._niveau_idx + 1) % len(NIVEAUX)
        self._niveau_lbl.text = NIVEAUX[self._niveau_idx]

    def get_values(self):
        return {
            'nom': self.nom_field.text.strip(),
            'niveau': NIVEAUX[self._niveau_idx],
            'annee_scolaire': self.annee_field.text.strip() or '2025-2026',
        }


class ClassesScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._dialog = None

    def on_enter(self):
        self.clear_widgets()
        self._build_ui()

    def _get_user_uuid(self):
        app = App.get_running_app()
        return (app.current_user or {}).get('uid', '')

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *a: setattr(self._bg, 'pos', self.pos),
                   size=lambda *a: setattr(self._bg, 'size', self.size))

        app = App.get_running_app()
        uid = self._get_user_uuid()
        try:
            classes_data = app.db_manager.get_classes_with_counts(enseignant_uuid=uid)
        except Exception as e:
            print(f"[Classes] Erreur: {e}")
            classes_data = []

        root = MDBoxLayout(orientation='vertical')

        # Top bar
        topbar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(68),
                              padding=[dp(8), dp(14), dp(16), dp(4)], spacing=dp(4))
        back_btn = MDIconButton(icon='arrow-left',
                                 theme_icon_color='Custom', icon_color=T1)
        back_btn.bind(on_release=lambda x: self._go('dashboard'))
        topbar.add_widget(back_btn)

        title_box = MDBoxLayout(orientation='vertical', spacing=dp(1))
        title_box.add_widget(MDLabel(text='Mes Classes', font_style='H5',
                                      theme_text_color='Custom', text_color=T1))
        title_box.add_widget(MDLabel(
            text=f'{len(classes_data)} classe(s)',
            font_style='Caption', theme_text_color='Custom', text_color=T2,
        ))
        topbar.add_widget(title_box)
        topbar.add_widget(Widget())

        add_btn = MDRaisedButton(text='+ Ajouter', md_bg_color=BLUE,
                                  size_hint=(None, None), size=(dp(110), dp(38)),
                                  pos_hint={'center_y': 0.5})
        add_btn.bind(on_release=lambda x: self._show_add_dialog())
        topbar.add_widget(add_btn)
        root.add_widget(topbar)

        # Stats chips
        total_eleves = sum(c.get('student_count', 0) for c in classes_data)
        summary = MDBoxLayout(orientation='horizontal', spacing=dp(10),
                               size_hint_y=None, height=dp(60),
                               padding=[dp(16), dp(4)])
        for label, value, color in [
            ('Classes', str(len(classes_data)), BLUE),
            ('Élèves', str(total_eleves), PURPLE),
        ]:
            chip = MDCard(md_bg_color=(*color[:3], 0.14), radius=[dp(14)],
                           orientation='vertical', padding=[dp(12), dp(4)],
                           size_hint=(None, None), size=(dp(90), dp(48)))
            chip.add_widget(MDLabel(text=value, halign='center', font_style='H6',
                                     theme_text_color='Custom', text_color=color))
            chip.add_widget(MDLabel(text=label, halign='center', font_style='Caption',
                                     theme_text_color='Custom', text_color=T3))
            summary.add_widget(chip)
        summary.add_widget(Widget())
        root.add_widget(summary)

        # Liste des classes
        scroll = MDScrollView()
        content = MDBoxLayout(orientation='vertical',
                               padding=[dp(16), dp(4), dp(16), dp(80)],
                               spacing=dp(10), size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))

        if not classes_data:
            empty_box = MDBoxLayout(orientation='vertical', spacing=dp(12),
                                     size_hint_y=None, height=dp(200),
                                     padding=[dp(20), dp(40)])
            empty_box.add_widget(MDLabel(
                text='🏫', halign='center', font_style='H2',
                size_hint_y=None, height=dp(60),
            ))
            empty_box.add_widget(MDLabel(
                text='Aucune classe',
                halign='center', font_style='H6',
                theme_text_color='Custom', text_color=T1,
                size_hint_y=None, height=dp(36),
            ))
            empty_box.add_widget(MDLabel(
                text='Appuyez sur "+ Ajouter" pour créer votre première classe.',
                halign='center', font_style='Body1',
                theme_text_color='Custom', text_color=T2,
                size_hint_y=None, height=dp(60),
            ))
            content.add_widget(empty_box)
        else:
            for cls in classes_data:
                cnt = cls.get('student_count', 0)
                card = ClassCard(
                    cls, cnt,
                    on_delete=self._confirm_delete,
                    on_edit=self._show_edit_dialog,
                )
                content.add_widget(card)

        scroll.add_widget(content)
        root.add_widget(scroll)
        root.add_widget(BottomNavBar(active_screen='classes'))
        self.add_widget(root)

    # ──────────────────────── Dialogs ─────────────────────────────────────────

    def _show_add_dialog(self):
        if self._dialog:
            self._dialog.dismiss()
        form = ClassFormContent()
        self._dialog = MDDialog(
            title='Nouvelle classe',
            type='custom',
            content_cls=form,
            buttons=[
                MDFlatButton(text='Annuler', on_release=lambda x: self._dialog.dismiss()),
                MDRaisedButton(text='Créer', md_bg_color=BLUE,
                               on_release=lambda x: self._do_create(form)),
            ],
        )
        self._dialog.open()

    def _do_create(self, form):
        vals = form.get_values()
        if not vals['nom']:
            return
        app = App.get_running_app()
        uid = self._get_user_uuid()
        app.db_manager.create_classe(uid, vals['nom'], vals['niveau'], vals['annee_scolaire'])
        self._dialog.dismiss()
        self._dialog = None
        self.on_enter()

    def _show_edit_dialog(self, classe):
        if self._dialog:
            self._dialog.dismiss()
        form = ClassFormContent(classe=classe)
        self._dialog = MDDialog(
            title='Modifier la classe',
            type='custom',
            content_cls=form,
            buttons=[
                MDFlatButton(text='Annuler', on_release=lambda x: self._dialog.dismiss()),
                MDRaisedButton(text='Enregistrer', md_bg_color=BLUE,
                               on_release=lambda x: self._do_edit(classe['uuid'], form)),
            ],
        )
        self._dialog.open()

    def _do_edit(self, classe_uuid, form):
        vals = form.get_values()
        if not vals['nom']:
            return
        app = App.get_running_app()
        app.db_manager.update_classe(classe_uuid, vals['nom'], vals['niveau'], vals['annee_scolaire'])
        self._dialog.dismiss()
        self._dialog = None
        self.on_enter()

    def _confirm_delete(self, classe):
        if self._dialog:
            self._dialog.dismiss()
        self._dialog = MDDialog(
            title='Supprimer la classe ?',
            text=f'"{classe.get("nom")}" et tous ses élèves seront supprimés.',
            buttons=[
                MDFlatButton(text='Annuler', on_release=lambda x: self._dialog.dismiss()),
                MDRaisedButton(text='Supprimer', md_bg_color=(0.9, 0.3, 0.3, 1),
                               on_release=lambda x: self._do_delete(classe['uuid'])),
            ],
        )
        self._dialog.open()

    def _do_delete(self, classe_uuid):
        app = App.get_running_app()
        app.db_manager.delete_classe(classe_uuid)
        self._dialog.dismiss()
        self._dialog = None
        self.on_enter()

    def _go(self, screen):
        try:
            self.manager.current = screen
        except Exception as e:
            print(f"[ClassesScreen] Nav error: {e}")
