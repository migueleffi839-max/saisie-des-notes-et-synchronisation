"""
Analytics Screen — Grade distribution charts
ISSAM v3.0 — FIX: _go_back undefined, on_enter missing, class avg from real DB
"""
import math
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle, Ellipse, Line
from kivy.metrics import dp
from kivy.app import App
from widgets.bottom_nav import BottomNavBar
from core.theme.theme_manager import (
    BG, CARD1, CARD2, BLUE, PURPLE, GREEN, GREEN_A, AMBER, AMBER_A,
    RED, RED_A, BLUE_A, T1, T2, T3
)


class DonutChart(Widget):
    def __init__(self, dist, **kwargs):
        super().__init__(**kwargs)
        self._dist = dist
        self.bind(pos=self._draw, size=self._draw)

    def _draw(self, *a):
        self.canvas.clear()
        cx, cy = self.center_x, self.center_y
        r  = min(self.width, self.height) / 2 - dp(4)
        ri = r * 0.58

        slices = [
            ('Excellent ≥16', self._dist.get('excellent', 0), GREEN),
            ('Bien 12-15',    self._dist.get('bien', 0),      BLUE),
            ('Passable 8-11', self._dist.get('passable', 0),  AMBER),
            ('Insuffisant',   self._dist.get('insuffisant', 0), RED),
        ]
        total = sum(s[1] for s in slices) or 100
        angle = 90

        with self.canvas:
            for label, val, color in slices:
                sweep = val / total * 360
                pts = []
                for deg in range(int(angle), int(angle - sweep), -2):
                    rad = math.radians(deg)
                    pts += [cx + r * math.cos(rad), cy + r * math.sin(rad)]
                if len(pts) >= 4:
                    Color(*color[:3], 0.9)
                    Line(points=pts, width=dp(13))
                angle -= sweep

            Color(*BG)
            Ellipse(pos=(cx - ri, cy - ri), size=(ri * 2, ri * 2))
            Color(*CARD1)
            ct = dp(38)
            Ellipse(pos=(cx - ct, cy - ct), size=(ct * 2, ct * 2))

    def on_size(self, *a):
        self._draw()


class AnalyticsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def on_enter(self):
        self.clear_widgets()
        self._build_ui()

    # ── FIX: _go_back was called but never defined ─────────────────────────────
    def _go_back(self):
        try:
            self.manager.current = 'dashboard'
        except Exception as e:
            print(f"[AnalyticsScreen] nav error: {e}")

    def _build_ui(self):
        with self.canvas.before:
            Color(*BG)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size)
        self.bind(pos=lambda *a: setattr(self._bg, 'pos', self.pos),
                  size=lambda *a: setattr(self._bg, 'size', self.size))

        app   = App.get_running_app()
        stats = app.db_manager.get_global_stats()
        dist  = app.db_manager.get_note_distribution()

        # Build real per-class averages from DB
        classes_data = app.db_manager.get_classes_with_counts()
        class_avgs = []
        for cls in classes_data:
            students = app.db_manager.get_students_with_averages(cls['uuid'])
            moyennes = [float(s['moyenne']) for s in students
                        if s.get('moyenne') is not None]
            avg = round(sum(moyennes) / len(moyennes), 1) if moyennes else 0.0
            moy_color = GREEN if avg >= 12 else (AMBER if avg >= 8 else RED)
            class_avgs.append((cls['nom'], avg, moy_color))

        root = MDBoxLayout(orientation='vertical')

        # ── Top bar ─────────────────────────────────────────────────────────────
        topbar = MDBoxLayout(orientation='horizontal', size_hint_y=None, height=dp(68),
                             padding=[dp(8), dp(14), dp(16), dp(4)], spacing=dp(4))
        back_btn = MDIconButton(icon='arrow-left', theme_icon_color='Custom', icon_color=T1)
        back_btn.bind(on_release=lambda x: self._go_back())
        topbar.add_widget(back_btn)
        t_box = MDBoxLayout(orientation='vertical', spacing=dp(1))
        t_box.add_widget(MDLabel(text='Statistiques', font_style='H5',
                                 theme_text_color='Custom', text_color=T1))
        t_box.add_widget(MDLabel(text=f'Basé sur {stats["notes"]} notes',
                                 font_style='Caption', theme_text_color='Custom', text_color=T2))
        topbar.add_widget(t_box)
        topbar.add_widget(Widget())
        root.add_widget(topbar)

        scroll = MDScrollView()
        body = MDBoxLayout(orientation='vertical',
                           padding=[dp(16), dp(4), dp(16), dp(80)],
                           spacing=dp(16), size_hint_y=None)
        body.bind(minimum_height=body.setter('height'))

        # ── KPI row ─────────────────────────────────────────────────────────────
        kpi_row = MDBoxLayout(orientation='horizontal', spacing=dp(10),
                              size_hint_y=None, height=dp(78))
        moy = stats['moyenne']
        for label, value, color in [
            ('Moy. générale', f'{moy}/20', GREEN if moy >= 12 else (AMBER if moy >= 8 else RED)),
            ('Notes saisies', str(stats['notes']), BLUE),
            ('Évaluations',   str(stats['evaluations']), PURPLE),
        ]:
            kpi = MDCard(md_bg_color=(*color[:3], 0.12), radius=[dp(18)],
                         orientation='vertical', padding=[dp(10), dp(8)],
                         size_hint=(1, 1), elevation=0)
            kpi.add_widget(MDLabel(text=value, halign='center', font_style='H5',
                                   theme_text_color='Custom', text_color=color))
            kpi.add_widget(MDLabel(text=label, halign='center', font_style='Caption',
                                   theme_text_color='Custom', text_color=T3))
            kpi_row.add_widget(kpi)
        body.add_widget(kpi_row)

        # ── Donut chart card ─────────────────────────────────────────────────────
        donut_card = MDCard(orientation='vertical', padding=dp(16), spacing=dp(12),
                            md_bg_color=CARD1, radius=[dp(20)],
                            size_hint_y=None, height=dp(280), elevation=0)
        donut_card.add_widget(MDLabel(text='Répartition des notes', font_style='Subtitle1',
                                      theme_text_color='Custom', text_color=T1,
                                      size_hint_y=None, height=dp(24)))
        chart_row = MDBoxLayout(orientation='horizontal', spacing=dp(16))
        donut = DonutChart(dist, size_hint=(None, 1), width=dp(160))
        chart_row.add_widget(donut)

        legend = MDBoxLayout(orientation='vertical', spacing=dp(10), padding=[0, dp(20)])
        for label, key, color in [
            ('≥ 16  Excellent',  'excellent',  GREEN),
            ('12-15  Bien',      'bien',        BLUE),
            ('8-11  Passable',   'passable',    AMBER),
            ('< 8  Insuffisant', 'insuffisant', RED),
        ]:
            row = MDBoxLayout(orientation='horizontal', spacing=dp(10),
                              size_hint_y=None, height=dp(30))
            dot = MDCard(md_bg_color=(*color[:3], 0.25), radius=[dp(6)],
                         size_hint=(None, None), size=(dp(12), dp(12)),
                         pos_hint={'center_y': 0.5})
            pct = dist.get(key, 0)
            row.add_widget(dot)
            row.add_widget(MDLabel(text=label, font_style='Caption',
                                   theme_text_color='Custom', text_color=T2))
            row.add_widget(Widget())
            row.add_widget(MDLabel(text=f'{pct}%', halign='right', font_style='Body2',
                                   size_hint=(None, 1), width=dp(36),
                                   theme_text_color='Custom', text_color=color))
            legend.add_widget(row)
        chart_row.add_widget(legend)
        donut_card.add_widget(chart_row)
        body.add_widget(donut_card)

        # ── Bar chart — by grade band ────────────────────────────────────────────
        bar_data = [
            ('Excellent ≥16', dist.get('excellent', 0), GREEN),
            ('Bien 12-15',    dist.get('bien', 0),      BLUE),
            ('Passable 8-11', dist.get('passable', 0),  AMBER),
            ('Insuffisant <8', dist.get('insuffisant', 0), RED),
        ]
        bar_card = MDCard(orientation='vertical', padding=dp(16), spacing=dp(12),
                          md_bg_color=CARD1, radius=[dp(20)],
                          size_hint_y=None, height=dp(220), elevation=0)
        bar_card.add_widget(MDLabel(text='Détail par tranche', font_style='Subtitle1',
                                    theme_text_color='Custom', text_color=T1,
                                    size_hint_y=None, height=dp(24)))
        for label, val, color in bar_data:
            r = MDBoxLayout(orientation='horizontal', spacing=dp(8),
                            size_hint_y=None, height=dp(28))
            r.add_widget(MDLabel(text=label, font_style='Caption',
                                 size_hint=(None, 1), width=dp(100),
                                 theme_text_color='Custom', text_color=T2))
            bar_bg = MDCard(md_bg_color=CARD2, radius=[dp(8)], size_hint=(1, None),
                            height=dp(18), pos_hint={'center_y': 0.5})
            bar_fill = MDCard(
                md_bg_color=(*color[:3], 0.80), radius=[dp(8)],
                size_hint=(max(val / 100, 0.01), None), height=dp(18),
                pos_hint={'center_y': 0.5},
            )
            bar_bg.add_widget(bar_fill)
            r.add_widget(bar_bg)
            r.add_widget(MDLabel(text=f'{val}%', halign='right', font_style='Caption',
                                 size_hint=(None, 1), width=dp(32),
                                 theme_text_color='Custom', text_color=color))
            bar_card.add_widget(r)
        body.add_widget(bar_card)

        # ── Per-class averages (REAL data from DB) ────────────────────────────────
        if class_avgs:
            class_card_h = dp(56) + dp(28) * len(class_avgs)
            class_card = MDCard(orientation='vertical', padding=dp(16), spacing=dp(10),
                                md_bg_color=CARD1, radius=[dp(20)],
                                size_hint_y=None, height=class_card_h, elevation=0)
            class_card.add_widget(MDLabel(text='Moyenne par classe', font_style='Subtitle1',
                                          theme_text_color='Custom', text_color=T1,
                                          size_hint_y=None, height=dp(24)))
            for cls_nom, avg, color in class_avgs:
                r = MDBoxLayout(orientation='horizontal', spacing=dp(8),
                                size_hint_y=None, height=dp(28))
                r.add_widget(MDLabel(text=cls_nom, font_style='Caption',
                                     size_hint=(None, 1), width=dp(90),
                                     theme_text_color='Custom', text_color=T2))
                bar_bg = MDCard(md_bg_color=CARD2, radius=[dp(8)], size_hint=(1, None),
                                height=dp(18), pos_hint={'center_y': 0.5})
                bar_fill = MDCard(
                    md_bg_color=(*color[:3], 0.80), radius=[dp(8)],
                    size_hint=(max(avg / 20, 0.01), None), height=dp(18),
                    pos_hint={'center_y': 0.5},
                )
                bar_bg.add_widget(bar_fill)
                r.add_widget(bar_bg)
                r.add_widget(MDLabel(text=f'{avg}', halign='right', font_style='Caption',
                                     size_hint=(None, 1), width=dp(36),
                                     theme_text_color='Custom', text_color=color))
                class_card.add_widget(r)
            body.add_widget(class_card)

        scroll.add_widget(body)
        root.add_widget(scroll)
        root.add_widget(BottomNavBar(active_screen='analytics'))
        self.add_widget(root)
