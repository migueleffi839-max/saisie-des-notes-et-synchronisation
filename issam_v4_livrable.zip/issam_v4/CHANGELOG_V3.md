# ISSAM v3.0 — Corrections & Améliorations

## 🔴 Bugs critiques résolus

### 1. `_go_back()` non défini — crash immédiat au clic ← Retour
**Fichiers affectés :** `sync_screen.py`, `analytics_screen.py`, `settings_screen.py`  
**Symptôme :** `AttributeError: 'SyncScreen' object has no attribute '_go_back'`  
**Fix :** Méthode `_go_back()` ajoutée avec try/except dans chaque écran.

### 2. `close_btn` du NumpadPopup non relié — impossible de fermer le numpad
**Fichier :** `grades_screen.py`  
**Symptôme :** Le bouton ✕ du numpad n'avait aucun handler — le popup restait bloqué.  
**Fix :** `close_btn.bind(on_release=lambda x: self.dismiss())` ajouté.

### 3. Bouton ← de `GradeEntryScreen` non relié — navigation impossible
**Fichier :** `grades_screen.py`  
**Symptôme :** Le bouton retour de l'écran de saisie de notes ne faisait rien.  
**Fix :** `_back.bind(on_release=lambda x: self._go_back())` ajouté.

### 4. `on_release=` dans constructeur `MDIconButton` (BottomNavBar) — handler perdu
**Fichier :** `widgets/bottom_nav.py`  
**Symptôme :** KivyMD réinitialise les kwargs lors du rendu → tous les clics de navigation ignorés.  
**Fix :** Remplacement par `.bind(on_release=self._nav)` après création.

### 5. `Clock.schedule_once(lambda dt: setattr(manager, 'current', screen))` — race condition
**Fichiers :** `login_screen.py`, `register_screen.py`, `sync_screen.py`, `splash_screen.py`  
**Symptôme :** `setattr` dans un lambda Clock ne garantit pas que le ScreenManager existe encore → crash intermittent.  
**Fix :** Remplacement par des méthodes `_go_dashboard()` / `_leave_to()` avec try/except.

### 6. `_SpinRing` — fuite mémoire via `Clock.schedule_interval` jamais annulé
**Fichier :** `splash_screen.py`  
**Symptôme :** Le timer de rotation continuait à tourner après la navigation → lag croissant.  
**Fix :** `on_parent()` annule le Clock quand le widget quitte l'arbre.

### 7. `SectionCard` — hauteur calculée incorrectement
**Fichier :** `settings_screen.py`  
**Symptôme :** La carte Paramètres dépassait ou tronquait les rangées selon le nombre de lignes.  
**Fix :** `height = dp(32) + sum(r.height for r in rows) + dp(8)` calculé dynamiquement.

### 8. `on_enter` manquant sur `AnalyticsScreen` et `SettingsScreen`
**Symptôme :** Le contenu n'était pas rechargé en revenant sur ces écrans → données périmées.  
**Fix :** `on_enter()` + `clear_widgets()` + `_build_ui()` ajoutés.

## 🟡 Améliorations fonctionnelles

### Synchronisation — données réelles
`SyncScreen` affiche maintenant les stats réelles depuis `db_manager.get_sync_stats()` et l'historique depuis `get_recent_sync_logs()`. Le bouton "Relancer les erreurs" appelle `reset_errors_to_pending()`.

### Analytiques — moyennes par classe depuis la DB
`AnalyticsScreen` calcule les moyennes par classe via `get_students_with_averages()` au lieu d'utiliser des données en dur (`[14.2, 11.8, 9.4, 8.1]`).

### Paramètres — notes en attente en temps réel
L'écran Paramètres affiche le nombre réel de notes en attente de sync.

## 🚀 Lancement

```bash
cd issam_v3
pip install kivy[base] kivymd requests
python main.py
```

**Comptes démo :**
| Email | Mot de passe |
|-------|-------------|
| `enseignant@example.com` | `password123` |
| `admin@issam.cm` | `admin123` |
