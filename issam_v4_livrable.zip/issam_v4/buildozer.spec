[app]
title = ISSAM Academic Evaluation System
package.name = issamapp
package.domain = org.issam
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf,json
version = 1.0
requirements = python3,kivy==2.3.0,kivymd==2.0.0,sqlite3,requests

orientation = portrait
fullscreen = 0

android.permissions = INTERNET,ACCESS_NETWORK_STATE,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE
android.api = 33
android.minapi = 26
android.ndk = 25b
android.ndk_api = 26
android.arch = arm64-v8a

[buildozer]
log_level = 2
warn_on_root = 1
