# ISSAM Academic Evaluation System
## Guide d'installation complet — Ubuntu 22.04 / 24.04

---

## 🏗️ Architecture du projet

```
issam_app/
├── main.py                    # Point d'entrée principal
├── backend_api.py             # API FastAPI (serveur)
├── buildozer.spec             # Config build APK Android
├── requirements.txt
│
├── core/
│   ├── theme/theme_manager.py    # Design system couleurs
│   ├── database/db_manager.py    # SQLite offline
│   ├── network/network_monitor.py # Détection réseau
│   └── sync/sync_manager.py       # Synchronisation LWW
│
├── screens/
│   ├── splash/      → Écran de démarrage animé
│   ├── auth/        → Connexion JWT + offline
│   ├── dashboard/   → Tableau de bord + stats
│   ├── classes/     → Liste des classes
│   ├── students/    → Liste élèves avec moyennes
│   ├── evaluations/ → Gestion évaluations
│   ├── grades/      → Saisie rapide notes (autosave)
│   ├── sync_screen/ → Synchronisation avec animations
│   ├── analytics/   → Statistiques et graphiques
│   └── settings/    → Profil et paramètres
│
└── widgets/
    └── bottom_nav.py  # Barre de navigation partagée
```

---

## ⚡ Installation rapide (Ubuntu)

### 1. Prérequis système

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3.12 python3.12-venv python3-pip \
    git curl build-essential libssl-dev libffi-dev \
    libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev \
    libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev \
    zlib1g-dev libgstreamer1.0-dev gstreamer1.0-plugins-base \
    xclip pkg-config
```

### 2. Créer l'environnement virtuel

```bash
cd issam_app/
python3.12 -m venv venv
source venv/bin/activate
```

### 3. Installer les dépendances Python

```bash
pip install --upgrade pip
pip install kivy[base] kivymd
pip install requests
```

### 4. Lancer l'application mobile

```bash
python main.py
```

### Identifiants de test

| Champ | Valeur |
|-------|--------|
| Email | enseignant@example.com |
| Mot de passe | password123 |

---

## 🌐 Backend FastAPI (optionnel)

### Installation

```bash
pip install fastapi uvicorn pyjwt python-multipart
```

### Lancement

```bash
python backend_api.py
# Accès : http://localhost:8000
# Docs  : http://localhost:8000/docs
```

---

## 📱 Build APK Android

### 1. Installer Buildozer

```bash
pip install buildozer cython
sudo apt install -y openjdk-17-jdk
```

### 2. Générer l'APK (debug)

```bash
buildozer android debug
```

### 3. Déployer sur Android

```bash
buildozer android debug deploy run
```

L'APK se trouve dans : `bin/issamapp-1.0-arm64-v8a-debug.apk`

---

## 🔄 Logique de synchronisation

| Étape | Description |
|-------|-------------|
| **1. Saisie offline** | Notes sauvegardées en SQLite avec `sync_status = 'pending_sync'` |
| **2. Détection réseau** | `NetworkMonitor` poll toutes les 5s |
| **3. Push automatique** | `SyncManager.start_sync()` → batch vers `/api/sync/push` |
| **4. LWW résolution** | `updated_at` le plus récent gagne |
| **5. Pull référentiel** | Récupération élèves/classes via `/api/sync/pull` |

---

## 🗄️ Modèle de données (SQLite local)

Tables : `utilisateur`, `matiere`, `classe`, `eleve`, `enseigne`, `evaluation`, `note`, `session_sync`, `sync_queue`

Colonnes de sync obligatoires sur chaque table :

| Colonne | Type | Rôle |
|---------|------|------|
| `uuid` | TEXT (PK) | Identifiant universel UUID v4 |
| `created_at` | TIMESTAMP | Date de création |
| `updated_at` | TIMESTAMP | Dernière modification (LWW) |
| `sync_status` | TEXT | `pending_sync` ou `synced` |

---

## 🔒 Sécurité implémentée

- ✅ JWT tokens (expiration 24h)
- ✅ Hash SHA-256 des mots de passe
- ✅ Connexion offline avec cache des identifiants
- ✅ TLS/HTTPS sur tous les flux API (en production)
- ✅ Validation des notes côté client (0–20)

---

## 📊 Fonctionnalités de l'application

| Écran | Fonctionnalité |
|-------|---------------|
| **Splash** | Animation logo avec transition fluide |
| **Login** | Auth JWT + fallback offline |
| **Dashboard** | Stats globales, activité récente, sync indicator |
| **Classes** | Liste avec badges online/offline par classe |
| **Élèves** | Tableau avec moyennes colorées |
| **Évaluations** | Filtrage par statut (Publié / En cours / Brouillon) |
| **Saisie Notes** | Autosave SQLite, validation instantanée |
| **Synchronisation** | Barre de progression, stats détaillées, retry |
| **Analytiques** | Donut chart distribution, bar chart évolution |
| **Profil** | Gestion compte, déconnexion |
