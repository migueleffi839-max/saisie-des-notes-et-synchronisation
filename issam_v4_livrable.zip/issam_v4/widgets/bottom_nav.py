"""
Floating Bottom Navigation Bar — Pill design
ISSAM v3.0 — FIX: on_release= in MDIconButton constructor replaced by .bind()
"""
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDIconButton
from kivymd.uix.label import MDLabel
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.app import App
from core.theme.theme_manager import BG, CARD1, BLUE, T2, T3


ITEMS = [
    ('home-variant',      'Accueil',     'dashboard'),
    ('view-grid-outline', 'Classes',     'classes'),
    ('clipboard-text',    'Évaluations', 'evaluations'),
    ('chart-bar',         'Stats',       'analytics'),
    ('account-circle',    'Profil',      'settings'),
]


class NavItem(MDBoxLayout):
    def __init__(self, icon, label, screen, active, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = dp(2)
        self.padding = [dp(4), dp(6)]
        self._screen = screen

        color = BLUE if active else T3

        # FIX: do NOT pass on_release= as constructor kwarg — bind() after creation
        icon_btn = MDIconButton(
            icon=icon,
            theme_icon_color='Custom',
            icon_color=color,
        )
        icon_btn.bind(on_release=self._nav)

        lbl = MDLabel(
            text=label,
            halign='center',
            font_style='Caption',
            theme_text_color='Custom',
            text_color=color,
            size_hint_y=None,
            height=dp(14),
        )
        if active:
            with icon_btn.canvas.after:
                Color(*BLUE)
                RoundedRectangle(
                    pos=(icon_btn.center_x - dp(3), icon_btn.y + dp(2)),
                    size=(dp(6), dp(3)),
                    radius=[dp(2)],
                )
        self.add_widget(icon_btn)
        self.add_widget(lbl)

    def _nav(self, *_):
        try:
            app = App.get_running_app()
            if app and app.root and app.root.current != self._screen:
                app.root.current = self._screen
        except Exception as e:
            print(f'[BottomNav] Nav error to {self._screen}: {e}')


class BottomNavBar(MDBoxLayout):
    def __init__(self, active_screen='dashboard', **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = dp(68)
        self.padding = [dp(4), dp(2), dp(4), dp(6)]
        self.spacing = dp(0)

        with self.canvas.before:
            Color(0.0, 0.0, 0.0, 0.4)
            self._shadow = RoundedRectangle(
                pos=(self.x - dp(2), self.y - dp(2)),
                size=(self.width + dp(4), self.height + dp(4)),
                radius=[dp(22), dp(22), 0, 0],
            )
            Color(0.055, 0.106, 0.180, 1)
            self._bg = RoundedRectangle(
                pos=self.pos, size=self.size,
                radius=[dp(20), dp(20), 0, 0],
            )
            Color(*BLUE[:3], 0.3)
            self._line = RoundedRectangle(
                pos=self.pos, size=(self.width, dp(1)),
                radius=[0],
            )
        self.bind(pos=self._upd, size=self._upd)

        for icon, label, screen in ITEMS:
            self.add_widget(NavItem(icon, label, screen, screen == active_screen))

    def _upd(self, *a):
        self._bg.pos    = self.pos
        self._bg.size   = self.size
        self._shadow.pos  = (self.x - dp(2), self.y - dp(2))
        self._shadow.size = (self.width + dp(4), self.height + dp(4))
        self._line.pos  = self.pos
        self._line.size = (self.width, dp(1))
