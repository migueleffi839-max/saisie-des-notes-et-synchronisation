"""
ISSAM Academic Evaluation System v2.0
Production SaaS — Firebase Auth + Offline-First SQLite
"""
from kivy.core.window import Window
from kivy.utils import platform
from kivymd.app import MDApp
from kivymd.uix.screenmanager import MDScreenManager

from core.theme.theme_manager import ThemeManager
from core.database.db_manager import DatabaseManager
from core.network.network_monitor import NetworkMonitor
from core.sync.sync_manager import SyncManager
from core.auth.auth_service import AuthService

from screens.splash.splash_screen          import SplashScreen
from screens.auth.login_screen             import LoginScreen
from screens.auth.register_screen          import RegisterScreen
from screens.auth.verify_email_screen      import VerifyEmailScreen
from screens.auth.forgot_password_screen   import ForgotPasswordScreen
from screens.dashboard.dashboard_screen    import DashboardScreen
from screens.classes.classes_screen        import ClassesScreen
from screens.students.students_screen      import StudentsScreen
from screens.evaluations.evaluations_screen import EvaluationsScreen
from screens.grades.grades_screen          import GradeEntryScreen
from screens.sync_screen.sync_screen       import SyncScreen
from screens.analytics.analytics_screen    import AnalyticsScreen
from screens.settings.settings_screen      import SettingsScreen

import traceback
import sys

def _handle_exception(exc_type, exc_value, exc_tb):
    print("[ISSAM CRASH] Uncaught exception:")
    traceback.print_exception(exc_type, exc_value, exc_tb)
    # Don't crash the app on non-critical errors
    if exc_type not in (KeyboardInterrupt, SystemExit):
        return
    sys.__excepthook__(exc_type, exc_value, exc_tb)

sys.excepthook = _handle_exception

if platform not in ('android', 'ios'):
    Window.size = (400, 800)


class IssamApp(MDApp):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.db_manager   = None
        self.network_monitor = None
        self.sync_manager = None
        self.auth_service = None
        self.current_user = None        # dict with uid, email, display_name…
        self.selected_classe     = None
        self.selected_evaluation = None

    def build(self):
        ThemeManager.apply(self)
        self.title = 'ISSAM v3.0 — Saisie de Notes'

        sm = MDScreenManager()
        sm.add_widget(SplashScreen(name='splash'))
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(RegisterScreen(name='register'))
        sm.add_widget(VerifyEmailScreen(name='verify_email'))
        sm.add_widget(ForgotPasswordScreen(name='forgot_password'))
        sm.add_widget(DashboardScreen(name='dashboard'))
        sm.add_widget(ClassesScreen(name='classes'))
        sm.add_widget(StudentsScreen(name='students'))
        sm.add_widget(EvaluationsScreen(name='evaluations'))
        sm.add_widget(GradeEntryScreen(name='grades'))
        sm.add_widget(SyncScreen(name='sync'))
        sm.add_widget(AnalyticsScreen(name='analytics'))
        sm.add_widget(SettingsScreen(name='settings'))
        sm.current = 'splash'
        return sm

    def on_start(self):
        # ── Database ──────────────────────────────────────────────────────────
        self.db_manager = DatabaseManager()
        self.db_manager.initialize()
        self.db_manager.seed_demo_data()

        # ── Network ───────────────────────────────────────────────────────────
        self.network_monitor = NetworkMonitor()
        self.network_monitor.start()

        # ── Sync ──────────────────────────────────────────────────────────────
        self.sync_manager = SyncManager(self.db_manager, self.network_monitor)

        # ── Auth service ─────────────────────────────────────────────────────
        self.auth_service = AuthService(self.db_manager)

        # ── Try to restore saved session ──────────────────────────────────────
        # (only reached after splash finishes — tied to splash's _leave)

    def on_pause(self):
        return True

    def on_resume(self):
        pass


if __name__ == '__main__':
    IssamApp().run()
