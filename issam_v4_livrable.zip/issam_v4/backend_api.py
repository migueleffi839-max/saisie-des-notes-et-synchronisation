"""
ISSAM Backend — FastAPI REST API
JWT Authentication + PostgreSQL + Sync Endpoints
"""
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime, timedelta
import uuid
import hashlib
import jwt  # PyJWT

# ─────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────
SECRET_KEY = "issam-super-secret-key-2025"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24h

app = FastAPI(
    title="ISSAM Academic Evaluation API",
    description="Backend RESTful pour l'application mobile de saisie de notes",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token")

# ─────────────────────────────────────────────
# In-memory store (replace with SQLAlchemy + PostgreSQL in production)
# ─────────────────────────────────────────────
FAKE_USERS = {
    "enseignant@example.com": {
        "uuid": "user-001",
        "nom": "Dupont",
        "prenom": "Marc",
        "email": "enseignant@example.com",
        "pwd_hash": hashlib.sha256("password123".encode()).hexdigest(),
        "role": "enseignant",
    }
}

# ─────────────────────────────────────────────
# Schemas (Pydantic)
# ─────────────────────────────────────────────
class Token(BaseModel):
    access_token: str
    token_type: str
    user: dict

class NoteSync(BaseModel):
    uuid: str
    evaluation_uuid: str
    eleve_uuid: str
    enseignant_uuid: str
    valeur: Optional[float] = None
    appreciation: Optional[str] = ""
    created_at: str
    updated_at: str
    sync_status: str = "pending_sync"

class SyncPayload(BaseModel):
    device_id: str
    notes: List[NoteSync] = []

class SyncResult(BaseModel):
    synced_count: int
    errors: List[str] = []
    server_timestamp: str

# ─────────────────────────────────────────────
# Auth helpers
# ─────────────────────────────────────────────
def create_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode["exp"] = expire
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(token: str = Depends(oauth2_scheme)) -> dict:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expiré")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Token invalide")

# ─────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────

@app.get("/")
def root():
    return {"message": "ISSAM Academic Evaluation API v1.0", "status": "online"}

@app.post("/auth/token", response_model=Token)
def login(form: OAuth2PasswordRequestForm = Depends()):
    user = FAKE_USERS.get(form.username)
    if not user:
        raise HTTPException(status_code=400, detail="Utilisateur introuvable")
    pwd_hash = hashlib.sha256(form.password.encode()).hexdigest()
    if user["pwd_hash"] != pwd_hash:
        raise HTTPException(status_code=400, detail="Mot de passe incorrect")
    token = create_token({"sub": user["uuid"], "email": user["email"], "role": user["role"]})
    return {"access_token": token, "token_type": "bearer", "user": user}

@app.get("/api/me")
def get_me(current_user: dict = Depends(verify_token)):
    email = current_user.get("email")
    user = FAKE_USERS.get(email, {})
    return user

@app.get("/api/classes")
def get_classes(current_user: dict = Depends(verify_token)):
    return [
        {"uuid": "cls-001", "nom": "3ème A", "niveau": "3ème", "annee_scolaire": "2024-2025"},
        {"uuid": "cls-002", "nom": "2nde B", "niveau": "2nde", "annee_scolaire": "2024-2025"},
        {"uuid": "cls-003", "nom": "1ère C", "niveau": "1ère", "annee_scolaire": "2024-2025"},
        {"uuid": "cls-004", "nom": "Terminale D", "niveau": "Terminale", "annee_scolaire": "2024-2025"},
    ]

@app.get("/api/evaluations")
def get_evaluations(current_user: dict = Depends(verify_token)):
    return [
        {"uuid": "ev-001", "nom": "Devoir Maison", "type": "Devoir Maison",
         "classe_uuid": "cls-001", "matiere_uuid": "mat-001",
         "date_debut": "2024-05-20", "bareme": 20.0},
    ]

@app.post("/api/sync/push", response_model=SyncResult)
def sync_push(payload: SyncPayload, current_user: dict = Depends(verify_token)):
    """
    Réception batch de notes (Last-Write-Wins par updated_at)
    """
    synced = 0
    errors = []

    for note in payload.notes:
        try:
            # In production: upsert into PostgreSQL with LWW policy
            # UPDATE note SET valeur=?, updated_at=? WHERE uuid=? AND updated_at < ?
            # OR INSERT if not exists
            synced += 1
        except Exception as e:
            errors.append(f"Note {note.uuid}: {str(e)}")

    return SyncResult(
        synced_count=synced,
        errors=errors,
        server_timestamp=datetime.utcnow().isoformat(),
    )

@app.get("/api/sync/pull")
def sync_pull(since: Optional[str] = None, current_user: dict = Depends(verify_token)):
    """
    Retourne les données modifiées depuis la dernière sync (Pull)
    """
    return {
        "classes": [],
        "eleves": [],
        "evaluations": [],
        "notes": [],
        "server_timestamp": datetime.utcnow().isoformat(),
    }

# ─────────────────────────────────────────────
# Run
# ─────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
